#pragma once

#define m_UNITYLIB "libunity.so"
#define m_ANOGSLIB "libanogs.so"

#define SLEEP_TIME 1000LL / 60LL
uintptr_t m_unity;

uintptr_t libs;
uintptr_t Class_Pawn_get_AimRotation;
uintptr_t Class_Component_get_gameObject;
uintptr_t Class_Transform_get_position;
uintptr_t Class_Transform_get_eulerAngles;
uintptr_t Class_Gameplay_get_MatchGame;
uintptr_t Class_Gameplay_get_LocalPawn;
uintptr_t Class_Pawn_get_IsFiring;
uintptr_t Class_Pawn_IsAiming;
uintptr_t Class_Pawn_get_TriggerQuickKnife;
uintptr_t Class_Pawn_set_AimRotation;
uintptr_t Class_Pawn_get_MapShowRotation;
uintptr_t Class_MatchGame_get_DroppedPickUpMgr;

uintptr_t Class_Pawn_get_LastPawnPos;
uintptr_t Class_Pawn_get_HeadPosition;
uintptr_t Class_Pawn_get_PlayerName;
uintptr_t Class_Pawn_get_TeamSeatId;
uintptr_t PlayerVisibleC;

uintptr_t Class_Input_GetTouch;
uintptr_t Class_Input_get_touchSupported;
uintptr_t Class_Input_get_touchCount;
uintptr_t Class_Input_get_mousePosition;
uintptr_t Screen_get_width;
uintptr_t Screen_get_height;
uintptr_t Screen_get_dpi;

uintptr_t Class_Pawn_m_PlayerInfo;
uintptr_t Class_PlayerInfo_m_IsPlayerDead;
uintptr_t Class_PlayerInfo_m_NickName;
uintptr_t Class_AttackableTarget_m_AttackableInfo;
uintptr_t Class_AttackableTarget_m_Health;
uintptr_t Class_AttackableTarget_m_MaxHealth;
uintptr_t Class_BaseGame_m_AllVehicles;
uintptr_t Class_AttackableTarget_m_ExtraHealth;
uintptr_t Class_AttackableTarget_m_MaxExtraHealth;
uintptr_t Class_Pawn_m_IsBot;
uintptr_t Class_Pawn_m_IsAlive;
uintptr_t Class_Pawn_IsFadeOut;
uintptr_t Class_Pawn_m_Mesh;
uintptr_t Class_Pawn_m_HeadBone;
uintptr_t Class_BaseGame_EnemyPawns;
uintptr_t Class_Pawn_bDiedRespawn;
uintptr_t Class_Pawn_m_LastFireWeaponName;
uintptr_t Class_PhysicsVehicle_vehicleType;
uintptr_t Class_LethalAndTacticalConfConfig_MarkOfName;
uintptr_t Class_BRDroppedPickUpNormal_mThrowConf;
uintptr_t Class_BRDroppedPickUpMgr_mNormalItemEntityDic;

uintptr_t Class_Transform_set_position;
uintptr_t Class_Transform_set_localPosition;

uintptr_t Class_Time_set_timeScale;
uintptr_t Class_Time_get_timeScale;


uintptr_t Class_Animator_GetBoneTransform;
uintptr_t Class_GameObject_GetComponent;
uintptr_t Class_Type_GetType;


uintptr_t api24 = 0x599; 
uintptr_t api25 = 0x530; 
uintptr_t api26 = 0x19C; 
uintptr_t api27 = 0x198; 
uintptr_t api28 = 0x33C; 
uintptr_t api29 = 0x2D8; 
uintptr_t api30 = 0x2F0; 
uintptr_t api31 = 0x300; 

void UpdateAllOffset(){
#define Class_Input_get_touchCount (m_unity + 0x5057E08)
#define Class_Input_GetTouch (m_unity + 0x5057E18)
#define Class_Input_get_mousePosition (m_unity + 0x50577C0)
#define Class_Screen_get_width (m_unity + 0x50504BC)
#define Class_Screen_get_height (m_unity + 0x5050520)
#define Class_Screen_get_dpi (m_unity + 0x5087930)
#define Class_Camera_get_main (m_unity + 0x5024010)
#define Class_Camera_WorldToScreenPoint (m_unity + 0x5023AB8)
#define Class_Component_get_transform (m_unity + 0x50291B0)
#define Class_Transform_get_position (m_unity + 0x507C19C)
#define Class_Gameplay_get_MatchGame (m_unity + 0x8569B10)
#define Class_Gameplay_get_LocalPawn (m_unity + 0x856AA08)
#define Class_Pawn_get_IsFiring (m_unity + 0x51A8A38)         
#define Class_Pawn_set_AimRotation (m_unity + 0x51B42E4)     
#define Class_Pawn_IsAiming (m_unity + 0x519BB10)
#define Class_Pawn_get_LocalOrViewTargetPlayerInfo (m_unity + 0x856DD28) 
#define Class_Pawn_get_LastPawnPos (m_unity + 0x51B8D30)
#define Class_Pawn_get_HeadPosition (m_unity + 0x51B86EC)
#define Class_Pawn_get_PlayerName (m_unity + 0x51B8BDC)
#define Class_Pawn_get_TeamSeatId (m_unity + 0x51B89F4)
#define Class_Input_get_touchSupported (m_unity + 0x5057F00)

#define Pawn_get_CurrentWeapon (m_unity + 0x518BEA8)
#define Weapon_GetWeaponId (m_unity + 0x51199AC)

#define Class_Pawn_m_PlayerInfo (0x5C0)
#define Class_Pawn_m_IsBot (0x5B9)
#define Class_Pawn_m_IsAlive (0x548)
#define Class_Pawn_IsFadeOut (0x5B8)
#define Class_Pawn_m_Mesh (0x628)
#define Class_Pawn_m_HeadBone (0x308)
#define Class_PlayerInfo_m_NickName (0x160)
#define Class_AttackableTarget_m_AttackableInfo (0x78)
#define Class_AttackableTarget_m_Health (0x34)              
#define Class_AttackableTarget_m_MaxHealth (0x38)

#define Class_Pawn_m_SpineBone (0x1C38)
#define Class_Pawn_m_NeckBone (0x1C40)
#define Class_Pawn_m_HipsBone (0x1C48)
#define Class_Pawn_m_LeftAnkleBone (0x1C50)
#define Class_Pawn_m_RightAnkleBone (0x1C58)

#define Class_BaseGame_EnemyPawns (0x178)

#define Class_Weapon_m_FireComponents (0x00)
#define Class_FireComponentArray_m_CurrentComponent (0x00)
#define Class_WeaponFireComponent_m_ClipAmmoCount (0x00)
#define Class_WeaponFireComponent_m_CarriedAmmoCount (0x00)
#define Class_WeaponFireComponent_m_BaseClipAmmoCount (0x00)

#define Class_Transform_set_position (m_unity + 0x4F1AE94)    
#define Class_Transform_set_localPosition (m_unity + 0x507AD40) 

//-- Skeleton
#define Class_Animator_GetBoneTransform (m_unity + 0x50182B8)
#define Class_GameObject_GetComponent (m_unity + 0x502B780)
#define Class_Type_GetType (m_unity + 0x4EC0224)
#define Class_Component_get_gameObject (m_unity + 0x5028B54)

#define Class_Time_set_timeScale (m_unity + 0x509B320)
#define Class_Time_get_timeScale (m_unity + 0x5020738)

}

bool get_touchSupported(void *instance) {
    return reinterpret_cast<bool(__fastcall *)(void *)>(Class_Input_get_touchSupported)(instance);
}

int get_touchCount() {
    return reinterpret_cast<int(__fastcall *)()>(Class_Input_get_touchCount)();
}

Vector3 get_mousePosition(void *instance) {
    return reinterpret_cast<Vector3(__fastcall *)(void *)>(Class_Input_get_mousePosition)(instance);
}

int get_width() {
    return reinterpret_cast<int(__fastcall *)()>(Class_Screen_get_width)();
}

int get_height() {
    return reinterpret_cast<int(__fastcall *)()>(Class_Screen_get_height)();
}

int get_dpi() {
    return reinterpret_cast<int(__fastcall *)()>(Class_Screen_get_dpi)();
}