extern uintptr_t Item2InventoryAddress;
extern uintptr_t WeaponConfAddress;
extern uintptr_t WeaponConfExtraAddress;
extern uintptr_t WeaponFireEffectAddress;
extern uintptr_t CharacterModelAddress;
extern uintptr_t BRDeadboxSkinAddress;
extern uintptr_t BRDropPlaneSkinAddress;
extern uintptr_t WeaponAssetGroupAddress;
extern uintptr_t MythicArmorConfigAddress;
extern uintptr_t MythicSightConfigAddress;
extern uintptr_t KillEffectItemConfConfigAddress;
extern uintptr_t WeaponSkinAddress;
extern uintptr_t ItemResourceAddress;
extern uintptr_t RoleConfAddress;
extern uintptr_t RoleSkinAddress;
extern uintptr_t RolePackConfAddress;
extern uintptr_t WeaponConfName;
extern uintptr_t GetDropPlaneName;
extern uintptr_t GetNameRoleSkin;
extern uintptr_t GetRoleConfName;
extern uintptr_t GetDeadBoxIDAddress;
extern uintptr_t VehicleSkinConfAddress;
extern uintptr_t VehicleItemConfAddress;
extern uintptr_t VehicleSkinHelperChangeVehicleSkinIdAddress;
extern uintptr_t VehicleSkinHelperChangeVehicleSkinConfAddress;
extern uintptr_t VehicleSkisSetupSkinAddress;
extern uintptr_t VehicleSkisChangeSkinIdAddress;
extern uintptr_t VehicleSkisChangeSkinConfAddress;
extern uintptr_t VehicleSkisBuildVehicleModelAddress;
extern uintptr_t VehicleSkisLoadModelCompleteAddress;
extern uintptr_t VehicleSkisApplySkinAddress;
extern std::vector<void *> itemInventoryInstance;
extern std::vector<void *> weaponExtraInstance;
extern std::vector<void *> weaponFireEffectInstance;
extern std::vector<void *> weaponConfInstance;
extern std::vector<void *> weaponAssetGroupInstance;
extern std::vector<void *> mythicArmorInstance;
extern std::vector<void *> mythicSightInstance;
extern std::vector<void *> killEffectItemInstance;
extern std::vector<void *> weaponSkinConfigInstance;
extern std::vector<void *> itemResourceConfigInstance;
extern std::vector<void *> CharacterModelConfigInstance;
extern std::vector<void *> RoleConfConfigInstance;
extern std::vector<void *> RoleSkinConfigInstance;
extern std::vector<void *> RolePackConfConfigInstance;
extern std::vector<void *> BRDeadboxSkinConfigInstance;
extern std::vector<void *> BRDropPlaneSkinConfigInstance;
extern std::vector<void *> ExecutionConfConfigInstance; 
extern std::vector<void *> vehicleSkinConfigInstance;
extern std::vector<void *> vehicleItemConfigInstance;
extern std::unordered_map<int, int> activeVehicleSkins;
extern std::unordered_map<int, int> activeVehicleSkinsById;
extern std::unordered_map<int, void*> activeVehicleSkinConfs;
extern std::unordered_map<std::string, bool> sBool;
extern std::unordered_map<int, int> activeKillEffects;
extern std::unordered_map<int, int> activeBulletTrackEffects;
extern std::unordered_map<int, int> activeWeaponFireEffects;
extern std::unordered_map<int, int> activeWeaponBrocast;
extern int g_selectedTargetCharIndex;
extern bool enableAutoBestSkinAll;
extern void Toast(const char* text);
extern void ApplyBestSkinToAllWeapons();
extern std::unordered_map<int, int> bestSkinForWeapon;
extern std::unordered_map<int, int> bestKillEffectForWeapon;
extern std::unordered_map<int, int> bestKillConfForWeapon;
extern std::unordered_map<int, int> applykilleffects;
extern std::unordered_map<int, int> applyBrocast;
extern std::unordered_map<int, int> bestFireEffectForWeapon;
extern std::unordered_map<int, int> currentBestTier;
extern std::unordered_map<int, int> bestKillTierForWeapon;
extern std::unordered_map<std::string, bool> xBool;
extern std::unordered_map<int, int> bestSkinForWeapon;
extern std::unordered_map<int, int> bestKillConfForWeapon;
extern void LoadWeaponSkins();

struct TargetChar {
    std::string name;
    int traitor1p;
    int traitor3p;
    int itemID;
    int roleID;
    int rolepackID;
};

extern std::vector<TargetChar> g_targetCharacters;

struct itemInfo
{
    std::string itemName;
    std::array<int, 4> Item2Inventory;
    std::array<int, 4> WeaponConf;
    std::array<int, 5> WeaponExtra;
    std::array<int, 3> WeaponAsset;
    std::array<int, 4> WeaponAttach;
    std::array<int, 3> ItemResInt;
    std::array<void*, 4> ItemRes;
    void* LOCID_Name;
    void* LOCID_Desc;
};

extern std::vector<itemInfo> itemData;

struct charInfo
{
    std::string charName;
    std::array<int, 12> charModel;
    std::array<int, 3> charRes;
    std::array<void *, 4> charRes2;
    std::array<int, 8> charRole;
    std::array<void *, 1> charRole2;
    std::array<int, 6> charPack;
    std::array<int, 2> charExec;
};
extern std::vector<charInfo> charData;

struct watcher
{
    std::string watchname;
    int watchvalue;
};
extern std::vector<watcher> watch;

struct deadbox
{
    std::string deadname;
    std::array<int, 6> dead;
};
extern std::vector<deadbox> deadboxF;

struct planeID
{
    std::string planename;
    std::array<int, 6> plane;
};
extern std::vector<planeID> dropplane;

struct snowboardInfo
{
    std::string skinName;
    int skinId;
};
extern std::vector<snowboardInfo> snowboardData;

extern char searchQuery[256];
extern std::string ToLower(std::string str);
extern uintptr_t getRealOffset(uintptr_t offset);

struct RoleSkinFields
{
    uint8_t ClothType;             // 0x20
    uint8_t ColorID;               // 0x19
    uint8_t GoGetPos;              // 0x1A
    uint8_t HatSubMode;            // 0x1B
    uint8_t IsCanBeUsedForAllRole; // 0x24
    bool IsCloseScreenSaver;       // 0x1D
    uint8_t SecondTab;             // 0x1E
    bool ShowInBag;                // 0x1F
    bool ShowRare;                 // 0x20
    int BRBagAssetID;              // 0x24
    int BRClothAssetID;            // 0x28
    int BRHatAssetID;              // 0x2C
    int BRLeftArmAssetID;          // 0x30
    int BRSuitAssetID;             // 0x34
    int BRWingAssetID;             // 0x38
    int BagAssetID;                // 0x3C
    int CamoID;                    // 0x28
    int ClothAssetID;              // 0x48
    int FxAssetIDHandGestureUI;    // 0x48
    int FxAssetIDShow;             // 0x4C
    int FxAssetID_1P;              // 0x50
    int FxAssetID_3P;              // 0x54
    int FxAssetID_UI;              // 0x58
    int HatAssetID;                // 0x5C
    uint ID;                       // 0x60
    int LeftArm1PAssetID;          // 0x64
    int LeftArmAssetID;            // 0x68
    int ShowBagAssetID;            // 0x6C
    int ShowClothAssetID;          // 0x70
    int ShowHatAssetID;            // 0x74
    int SuitAssetID;               // 0x80
    int WingAssetID;               // 0x80
};
extern RoleSkinFields *roleskinFields;

struct CharacterModelFields
{
    bool Female;               // 0x18
    uint AvatarAnimationType;  // 0x1C
    int BRBagModel;            // 0x20
    int BRHeadModel;           // 0x24
    int BRLobby;               // 0x20
    int BRModel;               // 0x24
    int BindEffect1P;          // 0x28
    int ChangeClipEffect1P;    // 0x2C
    int DefaultModelID;        // 0x30
    int Guarder1P;             // 0x34
    int Guarder3P;             // 0x38
    int GuarderBagModel;       // 0x3C
    int GuarderHeadModel;      // 0x28
    int GuarderLobby;          // 0x48
    int HeadIgnoreGUPSkin;     // 0x48
    int SpReceiveAnimType;     // 0x4C
    int Traitor1P;             // 0x50
    int Traitor3P;             // 0x54
    float *BagOffset;          // 0x58
    string *Desc;              // 0x60
    float *VehicleOffset;      // 0x68
    int *VestOtherModelID;     // 0x70
    uintptr_t ItemID;          // 0x7C
    uintptr_t LitePackDefault; // 0x80
};
extern CharacterModelFields *characterfields;

struct RolePackFields
{
    int mMatchRoomEasterEggType;           // 0x18
    uint mMatchRoomEasterEggCharacterID;   // 0x1C
    String *mMatchRoomEasterEggActionName; // 0x20
    bool DisableCustomize;                 // 0x20
    bool EntryDefaultAppearance;           // 0x21
    bool SkipWinnerCircleAnimation;        // 0x22
    bool UseDynamicLobbyScene;             // 0x23
    bool UseVFWFeature;                    // 0x24
    int AirItem1;                          // 0x24
    int AnimationWhenSell;                 // 0x28
    int CabinIndivID;                      // 0x2C
    int DeadBoxID;                         // 0x30
    int DynamicRoomAssetID;                // 0x34
    int EntryAnimID;                       // 0x38
    int EntryUIEffectAssetID;              // 0x3C
    int GestureId;                         // 0x28
    int HandEffectUI;                      // 0x48
    int KillStreakSkinID;                  // 0x48
    int LoadingFrame;                      // 0x4C
    int LobbySceneType;                    // 0x50
    int MVPIndivID;                        // 0x54
    int MatchRoomSort;                     // 0x58
    int OpenSceneIndivID;                  // 0x5C
    int PendantShowID;                     // 0x60
    int PetID;                             // 0x64
    int PetSwitchEffectAssetID;            // 0x68
    uint RolePackID;                       // 0x6C
    int SkillSkinID;                       // 0x70
    int SkillSkinUI;                       // 0x74
    int SpecialSceneFrameGroupAssetID;     // 0x7C
    int VTOLShowAssetID;                   // 0x80
    String *AirPoseBR;                     // 0x80
    String *EntryAnim;                     // 0x88
    String *EntryIdleAnim;                 // 0x90
    void *EntryIdleItems;                  // 0x98
    void *EntryItems;                      // 0xA0
    void *EntryItemsAnim;                  // 0xA8
    void *EntryItemsIdleAnim;              // 0xB0
    String *EntryUIAnimationStateName;     // 0xB8
};
extern RolePackFields *packfields;

struct RoleConfFields
{
    uint BaseCharacterID;           // 0x18
    uint roleLeftArmID;             // 0x1C
    uint roleFinalSuitID;           // 0x20
    uint roleBasicHologramID;       // 0x24
    uint8_t ArchiveSwitch;          // 0x20
    uint8_t ArmorType;              // 0x21
    bool BlockBack;                 // 0x22
    uint8_t ColorID;                // 0x23
    uint8_t ColorSubID;             // 0x24
    uint8_t DefaultPerk_1;          // 0x25
    uint8_t DefaultPerk_2;          // 0x26
    uint8_t DefaultPerk_3;          // 0x27
    bool DefaultShow;               // 0x28
    uint8_t DefaultSkill_1;         // 0x29
    bool ExternalUnVisible;         // 0x2A
    bool IsVFW;                     // 0x2B
    uint8_t Loadout_Magnifier_Flag; // 0x2C
    uint8_t LockedShowOrder;        // 0x2D
    uint8_t RoleLvGroupID;          // 0x2E
    bool ShowInBag;                 // 0x2E
    uint8_t ShowOrder;              // 0x2F
    bool ShowRare;                  // 0x30
    uint ID;                        // 0x34
    int JetPackInfoID;              // 0x38
    int KeepInCatalog;              // 0x3C
    float RTPCMaxValue;             // 0x28
    int RolePackID;                 // 0x48
    void *AudioSwitch;              // 0x48
    void *BRBankNameEX;             // 0x50
    void *BasicAudioBank;           // 0x58
    void *BasicAudioBank2;          // 0x60
    void *BasicAudioBank3;          // 0x68
    void *DefaultAudioBank;         // 0x70
    void *DefaultAudioBank2;        // 0x7C
    void *DefaultAudioEventEx;      // 0x80
    void *FoleyAudioBank;           // 0x88
    void *FoleyAudioNameEx;         // 0x90
    void *LOCID_Desc;               // 0x98
    void *LOCID_Name;               // 0xA0
    void *LitePackageKeyName;       // 0xA8
    void *MPBankNameEx;             // 0xB0
    void *PVEBankNameEX;            // 0xB8
    void *RTPCName;                 // 0xC0
    void *RoleSkinBox;              // 0xC8
    void *SpecialAudioBank;         // 0xD0
    void *SpecialAudioBank2;        // 0xD8
    void *SpecialAudioEventEx;      // 0xE0
    void *SpecialTips;              // 0xE8
    uint64_t WinnerCircle;          // 0xF0
};
extern RoleConfFields *roleFields;

struct ItemResourceFields
{
    int FxAssetID;            // 0x20
    int ID;                   // 0x24
    int InventoryModelID;     // 0x20
    int ModelAssetIDRaw;      // 0x24
    void *UIMiniSpriteName;   // 0x20
    void *UISmallSpriteName;  // 0x28
    void *UISpriteName;       // 0x30
    void *UISquareSpriteName; // 0x38
    uintptr_t AvatarModelID;   // 0x28
};
extern ItemResourceFields *itemFields;

struct ExecutionConfFields {
    bool IsGeneric;       // 0x18
    char _pad_11[3];
    int  BelongRoleID;    // 0x1C
    float DoDamageTime;   // 0x20
    float Duration;       // 0x24
    int  ExecutionID;     // 0x20
    int  ExecutionID_3p;  // 0x24
    int  ID;              // 0x28
    int  MaxKillRange;    // 0x2C
};
extern ExecutionConfFields *executionFields; 

struct WeaponConfFields
{
    uint8_t Accuracy;                // 0x20
    bool CanEquipOptic;              // 0x21
    uint8_t ColorID;                 // 0x22
    uint8_t ColorSubID;              // 0x23
    uint8_t Control;                 // 0x24
    uint8_t Damage;                  // 0x25
    bool ExternalUnVisible;          // 0x26
    uint8_t FireRate;                // 0x27
    uint8_t LOCID_HowToGet;          // 0x28
    uint8_t MaxAttach;               // 0x29
    uint8_t MaxSkill;                // 0x2A
    uint8_t Mobility;                // 0x2B
    uint8_t Range;                   // 0x2C
    bool ShowRare;                   // 0x2D
    uint8_t SuperShowGroup;          // 0x2E
    uint8_t WeaponBluePrintType;     // 0x2F
    uint8_t WinnerCircleAnimID;      // 0x30
    uint BaseWeaponId;               // 0x34
    int DefWeaponSkinID;             // 0x38
    int DefaultKillBrocast;          // 0x3C
    uint ID;                         // 0x28
    int WinnerCircleWeaponMountType; // 0x48
    void *EnableCamoBeta;            // 0x48
    void *LOCID_Desc;                // 0x50
    void *LOCID_Name;                // 0x58
    void *ModelRotation;             // 0x60
    void *UIProperty;                // 0x68
    void *UIPropertyUnlockLevel;     // 0x70
};
extern WeaponConfFields *weaponconfFields;

struct Item2InventoryFields
{
    int ItemID;                // 0x20
    int WeaponAssetGroupID;    // 0x24
    int WeaponIconID;          // 0x28
    void *AssetName;           // 0x30
    void *ConfigFilePathH;     // 0x38
    void *ConfigFilePath_BRH;  // 0x28
    void *ConfigFilePath_DMZH; // 0x48
    void *ConfigFilePath_PVEH; // 0x50
    void *WeaponNameH;         // 0x58
};
extern Item2InventoryFields *item2Fields;

struct WeaponAssetGroupFields
{
    int FireEffectGroupID;              // 0x28
    int Id;                             // 0x48
    int MeshAssetID1P;                  // 0x48
    int MeshAssetID3P;                  // 0x4C
    int MeshAssetID3P_L;                // 0x50
    int MeshAssetIDUI;                  // 0x54
    int ProjAssetID;                    // 0x58
    int ProjExplosionAssetID;           // 0x5C
    int ProjFlightAssetID;              // 0x60
    int ProjFlightAssetID3P;            // 0x64
    int SecendBRProjExplosionAssetID;   // 0x68
    int SecendProjAssetID;              // 0x6C
    int SecendProjExplosionAssetID;     // 0x70
    int SecendProjFlightAssetID;        // 0x74
    int SecendProjFlightAssetID3P;      // 0x7C
    int SecondaryFireEffectGroupID;     // 0x80
    int SpecialUnAimingEffectAssetID1P; // 0x80
    int UnusePupil;                     // 0x84
    int WeaponPickUpAssetID;            // 0x88
    void *LeftLaserRotation;            // 0x90
    void *RightLaserRotation;           // 0x98
    void *ScopeDistancePartIDs;         // 0xA0
    void *ScopeDistanceRatios;          // 0xA8
};
extern WeaponAssetGroupFields *weaponAssetFields;

struct WeaponFireEffectFields
{
    int AssetIdFor1P;                     // 0x18
    int AssetIdFor3P;                     // 0x1C
    int AssetIdForBulletSmoke1P;          // 0x20
    int AssetIdForBulletSmoke3P;          // 0x24
    int AssetIdForBulletTrack1P;          // 0x20
    int AssetIdForBulletTrack3P;          // 0x24
    int AssetIdForCharging1P;             // 0x28
    int AssetIdForCrossHair;              // 0x2C
    int AssetIdForDecalEffect;            // 0x30
    int AssetIdForExtra1P;                // 0x34
    int AssetIdForExtraBulletSmoke1P;     // 0x38
    int AssetIdForExtraBulletSmoke3P;     // 0x3C
    int AssetIdForHip1P;                  // 0x28
    int AssetIdForHip3P;                  // 0x48
    int AssetIdForHitEnemy;               // 0x48
    int AssetIdForInspectionScreenEffect; // 0x4C
    int AssetIdForSecondBulletSmoke1P;    // 0x50
    int AssetIdForSecondBulletSmoke3P;    // 0x54
    int AssetIdForSecondHip1P;            // 0x58
    int AssetIdForSecondHip3P;            // 0x5C
    int AssetIdForShellDrop1P;            // 0x60
    int AssetIdForShellDrop3P;            // 0x64
    int AttachAssetIdFor1P;               // 0x68
    int AttachAssetIdFor3P;               // 0x6C
    int AttachAssetIdForHip1P;            // 0x70
    int AttachAssetIdForHip3P;            // 0x74
    int DefaultKillEffectLevelUI;         // 0x7C
    float HitEffectDelayDestroyTime;      // 0x80
    int HitEffectType;                    // 0x80
    int Id;                               // 0x84
    float LevelEffectDelayTimeUI;         // 0x88
    float LevelEffectDelayTimeUI_King;    // 0x8C
    void *AssetIdForInspectionEffect;     // 0x90
    void *AssetIdForLevelEffects;         // 0x98
    void *AssetIdForLevelEffectsUI;       // 0xA0
    void *AssetIdsForCircleBluntDecal;    // 0xA8
    void *AssetIdsForCrustDecal;          // 0xB0
    void *AssetIdsForExtraEffects;        // 0xB8
    void *AssetIdsForExtraEffects3P;      // 0xC0
    void *AssetIdsForExtraEffectsUI;      // 0xC8
    void *AssetIdsForMeleeAttack;         // 0xD0
    void *AssetIdsForMetalDecal;          // 0xD8
    void *AssetIdsForShellDrop1P;         // 0xE0
    void *AssetIdsForShellDrop3P;         // 0xE8
    void *AssetIdsForStripBluntDecal;     // 0xF0
    void *BRKillCountTimePlus;            // 0xF8
    void *BRKillCountTimePlus_King;       // 0x100
    void *FireSoundExtend;                // 0x108
    void *HitEffectAssetIds;              // 0x110
    void *KillCountForLevelEffect;        // 0x118
    void *KillCountForLevelEffect_King;   // 0x120
    void *MPKillCountTimePlus;            // 0x128
    void *MPKillCountTimePlus_King;       // 0x130
    void *MeleeEffectDetachParent;        // 0x138
    void *SocketForInspectionEffect;      // 0x140
    void *SocketForLevelEffects;          // 0x148
    void *SocketForLevelEffectsUI;        // 0x150
    void *SocketNameForExtra1P;           // 0x158
    void *SocketsForExtraEffects;         // 0x160
    void *SocketsForExtraEffects3P;       // 0x168
    void *SocketsForExtraEffectsUI;       // 0x170
    void *SocketsForMeleeAttack;          // 0x178
    void *SocketsForShellDrop1P;          // 0x180
    void *SocketsForShellDrop3P;          // 0x188
};
extern WeaponFireEffectFields *weaponfireFields;

struct WeaponConfExtraFields
{
    uint8_t DefaultMythicArmor;     // 0x18
    uint8_t DefaultMythicSig;       // 0x11
    uint8_t GoGetPos;               // 0x12
    uint8_t SecondTab;              // 0x13
    uint8_t ThirdTab;               // 0x1C
    int DefaultDeadReplayEffectId;  // 0x20
    int DefaultKillEffectId;        // 0x24
    int FireEffectGroupID;          // 0x20
    uint ID;                        // 0x24
    void *GoGetUrl;                 // 0x28
    void *IdleAnimationIndex;       // 0x30
    void *OpenViewSkill;            // 0x38
    void *OpenViewSkillUnlockLevel; // 0x28
    void *PropertyModifys;          // 0x48
};
extern WeaponConfExtraFields *weaponextraFields;

struct MythicArmorFields
{
    int AssetID;              // 0x1C
    int ColorID;              // 0x20
    int ColorSubID;           // 0x24
    int GoGetPos;             // 0x20
    uint ID;                  // 0x24
    int MythicArmorLevel;     // 0x28
    int SecondTab;            // 0x2C
    int ThirdTab;             // 0x30
    void *EquippedWeaponIcon; // 0x38
    void *GoGetUrl;           // 0x28
    void *LOCID_Desc;         // 0x48
    void *LOCID_HowToGet;     // 0x50
    void *LOCID_Name;         // 0x58
    void *WeaponCanEquip;     // 0x60
};
extern MythicArmorFields *mythicarmorFields;

struct MythicSightFields
{
    bool ShowInBag;        // 0x18
    char pad_11[3];        // 0x11
    int AssetID;           // 0x1C
    int ColorID;           // 0x20
    int ColorSubID;        // 0x24
    uint ID;               // 0x20
    int RelateMythicSight; // 0x24
    void *LOCID_Desc;      // 0x28
    void *LOCID_Name;      // 0x30
    void *WeaponCanEquip;  // 0x38
};
extern MythicSightFields *mythicsightFields;

struct KillEffectItemFields
{
    void *RealAssetIDs;    // 0x18
    bool IsAutoDemolition; // 0x20
    bool ShowInBag;        // 0x19
    char pad_1A[2];        // 0x1A
    int ColorID;           // 0x24
    int ColorSubID;        // 0x20
    uint CurrencyID;       // 0x24
    int GoGetPos;          // 0x28
    uint ID;               // 0x2C
    int SecondTab;         // 0x30
    int SellPrice;         // 0x34
    int SellProtection;    // 0x38
    int ThirdTab;          // 0x3C
    void *AssetID;         // 0x28
    void *AssetID_CN;      // 0x48
    void *AssetID_GA;      // 0x50
    void *AssetID_KR;      // 0x58
    void *AssetID_VNG;     // 0x60
    string *GoGetUrl;      // 0x68
    void *KillCount;       // 0x70
    void *LOCID_Desc;      // 0x7C
    void *LOCID_HowToGet;  // 0x80
    void *LOCID_Name;      // 0x88
    void *WeaponCanEquip;  // 0x90
};
extern KillEffectItemFields *killeffectFields;

struct BRDeadboxSkinFields
{
    int ColorID;            // 0x18
    int DeadBoxEffectAsset; // 0x1C
    int Flag;               // 0x20
    int FlagAsset;          // 0x24
    uint ID;                // 0x20
    int ModelAsset3P;       // 0x24
    int ModelAssetUI;       // 0x28
};
extern BRDeadboxSkinFields *deadboxFields;

struct BRDropPlaneSkinFields
{
    int ColorID;            // 0x18
    uint ID;                // 0x1C
    int ModelAsset1P;       // 0x20
    int ModelAsset3P;       // 0x24
    int ModelAssetCutScene; // 0x20
    int ModelAssetUI;       // 0x24
    int Priority;           // 0x28
};
extern BRDropPlaneSkinFields *dropplaneFields;

std::string ToLower(std::string str) {
    std::transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

class VirtualKeyboard {
private:
    bool m_uppercase = false;
    char* m_targetBuffer = nullptr;
    size_t m_bufferSize = 0;

public:
    void SetTarget(char* buffer, size_t size) {
        m_targetBuffer = buffer;
        m_bufferSize = size;
    }

    void Render(bool* show) {
        if (!m_targetBuffer) return;

        if (ImGui::IsMouseClicked(0) && !ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow)) {
            if (show) *show = false;
        }

        float fullWidth = ImGui::GetContentRegionAvail().x;
        float btnHeight = 35.0f;
        float tagWidth = 45.0f;
        float spacing = 8.0f;

        float time = (float)ImGui::GetTime();
        float pulse = (sinf(time * 3.0f) * 0.5f) + 0.5f; 
        ImVec4 activeColor = ImVec4(0.0f, 0.7f + (pulse * 0.3f), 1.0f, 1.0f);

        const char* tagLabels[] = {"M", "L", "E", "C"};
        const char* tagValues[] = {"[M]", "[L]", "[E]", "[C]"};
        ImVec4 tagColors[] = {
            ImVec4(0.75f, 0.16f, 0.16f, 1.00f),
            ImVec4(0.8f, 0.5f, 0.1f, 1.00f),
            ImVec4(0.6f, 0.2f, 0.8f, 1.00f),
            ImVec4(0.2f, 0.6f, 0.2f, 1.00f)
        };

        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(spacing, 0));
        
        float totalRightWidth = (tagWidth * 4) + (btnHeight * 1) + (spacing * 5);
        ImGui::SetCursorPosX(fullWidth - totalRightWidth);

        for (int i = 0; i < 4; i++) {
            ImGui::PushStyleColor(ImGuiCol_Text, tagColors[i]);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, activeColor);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);

            if (ImGui::Button(tagLabels[i], ImVec2(tagWidth, btnHeight))) {
                memset(m_targetBuffer, 0, m_bufferSize); 
                strncpy(m_targetBuffer, tagValues[i], m_bufferSize - 1);
            }
            
            ImGui::PopStyleVar();
            ImGui::PopStyleColor(3);
            ImGui::SameLine();
        }

        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, activeColor);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);

        if (ImGui::Button("##TrashBtn", ImVec2(btnHeight, btnHeight))) {
            if (m_targetBuffer) m_targetBuffer[0] = '\0';
        }

        ImVec2 bPos = ImGui::GetItemRectMin();
        ImVec2 bSize = ImGui::GetItemRectSize();
        ImVec2 bCenter = ImVec2(bPos.x + bSize.x * 0.5f, bPos.y + bSize.y * 0.5f);
        ImDrawList* drawList = ImGui::GetWindowDrawList();
        ImU32 iconColor = ImGui::GetColorU32(ImGuiCol_Text);

        drawList->AddLine(ImVec2(bCenter.x - 4, bCenter.y - 4), ImVec2(bCenter.x + 4, bCenter.y + 4), iconColor, 1.5f);
        drawList->AddLine(ImVec2(bCenter.x + 4, bCenter.y - 4), ImVec2(bCenter.x - 4, bCenter.y + 4), iconColor, 1.5f);
        drawList->AddRect(ImVec2(bCenter.x - 5, bCenter.y - 2), ImVec2(bCenter.x + 5, bCenter.y + 6), iconColor, 1.0f);

        ImGui::PopStyleVar();
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar(); 
        
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        RenderKeyboardLayout(activeColor);
    }

private:
    void RenderKeyboardLayout(ImVec4 activeColor) {
        const char* rows[] = {"1234567890", "qwertyuiop", "asdfghjkl"};
        float windowWidth = ImGui::GetContentRegionAvail().x;
        float windowHeight = ImGui::GetContentRegionAvail().y;
        float btnHeight = (windowHeight / 6.5f);
        float btnWidth = (windowWidth / 11.0f);

        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(5, 6)); 
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 7.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f); 
        
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.18f, 0.18f, 0.18f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, activeColor); 
        
        ImGui::SetWindowFontScale(1.3f); 

        for (int i = 0; i < 3; i++) {
            int charCount = strlen(rows[i]);
            float rowWidth = (btnWidth + 5.0f) * charCount;
            ImGui::SetCursorPosX((windowWidth - rowWidth) * 0.5f);

            for (const char* c = rows[i]; *c; c++) {
                char buttonLabel[2] = { m_uppercase ? (char)std::toupper(*c) : *c, '\0' };
                if (ImGui::Button(buttonLabel, ImVec2(btnWidth, btnHeight))) {
                    TypeCharacter(buttonLabel[0]);
                }
                if (*(c + 1)) ImGui::SameLine();
            }
        }

        float row4Width = (btnWidth + 5.0f) * 9; 
        ImGui::SetCursorPosX((windowWidth - row4Width) * 0.5f);

        if (ImGui::Button(m_uppercase ? "SHIFT" : "shift", ImVec2(btnWidth, btnHeight))) {
            m_uppercase = !m_uppercase;
        }
        ImGui::SameLine();

        const char* row4Chars = "zxcvbnm";
        for (const char* c = row4Chars; *c; c++) {
            char buttonLabel[2] = { m_uppercase ? (char)std::toupper(*c) : *c, '\0' };
            if (ImGui::Button(buttonLabel, ImVec2(btnWidth, btnHeight))) {
                TypeCharacter(buttonLabel[0]);
            }
            ImGui::SameLine();
        }

        if (ImGui::Button("DEL", ImVec2(btnWidth, btnHeight))) {
            Backspace();
        }

        float commaWidth = windowWidth * 0.12f;
        float spaceWidth = windowWidth * 0.50f;
        float dotWidth = windowWidth * 0.12f;
        float bottomRowTotal = commaWidth + spaceWidth + dotWidth + 10.0f;
        ImGui::SetCursorPosX((windowWidth - bottomRowTotal) * 0.5f);

        if (ImGui::Button(",", ImVec2(commaWidth, btnHeight))) TypeCharacter(',');
        ImGui::SameLine();
        if (ImGui::Button("SPACE", ImVec2(spaceWidth, btnHeight))) TypeCharacter(' ');
        ImGui::SameLine();
        if (ImGui::Button(".", ImVec2(dotWidth, btnHeight))) TypeCharacter('.');

        ImGui::SetWindowFontScale(1.0f);
        ImGui::PopStyleColor(3);
        ImGui::PopStyleVar(3);
    }

    void TypeCharacter(char c) {
        if (!m_targetBuffer) return;
        size_t len = strlen(m_targetBuffer);
        if (len < m_bufferSize - 1) {
            m_targetBuffer[len] = c;
            m_targetBuffer[len + 1] = '\0';
        }
    }

    void Backspace() {
        if (!m_targetBuffer) return;
        size_t len = strlen(m_targetBuffer);
        if (len > 0) m_targetBuffer[len - 1] = '\0';
    }
};

static VirtualKeyboard g_VirtualKeyboard;

class SkinSearch {
private:
    char m_searchBuffer[256] = "";

public:
    void RenderSearchBar() {
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.1f, 0.1f, 0.1f, 0.8f));
        ImGui::InputTextWithHint("##SkinSearch", "Search skins...", m_searchBuffer, sizeof(m_searchBuffer));
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
    }
    
    void ClearSearch() {
        m_searchBuffer[0] = '\0';
    }

    const char* GetSearchQuery() const {
        return m_searchBuffer;
    }

    bool IsSearching() const {
        return m_searchBuffer[0] != '\0';
    }

    bool MatchesSearch(const std::string& itemName) const {
        if (!IsSearching()) return true;
        std::string searchLower = ToLower(m_searchBuffer);
        std::string itemLower = ToLower(itemName);
        return itemLower.find(searchLower) != std::string::npos;
    }
};

static SkinSearch g_SkinSearch;