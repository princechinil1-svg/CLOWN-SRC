#pragma once

extern float jumpHeightMultiplier;
extern bool SnowB;
extern float SnowBsize;
extern bool isSpeedHackEnabled;
extern float speedHackMultiplier;
extern bool isJumpAdjustmentEnabled;

float ( *orig_GetAssistAimSpeed)(void * instance, Vector3 assistCentorPos, float assistDis, float dis, float angle, bool isPVE, bool gamepadInput);
float GetAssistAimSpeed(void * instance, Vector3 assistCentorPos, float assistDis, float dis, float angle, bool isPVE, bool gamepadInput) {
    if (instance != NULL) {
        if (Config.Aim.AimAssist) {
            return (float)Config.Aim.AimAssistSize;
        }
    }
    return orig_GetAssistAimSpeed(instance, assistCentorPos, assistDis, dis, angle, isPVE, gamepadInput);
}

float ( *orig_GetScaleRecoil)(void * instance);
float GetScaleRecoil(void * instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Recoil) {
            return 0.0001;
        }
    }
    return orig_GetScaleRecoil(instance);
}

float ( *orig_GetRealSpreadModifier)(void * instance);
float GetRealSpreadModifier(void * instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Spread) {
            return 0.0001;
        }
    }
    return orig_GetRealSpreadModifier(instance);
}


float ( *orig_get_ChangeClipTime)(void *instance);
float get_ChangeClipTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Reload) {
            return 0.1f;
        }
    }
    return orig_get_ChangeClipTime(instance);
}

float ( *orig_get_ChangeClipLoopTime)(void *instance);
float get_ChangeClipLoopTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Reload) {
            return 0.1f;
        }
    }
    return orig_get_ChangeClipLoopTime(instance);
}

bool (*orig_UpdateCameraShake)(void *instance);
bool UpdateCameraShake(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Shake) {
             return true;
        }
    }
    return orig_UpdateCameraShake(instance);
}

bool (*orig_IsUnlocked)(void *instance);
bool IsUnlocked(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Blueprints) {
            return true;
        }
    }
    return orig_IsUnlocked(instance);
}

float ( *orig_get_AimingTime)(void *instance);
float get_AimingTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Scope) {
            return 0.1f;
        }
    }
    return orig_get_AimingTime(instance);
}

float ( *orig_BRUseItemArmorPlate_SetUseItemTime)(void *instance);
float hook_BRUseItemArmorPlate_SetUseItemTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Medicine) {
            return 0.6f;
        }
    }
    return orig_BRUseItemArmorPlate_SetUseItemTime(instance);
}

float ( *orig_get_EquipTime)(void *instance);
float get_EquipTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Switch) {
            return 0.6f;
        }
    }
    return orig_get_EquipTime(instance);
}

float ( *orig_get_UnequipTime)(void *instance);
float get_UnequipTime(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Switch) {
            return 0.6f;
        }
    }
    return orig_get_UnequipTime(instance);
}

static bool bIsEmulator = false;
bool IsEmulator(){
	return bIsEmulator;
}

int (*orig_get_ShotCost)(void *instance);
int get_ShotCost(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Cost) {
            return 0;
        }
    }
    return orig_get_ShotCost(instance);
}

float ( *orig_OverHeat)(void *instance);
float OverHeat(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Over) {
            return 0.000001f;
        }
    }
    return orig_OverHeat(instance);
}

void ( *orig_OnFlashBangExplode)(void *instance, int weaponItemID, float whiteTime, float whiteAlphaTime, float initIntensity);
void OnFlashBangExplode(void *instance, int weaponItemID, float whiteTime, float whiteAlphaTime, float initIntensity) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Flash) {
            return (void) false;
        }
    }
    return orig_OnFlashBangExplode(instance, weaponItemID, whiteTime, whiteAlphaTime, initIntensity);
}

bool ( *orig_SingleLineCheckPhysics)(void *instance, int hitType, void *hitTarget, void *hitCollider, Vector3 startPos, Vector3 dir, void *impactInfo);
bool SingleLineCheckPhysics(void *instance, int hitType, void *hitTarget, void *hitCollider, Vector3 startPos, Vector3 dir, void *impactInfo) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Hit) {
            return true;
        }
    }
    return orig_SingleLineCheckPhysics(instance, hitType, hitTarget, hitCollider, startPos, dir, impactInfo);
}

bool ( *orig_IsAimTargetCanAutoFire)(void *instance, void *weap);
bool IsAimTargetCanAutoFire(void *instance, void *weap) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Auto) {
            return true;
        }
    }
    return orig_IsAimTargetCanAutoFire(instance, weap);
}

bool (*orig_AdvanceUAV)(void *instance);
bool getAdvanceUAV(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Radar1) {
            return true;
        }
    }
    return orig_AdvanceUAV(instance);
}

void ( *orig_OpenParachute)(void *instance, bool isAuto);
void OpenParachute(void *instance, bool isAuto) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Parachute) {
            return (void) true;
        }
    }
    return orig_OpenParachute(instance, isAuto);
}

float (*orig_get_AccelerationForwardSpeedUp)(void *instance);
float get_AccelerationForwardSpeedUp(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Diving) {
            return 176.0f;

        }
    }
    return orig_get_AccelerationForwardSpeedUp(instance);
}

float (*orig_get_MaxVelocityForwardSpeedUp)(void *instance);
float get_MaxVelocityForwardSpeedUp(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Diving) {
            return 176.0f;

        }
    }
    return orig_get_MaxVelocityForwardSpeedUp(instance);
}

float (*orig_GetMaxJumpHeight)(void *);
float hook_GetMaxJumpHeight(void *instance) {
    float orig_ = orig_GetMaxJumpHeight(instance);
    return isJumpAdjustmentEnabled ? orig_ * jumpHeightMultiplier : orig_;
}


float (*o_GetSuperSlideRate)(void *ins);
float h_GetSuperSlideRate(void *ins) {
    if (SlideTackle) {
        return SlideRange + 256;
    }

    return o_GetSuperSlideRate(ins);
}

float (*o_get_SlideTackleAccelerationSpeed)(void *ins);
float h_get_SlideTackleAccelerationSpeed(void *ins) {
    if (SlideTackle) {
        return SlideRange + 1;
    }

    return o_get_SlideTackleAccelerationSpeed(ins);
}

float (*o_PawnGetMaxSpeed)(void *ins);
float h_PawnGetMaxSpeed(void *ins) {
    if (SlideTackle) {
        return SlideRange + 256;
    }

    return o_PawnGetMaxSpeed(ins);
}

void (*o_TickLocalPlayer)(void *ins, float deltaTime);
void h_TickLocalPlayer(void *ins, float deltaTime) {
    if (!SlideTackle) {
        o_TickLocalPlayer(ins, deltaTime);
    }
}

float (*o_get_SlideTackleSpeed)(void *ins);
float h_get_SlideTackleSpeed(void *ins) {
    if (SlideTackle) {
        return SlideRange;
    }

    return o_get_SlideTackleSpeed(ins);
}

float ( *orig_GetWeaponMoveScale)(void *instance);
float GetWeaponMoveScale(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Speed) {
            return 2.0f;
        }
    }
    return orig_GetWeaponMoveScale(instance);
}


bool (*orig_IsWidgetVisible)(void *instance, void *rec);
bool IsWidgetVisible(void *instance, void *rect) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Fps) {
            return true;
        }
    }
    return orig_IsWidgetVisible(instance, rect);
}



int (*orig_get_DeviceCapacityLevel)(void *instance);
int get_DeviceCapacityLevel(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Grap) {
            return 6;
        }
    }
    return orig_get_DeviceCapacityLevel(instance);
}


bool ( *orig_SameTeamFromPawn)(void *instance, void *pawn1, void *pawn2);
bool SameTeamFromPawn(void *instance, void *pawn1, void *pawn2) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Radar2) {
            return true;
        }
    }
    return orig_SameTeamFromPawn(instance, pawn1, pawn2);
}

bool (*orig_CheckTargetIsValid_DyingInAzurGameMode)(void* instance, void* targetPawn);
bool CheckTargetIsValid_DyingInAzurGameMode_Hook(void* instance, void* targetPawn) {
    if (instance != nullptr && targetPawn != nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return orig_CheckTargetIsValid_DyingInAzurGameMode(instance, targetPawn);
}

bool (*orig_CheckTargetIsValid_PhysState)(void* instance, void* targetPawn);
bool CheckTargetIsValid_PhysState_Hook(void* instance, void* targetPawn) {
    if (instance != nullptr && targetPawn != nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return orig_CheckTargetIsValid_PhysState(instance, targetPawn);
}

bool (*orig_CheckTargetIsValid_ManualParameter)(void* instance, void* tempPawn, float* distance);
bool CheckTargetIsValid_ManualParameter_Hook(void* instance, void* tempPawn, float* distance) {
    if (instance != nullptr && tempPawn != nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return orig_CheckTargetIsValid_ManualParameter(instance, tempPawn, distance);
}

bool (*orig_CheckTargetIsValid_Ult)(void* instance, void* targetPawn);
bool CheckTargetIsValid_Ult_Hook(void* instance, void* targetPawn) {
    if (instance != nullptr && targetPawn != nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return orig_CheckTargetIsValid_Ult(instance, targetPawn);
}

bool (*orig_CalculateObstacleSide)(void* instance, float* backDis, float* beforeDis);
bool CalculateObstacleSide_Hook(void* instance, float* backDis, float* beforeDis) {
    if (instance != nullptr) {
        if (isExecute) {
            return false;
        }
    }
    return orig_CalculateObstacleSide(instance, backDis, beforeDis);
}

bool (*orig_CalculateObstacleTop)(void* instance, Vector3 pawnPos);
bool CalculateObstacleTop_Hook(void* instance, Vector3 pawnPos) {
    if (instance != nullptr) {
        if (isExecute) {
            return false;
        }
    }
    return orig_CalculateObstacleTop(instance, pawnPos);
}

int (*oCheckTargetIsValid)(void *ins, void* tempPawn, float distance);
int CheckTargetIsValid(void *ins, void* tempPawn, float distance) {
    if ( ins != nullptr ) {
        if (isExecute) {
            return (int)true;
        }
    }
    return oCheckTargetIsValid(ins, tempPawn, distance);
}

bool (*oCheckCanExcution_Extra)(void *ins);
bool CheckCanExcution_Extra(void *ins) {
    if ( ins != nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return oCheckCanExcution_Extra(ins);
}

bool (*orig_IsInEM3Eye)(void *instance);
bool get_IsInEM3Eye(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.RedWallhack) {
            return true;
        }
    }
    return orig_IsInEM3Eye(instance);
}

float (*orig_GetAccDistance)(void *instance);
float GetAccDistance(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.RedWallhack) {
            return Config.ExtraMenu.RedWallhackDistance;
        }
    }
    return orig_GetAccDistance(instance);
}

bool (*o_CheckExecution_ObstacleAround)(void *ins);
bool CheckExecution_ObstacleAround(void *ins) {
    if (ins!=nullptr) {
        if (isExecute) {
            return true;
        }
    }
    return o_CheckExecution_ObstacleAround(ins);
}

float (*get_m_PhysSkisMaxSpeed)(void* instance);
float hooked_get_m_PhysSkisMaxSpeed(void* instance) {
    if (SnowB) {
        return SnowBsize;
    }
    return get_m_PhysSkisMaxSpeed(instance);

}


float (*original_CalcFinalMoveScale)(void* instance);
float hooked_CalcFinalMoveScale(void* instance) {
    if (instance == nullptr) {
        return original_CalcFinalMoveScale(instance);
    }

    if (isSpeedHackEnabled) {
        if (speedHackMultiplier > 0.0f && speedHackMultiplier <= 100.0f) {
            return speedHackMultiplier;
        }
    }

    return original_CalcFinalMoveScale(instance);
}

 int (*original_Fpslevel)(void*) = nullptr;
 int hooked_Fpslevel(void* ins) {
    return (ins && Config.ExtraMenu.EnhanceFPS) ? 7 : original_Fpslevel(ins);
}

 int (*original_Fpslevel1)(void*) = nullptr;
 int hooked_Fpslevel1(void* ins) {
    return (ins && Config.ExtraMenu.EnhanceFPS) ? 7 : original_Fpslevel1(ins);
}

 int (*orig_GetFrameRateValue)(void*, int, int) = nullptr;
 int GetFrameRateValue(void* ins, int f, int m) {
    if (ins) {
        return 360;
    }
    return orig_GetFrameRateValue(ins, f, m);
}

 int (*orig_GetUltraFrameRateFinalFPS)(void*) = nullptr;
 int GetUltraFrameRateFinalFPS(void* g) {
    return (g && Config.ExtraMenu.EnhanceFPS) ? 360 : orig_GetUltraFrameRateFinalFPS(g);
}

inline bool (*original_Extremequality)(void*) = nullptr;
inline bool hooked_Extremequality(void* ins) {
    return (ins && Config.ExtraMenu.EnhanceFPS) ? true : original_Extremequality(ins);
}


uintptr_t btrack1 = 0xC9B6F90;
uintptr_t btrack2 = 0xC9C33A4;

void NotaFeats() {
    MemoryPatch::createWithHex("libunity.so", 0x9FEC8AC, "00 00 80 D2 C0 03 5F D6").Modify();
    MemoryPatch::createWithHex("libunity.so", 0x9FEC9D0, "00 00 80 D2 C0 03 5F D6").Modify();
    MemoryPatch::createWithHex("libunity.so", 0x5755800, "00 00 80 D2 C0 03 5F D6").Modify();
    
    Patches.chute = MemoryPatch::createWithHex("libunity.so", 0x5DC662C, "00 00 80 D2 C0 03 5F D6");
    Patches.wing = MemoryPatch::createWithHex("libunity.so", 0x54A12F4, "00 00 80 D2 C0 03 5F D6");
    Patches.A1 = MemoryPatch::createWithHex("libunity.so", 0x8D781DC, "1F 20 03 D5 E0 03 13 AA");

    HOOK_LIB("libunity.so", "0x9677554", get_IsInEM3Eye, orig_IsInEM3Eye); 
    HOOK_LIB("libunity.so", "0x5074810", GetAccDistance, orig_GetAccDistance);
    HOOK_LIB("libunity.so", "0x5DE981C", get_AccelerationForwardSpeedUp, orig_get_AccelerationForwardSpeedUp);
    HOOK_LIB("libunity.so", "0x5DE9880", get_MaxVelocityForwardSpeedUp, orig_get_MaxVelocityForwardSpeedUp);
    HOOK_LIB("libunity.so", "0x5B0E56C", getAdvanceUAV, orig_AdvanceUAV);
    HOOK_LIB("libunity.so", "0xC9BAFF8", GetScaleRecoil, orig_GetScaleRecoil);
    HOOK_LIB("libunity.so", "0xC1514C0", SingleLineCheckPhysics, orig_SingleLineCheckPhysics);
    HOOK_LIB("libunity.so", "0x50ED8D4", get_EquipTime, orig_get_EquipTime);
    HOOK_LIB("libunity.so", "0x4ED49A4", get_AimingTime, orig_get_AimingTime);
    HOOK_LIB("libunity.so", "0x666FD90", GetAssistAimSpeed, orig_GetAssistAimSpeed);
    HOOK_LIB("libunity.so", "0x50ECADC", get_ChangeClipTime, orig_get_ChangeClipTime);
    HOOK_LIB("libunity.so", "0xC9B9618", GetRealSpreadModifier, orig_GetRealSpreadModifier);
    HOOK_LIB("libunity.so", "0x522860C", hooked_get_m_PhysSkisMaxSpeed, get_m_PhysSkisMaxSpeed);
    HOOK_LIB("libunity.so", "0x901F988", IsUnlocked, orig_IsUnlocked);
    
    HOOK_LIB("libunity.so", "0x9FE01CC", GetFrameRateValue, orig_GetFrameRateValue);
    HOOK_LIB("libunity.so", "0x9FDFBBC", GetUltraFrameRateFinalFPS, orig_GetUltraFrameRateFinalFPS);
    HOOK_LIB("libunity.so", "0x9FDFC58", hooked_Fpslevel, original_Fpslevel);
    HOOK_LIB("libunity.so", "0x9FDFC58", hooked_Fpslevel1, original_Fpslevel1);
    HOOK_LIB("libunity.so", "0x9FE3FB4", hooked_Extremequality, original_Extremequality);
	
    DobbyHook((void *) getAbsoluteAddress("libunity.so", btrack1), (void *)  &WeaponFireComponent_Instant_CreateBulletLine, (void **) &oWeaponFireComponent_Instant_CreateBulletLine); 
DobbyHook((void *) getAbsoluteAddress("libunity.so", btrack2), (void *) &WeaponFireComponent_Instant_CreateBulletProjectile, (void **)&oWeaponFireComponent_Instant_CreateBulletProjectile);

    HOOK_LIB("libunity.so", "0x93CEF00", hook_BRUseItemArmorPlate_SetUseItemTime, orig_BRUseItemArmorPlate_SetUseItemTime);

    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0xA057F8C, "20 00 80 D2 C0 03 5F D6");
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0xA057FE8, "20 00 80 D2 C0 03 5F D6");
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x9FE3C80, "20 00 80 D2 C0 03 5F D6");
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x9FE97A0, "20 00 80 D2 C0 03 5F D6");    
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x9FE98B4, "20 00 80 D2 C0 03 5F D6");    
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x7518A24, "20 00 80 D2 C0 03 5F D6");    
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x9FE98FC, "20 00 80 D2 C0 03 5F D6");    
    Patches.grap = MemoryPatch::createWithHex("libunity.so", 0x9FE9644, "20 00 80 D2 C0 03 5F D6");
	
    
    DobbyHook((void*) getAbsoluteAddress("libunity.so", 0x9FDEE28), (void*)&hooked_SetUltraFrameRateDeviceInfo, (void**)&orig_SetUltraFrameRateDeviceInfo);
    Patches.autosnipe = MemoryPatch::createWithHex("libunity.so",0x50EBA5C,"20 00 80 D2 C0 03 5F D6");
    Patches.kinetic = MemoryPatch::createWithHex("libunity.so",0x51B3D64,"20 00 80 D2 C0 03 5F D6");
    Patches.jetj = MemoryPatch::createWithHex("libunity.so",0x907D498,"20 00 80 D2 C0 03 5F D6");
    Patches.jets = MemoryPatch::createWithHex("libunity.so",0x9086B5C,"20 00 80 D2 C0 03 5F D6");
    Patches.revive = MemoryPatch::createWithHex("libunity.so",0x9681C20,"00 00 80 D2 C0 03 5F D6");
    Patches.revive = MemoryPatch::createWithHex("libunity.so",0x9687BEC,"20 00 80 D2 C0 03 5F D6");
    Patches.rpd = MemoryPatch::createWithHex("libunity.so",0xC14B314, "00 2C 40 BC C0 03 5F D6");
    Patches.fpss = MemoryPatch::createWithHex("libunity.so",0x9FDFDDC,"00 24 80 D2 C0 03 5F D6");
    Patches.fpss = MemoryPatch::createWithHex("libunity.so",0x9FDFDD4,"00 24 80 D2 C0 03 5F D6"); 
    Patches.cost = MemoryPatch::createWithHex("libunity.so",0x50EC794,"00 00 80 D2 C0 03 5F D6");
    Patches.outline = MemoryPatch::createWithHex("libunity.so",0xA02067C,"20 00 80 D2 C0 03 5F D6");
    Patches.outline = MemoryPatch::createWithHex("libunity.so",0x649F084,"20 00 80 D2 C0 03 5F D6");
    Patches.range = MemoryPatch::createWithHex("libunity.so",0x50EE1F8,"20 00 80 D2 C0 03 5F D6");
    
    HOOK_LIB("libunity.so", "0x5947970", CheckTargetIsValid_DyingInAzurGameMode_Hook, orig_CheckTargetIsValid_DyingInAzurGameMode);
    HOOK_LIB("libunity.so", "0x5947A24", CheckTargetIsValid_PhysState_Hook, orig_CheckTargetIsValid_PhysState);
    HOOK_LIB("libunity.so", "0x5947C18", CheckTargetIsValid_ManualParameter_Hook, orig_CheckTargetIsValid_ManualParameter);
    HOOK_LIB("libunity.so", "0x5947F1C", CheckTargetIsValid_Ult_Hook, orig_CheckTargetIsValid_Ult);
    HOOK_LIB("libunity.so", "0x5221D00", hook_GetMaxJumpHeight, orig_GetMaxJumpHeight);
    HOOK_LIB_NO_ORIG("libunity.so", "0xAE24334", IsEmulator);
//    HOOK_LIB("libunity.so", "0xC9B6F90", WeaponFireComponent_Instant_CreateBulletLine, oWeaponFireComponent_Instant_CreateBulletLine);
        //-- Long Slide
    HOOK_LIB("libunity.so", "0xA140D20", h_get_SlideTackleAccelerationSpeed, o_get_SlideTackleAccelerationSpeed);
    HOOK_LIB("libunity.so", "0xC2E3374", h_PawnGetMaxSpeed, o_PawnGetMaxSpeed);
    HOOK_LIB("libunity.so", "0x8BF71F0", h_get_SlideTackleSpeed, o_get_SlideTackleSpeed);
    HOOK_LIB("libunity.so", "0x8BF62D4", h_GetSuperSlideRate, o_GetSuperSlideRate);
    HOOK_LIB("libunity.so", "0x8BF7E48", h_TickLocalPlayer, o_TickLocalPlayer);
}
