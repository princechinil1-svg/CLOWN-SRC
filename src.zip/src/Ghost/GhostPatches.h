#pragma once

struct My_Patches
{
    MemoryPatch
    A1, rpd, grap, smk, Waller, chute, wing, tutorial, cost, red, jets, jetj, fire, fpss, frame, revive, outline, range, kinetic, autosnipe;

} Patches;