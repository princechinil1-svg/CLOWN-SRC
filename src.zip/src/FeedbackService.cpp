#include "FeedbackService.h"

#include <GLES2/gl2.h>
#include <curl/curl.h>
#include <sys/system_properties.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <ctime>
#include <cctype>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <thread>
#include <vector>

#ifndef STBI_INCLUDE_STB_IMAGE_WRITE_H
#define STBI_INCLUDE_STB_IMAGE_WRITE_H
#define STB_IMAGE_WRITE_STATIC 
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h" 
#endif

extern int g_TotalMatches;
extern std::chrono::steady_clock::time_point appStartTime;
extern int lastMatchResult;

namespace {

constexpr const char* kLogTag = "GhostFeedback";
const char* kHardcodedFeedbackBotToken = "8828197857:AAH_8zXpqmvmrvC39B2VafoZ8Y7E_Lz0slU"; // bot api
const char* kHardcodedFeedbackChatId = "@Gh0stPhHax"; //bot channel mo na admin dapat Ang bot mo, I add mo sa channel mo boy tapos make mo syang admin para dun nya isendzz

FeedbackState g_FeedbackState;
std::mutex g_FeedbackStatusMutex;
std::string g_FeedbackStatus = "Idle";
bool g_FeedbackStatusIsError = false;
std::atomic<bool> g_FeedbackSending{false};

std::mutex g_PendingCaptureMutex;
bool g_HasPendingCapture = false;
FeedbackState g_PendingCaptureSnapshot;
std::string g_PendingCaptureFilesDirPath;

std::string GetAndroidSystemProp(const char* key) {
    char value[PROP_VALUE_MAX] = {};
    __system_property_get(key, value);
    return (value[0] != '\0') ? std::string(value) : "Unknown";
}

std::string GetDeviceModel() {
    return GetAndroidSystemProp("ro.product.brand") + " " + GetAndroidSystemProp("ro.product.model");
}

bool IsUnknownPropValue(const std::string& value) {
    return value.empty() || value == "Unknown" || value == "unknown";
}

std::string NormalizeRegionValue(const std::string& value) {
    if (IsUnknownPropValue(value)) return "";
    std::string token = value;
    const size_t comma = token.find(',');
    if (comma != std::string::npos) token = token.substr(0, comma);
    const size_t separator = token.find_last_of("-_");
    if (separator != std::string::npos && separator + 1 < token.size()) {
        token = token.substr(separator + 1);
    }
    std::string normalized;
    normalized.reserve(token.size());
    for (unsigned char ch : token) {
        if (std::isalpha(ch)) normalized.push_back(static_cast<char>(std::toupper(ch)));
    }
    return normalized.size() >= 2 ? normalized : "";
}

std::string GetDeviceRegion() {
    static const char* kRegionProps[] = {
        "gsm.operator.iso-country", "ro.miui.region", "persist.sys.country",
        "persist.sys.locale.country", "ro.product.locale.region", "persist.sys.locale", "ro.config.locale"
    };
    for (const char* key : kRegionProps) {
        const std::string region = NormalizeRegionValue(GetAndroidSystemProp(key));
        if (!region.empty()) return region;
    }
    return "Unknown";
}

std::string GetFormattedPlaytime() {
    const auto currentDuration = std::chrono::steady_clock::now() - appStartTime;
    const auto totalSeconds = std::chrono::duration_cast<std::chrono::seconds>(currentDuration).count();
    const long hours = totalSeconds / 3600;
    const long minutes = (totalSeconds % 3600) / 60;
    const long seconds = totalSeconds % 60;
    char buf[64] = {};
    snprintf(buf, sizeof(buf), "%ldh %ldm %lds", hours, minutes, seconds);
    return std::string(buf);
}

bool EnsureCurlInitialized(std::string* errorOut = nullptr) {
    static std::once_flag once;
    static bool initialized = false;
    static CURLcode initCode = CURLE_OK;
    std::call_once(once, []() {
        initCode = curl_global_init(CURL_GLOBAL_DEFAULT);
        initialized = (initCode == CURLE_OK);
    });
    if (!initialized && errorOut) {
        *errorOut = std::string("curl_global_init failed: ") + curl_easy_strerror(initCode);
    }
    return initialized;
}

void SetFeedbackStatus(const std::string& text, bool isError = false) {
    std::lock_guard<std::mutex> lock(g_FeedbackStatusMutex);
    g_FeedbackStatus = text;
    g_FeedbackStatusIsError = isError;
    __android_log_print(isError ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO, kLogTag, "%s", text.c_str());
}

size_t FeedbackWriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    const size_t total = size * nmemb;
    if (!contents || !userp || total == 0) return 0;
    reinterpret_cast<std::string*>(userp)->append(reinterpret_cast<const char*>(contents), total);
    return total;
}

bool CaptureFeedbackScreenshotJPG(const std::string& savePath, std::string* errorOut) {
    GLint viewport[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, viewport);

    const int width  = viewport[2];
    const int height = viewport[3];

    if (width <= 0 || height <= 0) {
        if (errorOut) *errorOut = "Invalid viewport size";
        return false;
    }

    const size_t rowBytes =
        static_cast<size_t>(width) * 4u;

    const size_t imageBytes =
        static_cast<size_t>(width) *
        static_cast<size_t>(height) * 4u;

    std::vector<unsigned char> pixels(imageBytes);

    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glFinish();

    glReadPixels(
        0,
        0,
        width,
        height,
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        pixels.data()
    );

    if (glGetError() != GL_NO_ERROR) {
        if (errorOut) *errorOut = "glReadPixels failed";
        return false;
    }

    // OpenGL framebuffer is bottom-to-top; convert it to normal top-to-bottom.
    std::vector<unsigned char> image(imageBytes);

    for (int y = 0; y < height; ++y) {
        const int srcY = height - y - 1;

        memcpy(
            image.data() + static_cast<size_t>(y) * rowBytes,
            pixels.data() + static_cast<size_t>(srcY) * rowBytes,
            rowBytes
        );
    }

    /*
     * ==========================================================
     * PRIVACY BLUR - NAME/RECOMMENDATION AREA ONLY
     * ==========================================================
     *
     * Only the small lower-center nameplate/recommendation area
     * is blurred. The rest of the screenshot remains untouched.
     */

    const float blurWidthPercent  = 0.35f;  // narrower = less area blurred
    const float blurHeightPercent = 0.0100f;
    const float blurTopPercent = 0.716f;

    const int blurWidth = std::max(
        80, static_cast<int>(width * blurWidthPercent));

    const int blurHeight = std::max(
        24, static_cast<int>(height * blurHeightPercent));

    int blurLeft = (width - blurWidth) / 2;
    int blurTop  = static_cast<int>(height * blurTopPercent);

    int blurRight = std::min(width, blurLeft + blurWidth);
    int blurBottom = std::min(height, blurTop + blurHeight);

    blurLeft   = std::max(0, blurLeft);
    blurTop    = std::max(0, blurTop);
    blurRight  = std::max(blurLeft + 1, blurRight);
    blurBottom = std::max(blurTop + 1, blurBottom);

    // Strong enough to make the name unreadable while keeping the
    // blur confined to the selected rectangle.
    const int radius = std::max(
        6,
        std::min(14, std::min(width, height) / 80));

    // Horizontal blur pass.
    std::vector<unsigned char> temp = image;

    for (int y = blurTop; y < blurBottom; ++y) {
        for (int x = blurLeft; x < blurRight; ++x) {
            long r = 0, g = 0, b = 0, a = 0;
            int count = 0;

            const int startX = std::max(blurLeft, x - radius);
            const int endX   = std::min(blurRight - 1, x + radius);

            for (int sx = startX; sx <= endX; ++sx) {
                const size_t index =
                    (static_cast<size_t>(y) * static_cast<size_t>(width) +
                     static_cast<size_t>(sx)) * 4u;

                r += image[index + 0];
                g += image[index + 1];
                b += image[index + 2];
                a += image[index + 3];
                ++count;
            }

            const size_t dst =
                (static_cast<size_t>(y) * static_cast<size_t>(width) +
                 static_cast<size_t>(x)) * 4u;

            temp[dst + 0] = static_cast<unsigned char>(r / count);
            temp[dst + 1] = static_cast<unsigned char>(g / count);
            temp[dst + 2] = static_cast<unsigned char>(b / count);
            temp[dst + 3] = static_cast<unsigned char>(a / count);
        }
    }

    // Vertical blur pass.
    image.swap(temp);

    for (int y = blurTop; y < blurBottom; ++y) {
        for (int x = blurLeft; x < blurRight; ++x) {
            long r = 0, g = 0, b = 0, a = 0;
            int count = 0;

            const int startY = std::max(blurTop, y - radius);
            const int endY   = std::min(blurBottom - 1, y + radius);

            for (int sy = startY; sy <= endY; ++sy) {
                const size_t index =
                    (static_cast<size_t>(sy) * static_cast<size_t>(width) +
                     static_cast<size_t>(x)) * 4u;

                r += temp[index + 0];
                g += temp[index + 1];
                b += temp[index + 2];
                a += temp[index + 3];
                ++count;
            }

            const size_t dst =
                (static_cast<size_t>(y) * static_cast<size_t>(width) +
                 static_cast<size_t>(x)) * 4u;

            image[dst + 0] = static_cast<unsigned char>(r / count);
            image[dst + 1] = static_cast<unsigned char>(g / count);
            image[dst + 2] = static_cast<unsigned char>(b / count);
            image[dst + 3] = static_cast<unsigned char>(a / count);
        }
    }

    if (!stbi_write_jpg(
            savePath.c_str(),
            width,
            height,
            4,
            image.data(),
            80)) {

        if (errorOut)
            *errorOut = "stbi_write_jpg failed to save";

        return false;
    }

    return true;
}

bool SendTelegramPhoto(const std::string& token, const std::string& chatId, const std::string& filePath, const std::string& caption, std::string* errorOut) {
    if (!EnsureCurlInitialized(errorOut)) return false;

    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open()) {
        if (errorOut) *errorOut = "Unable to open screenshot file";
        return false;
    }

    const std::string fileContent((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();
    if (fileContent.empty()) {
        if (errorOut) *errorOut = "Screenshot file is empty";
        return false;
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        if (errorOut) *errorOut = "curl_easy_init failed";
        return false;
    }

    std::string response;
    const std::string url = "https://api.telegram.org/bot" + token + "/sendPhoto";
    const std::string boundary = "----AstralBoundary7MA4YWxkTrZu0gW";

    std::string body;
    body.reserve(fileContent.size() + 1024);
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n";
    body += chatId + "\r\n";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"caption\"\r\n\r\n";
    body += caption + "\r\n";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"parse_mode\"\r\n\r\n";
    body += "HTML\r\n"; // Finix para gumana ang html formatting tags mo (<b>, <code>)
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"photo\"; filename=\"feedback.jpg\"\r\n";
    body += "Content-Type: image/jpeg\r\n\r\n";
    body.append(fileContent.data(), fileContent.size());
    body += "\r\n--" + boundary + "--\r\n";

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, ("Content-Type: multipart/form-data; boundary=" + boundary).c_str());

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, FeedbackWriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    const CURLcode res = curl_easy_perform(curl);
    long statusCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &statusCode);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        if (errorOut) *errorOut = curl_easy_strerror(res);
        return false;
    }
    if (statusCode != 200 || response.find("\"ok\":true") == std::string::npos) {
        if (errorOut) *errorOut = response.empty() ? "Telegram API error" : response;
        return false;
    }
    return true;
}


std::string BuildFeedbackPayload(const FeedbackState& snapshot) {
    const std::string device = GetDeviceModel();
    const std::string playtime = GetFormattedPlaytime();

    std::time_t now = std::time(nullptr);
    std::tm localTime{};
#if defined(_WIN32)
    localtime_s(&localTime, &now);
#else
    localtime_r(&now, &localTime);
#endif

    char dateBuffer[64]{};
    std::strftime(dateBuffer, sizeof(dateBuffer),
                   "%B %d, %Y | %I:%M %p", &localTime);

    std::ostringstream oss;
    oss << "<b>GH0ST ECLIPSE FEEDBACK</b>\n\n";
    oss << "<b>Play Time:</b> <b>" << playtime << "</b>\n";
    oss << "<b>Model:</b> <b>" << device << "</b>\n";
    oss << "<b>Version:</b> <b>1.6.57</b>\n\n";
    oss << "<b>Date:</b> <b>" << dateBuffer << "</b>\n";
    oss << "<b>Avail Key:</b> <b>@Gh0stPh</b>\n";

    return oss.str();
}

void LaunchSendWorker(const FeedbackState& snapshot, const std::string& screenshotPath, const std::string& screenshotWarning) {
    std::thread([snapshot, screenshotPath, screenshotWarning]() {
        std::string error;

        std::string token(snapshot.botToken);
        if (token.empty() && kHardcodedFeedbackBotToken[0] != '\0') {
            token = kHardcodedFeedbackBotToken;
        }
        std::string chat(snapshot.chatId);
        if (chat.empty() && kHardcodedFeedbackChatId[0] != '\0') {
            chat = kHardcodedFeedbackChatId;
        }

        const bool hasScreenshot = !screenshotPath.empty();
        const std::string payload = BuildFeedbackPayload(snapshot);
        
        bool ok = false;
        if (hasScreenshot) {
            ok = SendTelegramPhoto(token, chat, screenshotPath, payload, &error);
        }

        if (!ok) {
            SetFeedbackStatus("Send failed: " + error, true);
        } else {
            SetFeedbackStatus("Feedback auto-sent successfully.", false);
        }
        g_FeedbackSending.store(false);
    }).detach();
}

}

namespace feedback {

FeedbackState& State() {
    return g_FeedbackState;
}

bool HasHardcodedBotToken() { return kHardcodedFeedbackBotToken[0] != '\0'; }
bool HasHardcodedChatId() { return kHardcodedFeedbackChatId[0] != '\0'; }
bool IsSending() { return g_FeedbackSending.load(); }

void GetStatus(std::string& outText, bool& outIsError) {
    std::lock_guard<std::mutex> lock(g_FeedbackStatusMutex);
    outText = g_FeedbackStatus;
    outIsError = g_FeedbackStatusIsError;
}


void StartSendAsync(const FeedbackState& snapshot, const std::string& filesDirPath) {
    if (g_FeedbackSending.exchange(true)) {
        return;
    }

    SetFeedbackStatus("Queuing stealth capture...", false);
    std::lock_guard<std::mutex> lock(g_PendingCaptureMutex);
    g_PendingCaptureSnapshot = snapshot;
    
    if(filesDirPath.empty()) {
        g_PendingCaptureFilesDirPath = "/storage/emulated/0/Android/data/com.garena.game.codm/files";
    } else {
        g_PendingCaptureFilesDirPath = filesDirPath;
    }
    g_HasPendingCapture = true;
}

void PumpAfterRender() {
    FeedbackState snapshot;
    std::string filesDirPath;
    {
        std::lock_guard<std::mutex> lock(g_PendingCaptureMutex);
        if (!g_HasPendingCapture) return;
        
        snapshot = g_PendingCaptureSnapshot;
        filesDirPath = g_PendingCaptureFilesDirPath;
        g_HasPendingCapture = false;
    }

    std::string screenshotPath = filesDirPath + "/feedback_capture.jpg";
    std::string error;
    
    if (!CaptureFeedbackScreenshotJPG(screenshotPath, &error)) {
        screenshotPath.clear();
    }

    LaunchSendWorker(snapshot, screenshotPath, error);
}

}
