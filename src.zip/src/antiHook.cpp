// language: C++17, file: antiHook.cpp, target: Android NDK arm64-v8a (API 24+), clang++
// Counters the exact chain of /proc-mem hook scanners: pid discovery, maps parse, mem-vs-disk diff —
// plus inline/PLT hook engines and injector frameworks. All checks run raw syscalls: a hooked libc can't lie to them.

#include <cstdint>
#include <cstddef>
#include <elf.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <netinet/in.h>

#include "AntiHook.h"   // fix: included before the static_assert so AH_EV_* codes exist

#ifndef ANTIHOOK_LIBNAME
#define ANTIHOOK_LIBNAME "libantihook.so"
#endif
#ifndef PTRACE_SEIZE
#define PTRACE_SEIZE 0x4206
#endif
#ifndef PR_SET_PTRACER
#define PR_SET_PTRACER 0x59616d61
#endif
#ifndef SOCK_CLOEXEC
#define SOCK_CLOEXEC 0x80000
#endif

namespace antihook {

// ─── raw syscall layer ──────────────────────────────────────────────────────
// Nothing below touches libc symbols: a PLT/GOT hook on open/read/memcmp can't silence our own checks.
static inline long sc(long n, long a = 0, long b = 0, long c = 0, long d = 0, long e = 0, long f = 0) {
    register long x8 __asm__("x8") = n;
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    register long x2 __asm__("x2") = c;
    register long x3 __asm__("x3") = d;
    register long x4 __asm__("x4") = e;
    register long x5 __asm__("x5") = f;
    __asm__ __volatile__("svc #0"
        : "+r"(x0)
        : "r"(x8), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5)
        : "memory", "cc");
    return x0;
}

// ─── libc-free helpers: loop implementations so the compiler can't swap them for hookable PLT calls ───
static size_t klen(const char* s) { size_t n = 0; while (s && s[n]) n++; return n; }
static bool keq(const char* a, const char* b, size_t n) { for (size_t i = 0; i < n; i++) if (a[i] != b[i]) return false; return true; }
static bool keqb(const uint8_t* a, const uint8_t* b, size_t n) { for (size_t i = 0; i < n; i++) if (a[i] != b[i]) return false; return true; }
static void kcpy(uint8_t* d, const uint8_t* s, size_t n) { for (size_t i = 0; i < n; i++) d[i] = s[i]; }
static void kzero(void* p, size_t n) { uint8_t* d = (uint8_t*)p; for (size_t i = 0; i < n; i++) d[i] = 0; }
static const char* kfind(const char* h, const char* n) {
    if (!h || !n) return nullptr;
    size_t m = klen(n); if (!m) return h;
    for (size_t i = 0; h[i]; i++) if (h[i] == n[0] && keq(h + i, n, m)) return h + i;
    return nullptr;
}
static bool kstart(const char* s, const char* p) { size_t n = klen(p); return keq(s, p, n); }
static bool kend(const char* s, const char* e) { size_t ls = klen(s), le = klen(e); return ls >= le && keq(s + ls - le, e, le); }
static bool kdig(const char* s) { return s[0] >= '0' && s[0] <= '9'; }
static long katol(const char* s) { long v = 0; while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; } return v; }
static size_t kdec(long v, char* out) {
    char t[24]; size_t n = 0;
    unsigned long u = (unsigned long)v;
    do { t[n++] = (char)('0' + (u % 10)); u /= 10; } while (u);
    size_t i = 0;
    while (n) out[i++] = t[--n];
    out[i] = 0; return i;
}
static size_t kjoin(char* out, const char* a, long v, const char* b) {
    size_t i = 0;
    for (; a[i]; ++i) out[i] = a[i];
    i += kdec(v, out + i);
    if (b) for (size_t j = 0; b[j]; ++j) out[i++] = b[j];
    out[i] = 0; return i;
}
static uintptr_t phex(const char*& p) {
    uintptr_t v = 0;
    for (;;) {
        char c = *p; int d;
        if (c >= '0' && c <= '9') d = c - '0';
        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        else break;
        v = v * 16 + (uintptr_t)d; p++;
    }
    return v;
}

static long read_file(const char* path, void* out, size_t cap) {
    long fd = sc(SYS_openat, AT_FDCWD, (long)path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    size_t tot = 0; uint8_t* o = (uint8_t*)out;
    while (tot < cap) {
        long r = sc(SYS_read, fd, (long)(o + tot), (long)(cap - tot));
        if (r <= 0) break;
        tot += (size_t)r;
    }
    sc(SYS_close, fd);
    return (long)tot;
}

static void sleep_ms(uint32_t ms) {
    timespec ts{ (time_t)(ms / 1000), (long)(ms % 1000) * 1000000L };
    sc(SYS_nanosleep, (long)&ts);
}

static inline uint64_t cntvct()  { uint64_t v; __asm__ __volatile__("mrs %0, cntvct_el0"  : "=r"(v)); return v; }
static inline uint64_t cntfrq()  { uint64_t v; __asm__ __volatile__("mrs %0, cntfrq_el0"  : "=r"(v)); return v; }

static uint64_t g_rng;
static uint64_t g_step_ticks = 0;   // fix: declared before first use in init()/ah_guard_exit

static void rng_seed() {
    g_rng = cntvct() ^ ((uint64_t)sc(SYS_getpid) << 32) ^ (uint64_t)(uintptr_t)&g_rng;
}
static uint32_t rnd() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 7; g_rng ^= g_rng << 17; return (uint32_t)(g_rng >> 32); }
static uint32_t rnd_range(uint32_t a, uint32_t b) { return a + (b > a ? rnd() % (b - a) : 0); }

struct linux_dirent64 { uint64_t d_ino; int64_t d_off; uint16_t d_reclen; uint8_t d_type; char d_name[]; };
enum { kDT_Lnk = 10 };

// ─── events ─────────────────────────────────────────────────────────────────
enum Ev : uint32_t {
    EV_INIT_HOOKED = 1,   // inline hook already present at constructor time — restored from disk
    EV_INLINE_HOOK,       // own .text patched at runtime — page restored from private mirror
    EV_GOT_HOOK,          // PLT slot redirected outside any file-backed exec range — slot restored
    EV_READER,            // foreign process holds an open fd to our /proc/self/{mem,maps,pagemap}
    EV_SCANNER_PROC,      // known scanner name in a process cmdline (reference tool: com.hamza.hooktool)
    EV_FRIDA,             // frida-server default port answered on loopback
    EV_INJECT_LIB,        // injection framework mapped into us / foreign thread comm / LD_PRELOAD
    EV_TRACER,            // TracerPid is neither 0 nor our watchdog
    EV_WATCHDOG_LOST,     // tracer watchdog died — tracer slot was briefly free
    EV_STEP               // guard window exceeded — single-stepped through a guarded function
};
static_assert((int)EV_INIT_HOOKED  == AH_EV_INIT_HOOKED  &&
              (int)EV_INLINE_HOOK  == AH_EV_INLINE_HOOK  &&
              (int)EV_GOT_HOOK     == AH_EV_GOT_HOOK     &&
              (int)EV_READER       == AH_EV_READER       &&
              (int)EV_SCANNER_PROC == AH_EV_SCANNER_PROC &&
              (int)EV_FRIDA        == AH_EV_FRIDA        &&
              (int)EV_INJECT_LIB   == AH_EV_INJECT_LIB   &&
              (int)EV_TRACER       == AH_EV_TRACER       &&
              (int)EV_WATCHDOG_LOST== AH_EV_WATCHDOG_LOST&&
              (int)EV_STEP         == AH_EV_STEP,
              "Ev enum drifted from AntiHook.h event codes");
typedef void (*AttackCb)(uint32_t ev, uintptr_t detail);
class SecureBlob;
static void lockdown();

struct State {
    long self_pid = 0, watchdog_pid = 0;
    AttackCb cb = nullptr;
    bool kill_scanners = true, kill_on_attack = false;
    uint32_t min_ms = 250, max_ms = 1400;
    bool booted = false;   // fix: constructor(101) boots first — later init() calls only apply policy
};
static State g;
static SecureBlob* g_blobs[32];
static int g_nblobs = 0;

static void fire(uint32_t ev, uintptr_t d) {
    if (g.cb) g.cb(ev, d);
    lockdown();  // every alarm seals plaintext first: anything read after this point is ciphertext
    if (g.kill_on_attack) sc(SYS_tgkill, g.self_pid, sc(SYS_gettid), SIGKILL);
}

// ─── maps ───────────────────────────────────────────────────────────────────
struct MapRange { uintptr_t start, end; uint64_t off; char perms[5]; char path[256]; };
static MapRange g_maps[768];
static int g_nmaps = 0;

static void refresh_maps() {
    static char s_maps[131072];
    long n = read_file("/proc/self/maps", s_maps, sizeof(s_maps) - 1);
    if (n <= 0) return;
    s_maps[n] = 0;
    int c = 0;
    const char* p = s_maps;
    while (*p && c < 768) {
        MapRange& m = g_maps[c];
        m.path[0] = 0;
        m.start = phex(p);
        if (*p != '-') { while (*p && *p != '\n') p++; if (*p == '\n') p++; continue; }
        p++;
        m.end = phex(p);
        if (*p != ' ') { while (*p && *p != '\n') p++; if (*p == '\n') p++; continue; }
        p++;
        int i = 0;
        while (*p && *p != ' ' && i < 4) m.perms[i++] = *p++;
        m.perms[i] = 0;
        while (*p == ' ') p++;
        m.off = phex(p);
        while (*p && *p != ' ') p++;  // dev
        while (*p == ' ') p++;
        while (*p && *p != ' ') p++;  // inode
        while (*p == ' ') p++;
        if (*p && *p != '\n') {
            size_t j = 0;
            while (*p && *p != '\n' && j < sizeof(m.path) - 1) m.path[j++] = *p++;
            m.path[j] = 0;
        }
        while (*p && *p != '\n') p++;
        if (*p == '\n') p++;
        c++;
    }
    g_nmaps = c;
}

// ─── page restore ───────────────────────────────────────────────────────────
static bool mp(void* a, size_t n, int prot) { return sc(SYS_mprotect, (long)a, (long)n, prot) >= 0; }
static void restore_page(uintptr_t page, const uint8_t* src, size_t n) {
    mp((void*)page, 4096, PROT_READ | PROT_WRITE);
    kcpy((uint8_t*)page, src, n);
    mp((void*)page, 4096, PROT_READ | PROT_EXEC);
    __builtin___clear_cache((char*)page, (char*)page + 4096);
}

// ─── self integrity: mem-vs-disk at init, mem-vs-mirror forever after ───────
struct Seg { uintptr_t start, end; uint64_t off; };
static Seg g_segs[64];
static int g_nsegs = 0;
static uint8_t* g_mirror = nullptr;  // anonymous private copy of our exec segments: no disk reference for scanners to tamper with

static bool build_baseline() {
    refresh_maps();
    const char* lib = ANTIHOOK_LIBNAME;
    char path[256] = { 0 };
    uintptr_t base = ~0ull;
    for (int i = 0; i < g_nmaps; i++) {
        const MapRange& m = g_maps[i];
        if (!m.path[0] || !kfind(m.path, lib)) continue;
        if (m.start < base) base = m.start;
        if (m.perms[2] == 'x' && !path[0]) kcpy((uint8_t*)path, (const uint8_t*)m.path, klen(m.path) + 1);
    }
    if (base == ~0ull || !path[0]) return false;

    g_nsegs = 0; size_t total = 0;
    for (int i = 0; i < g_nmaps; i++) {
        const MapRange& m = g_maps[i];
        if (!m.path[0] || !kfind(m.path, lib)) continue;
        if (m.perms[2] != 'x') continue;
        if (g_nsegs < 64) { g_segs[g_nsegs++] = { m.start, m.end, m.off }; total += m.end - m.start; }
    }
    if (!g_nsegs) return false;

    long fd = sc(SYS_openat, AT_FDCWD, (long)path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    long r = sc(SYS_mmap, 0, (long)total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (r <= 0) { sc(SYS_close, fd); return false; }
    g_mirror = (uint8_t*)r;
    sc(SYS_mlock, (long)g_mirror, (long)total);

    uint8_t* dst = g_mirror;
    bool hooked_at_init = false;
    for (int s = 0; s < g_nsegs; s++) {
        size_t len = g_segs[s].end - g_segs[s].start;
        long fm = sc(SYS_mmap, 0, (long)len, PROT_READ, MAP_PRIVATE, fd, (long)g_segs[s].off);
        if (fm <= 0) { sc(SYS_close, fd); return false; }
        const uint8_t* mem = (const uint8_t*)g_segs[s].start;
        // same probe the reference tool runs against its target, aimed at ourselves
        for (size_t o = 0; o < len; o += 4096) {
            size_t pn = (len - o < 4096) ? len - o : 4096;
            if (!keqb(mem + o, (const uint8_t*)fm + o, pn)) {
                uintptr_t page = (g_segs[s].start + o) & ~4095ull;
                size_t poff = (size_t)(page - g_segs[s].start);
                size_t psz = (len - poff < 4096) ? len - poff : 4096;
                restore_page(page, (const uint8_t*)fm + poff, psz);
                hooked_at_init = true;
            }
        }
        kcpy(dst, (const uint8_t*)fm, len);
        sc(SYS_munmap, fm, (long)len);
        dst += len;
    }
    sc(SYS_close, fd);
    mp(g_mirror, total, PROT_READ);  // mirror locked read-only: post-init repairs never touch disk
    if (hooked_at_init) fire(EV_INIT_HOOKED, base);
    return true;
}

static void integrity_pass() {
    if (!g_mirror) return;
    size_t seg_base = 0;
    for (int s = 0; s < g_nsegs; s++) {
        size_t len = g_segs[s].end - g_segs[s].start;
        const uint8_t* mem = (const uint8_t*)g_segs[s].start;
        for (size_t o = 0; o < len; o += 4096) {
            size_t pn = (len - o < 4096) ? len - o : 4096;
            if (!keqb(mem + o, g_mirror + seg_base + o, pn)) {
                uintptr_t page = (g_segs[s].start + o) & ~4095ull;
                size_t poff = (size_t)(page - g_segs[s].start);
                size_t psz = (len - poff < 4096) ? len - poff : 4096;
                restore_page(page, g_mirror + seg_base + poff, psz);
                fire(EV_INLINE_HOOK, page);
            }
        }
        seg_base += len;
    }
}

// ─── GOT freeze: every JUMP_SLOT must land inside a file-backed exec range ──
struct ExR { uintptr_t s, e; };
static ExR g_exec[256];
static int g_nexec = 0;
static uintptr_t* g_slots[1024];
static uintptr_t g_slotvals[1024];
static int g_nslots = 0;

static void snapshot_exec() {
    g_nexec = 0;
    for (int i = 0; i < g_nmaps && g_nexec < 256; i++) {
        const MapRange& m = g_maps[i];
        if (m.path[0] && m.perms[2] == 'x') { g_exec[g_nexec].s = m.start; g_exec[g_nexec].e = m.end; g_nexec++; }
    }
}
static bool in_exec(uintptr_t v) {
    for (int i = 0; i < g_nexec; i++) if (v >= g_exec[i].s && v < g_exec[i].e) return true;
    return false;
}

static void got_freeze() {
    refresh_maps();
    uintptr_t base = ~0ull;
    const char* lib = ANTIHOOK_LIBNAME;
    for (int i = 0; i < g_nmaps; i++) {
        const MapRange& m = g_maps[i];
        if (m.path[0] && kfind(m.path, lib) && m.start < base) base = m.start;
    }
    if (base == ~0ull) return;
    const Elf64_Ehdr* eh = (const Elf64_Ehdr*)base;
    static const uint8_t ELF_MAG[4] = { 0x7F, 'E', 'L', 'F' };
    if (!keqb((const uint8_t*)eh, ELF_MAG, 4)) return;
    const Elf64_Phdr* ph = (const Elf64_Phdr*)(base + eh->e_phoff);
    const Elf64_Dyn* dyn = nullptr;
    for (int i = 0; i < eh->e_phnum; i++)
        if (ph[i].p_type == PT_DYNAMIC) { dyn = (const Elf64_Dyn*)(base + ph[i].p_vaddr); break; }
    if (!dyn) return;
    uintptr_t jmprel = 0; uint64_t pltrelsz = 0, pltrel = 0;
    for (const Elf64_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_JMPREL:   jmprel = (uintptr_t)d->d_un.d_ptr; break;
            case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
            case DT_PLTREL:   pltrel = d->d_un.d_val; break;
        }
    }
    if (!jmprel || pltrel != DT_RELA || !pltrelsz) return;  // packed relocations: .text integrity still covers this lib
    const Elf64_Rela* r = (const Elf64_Rela*)(base + jmprel);
    size_t nrel = pltrelsz / sizeof(Elf64_Rela);
    g_nslots = 0;
    for (size_t i = 0; i < nrel && g_nslots < 1024; i++) {
        if (ELF64_R_TYPE(r[i].r_info) != R_AARCH64_JUMP_SLOT) continue;
        uintptr_t* slot = (uintptr_t*)(base + r[i].r_offset);
        g_slots[g_nslots] = slot;
        g_slotvals[g_nslots] = *slot;
        g_nslots++;
    }
    snapshot_exec();
}

static void got_verify() {
    for (int i = 0; i < g_nslots; i++) {
        uintptr_t v = *g_slots[i];
        if (!v || v == g_slotvals[i]) continue;
        if (in_exec(v)) continue;  // lazy bind moved it into a real file-backed exec range — legit
        *g_slots[i] = g_slotvals[i];  // landed in anon/RWX memory — trampoline, restore
        fire(EV_GOT_HOOK, (uintptr_t)g_slots[i]);
    }
}

// ─── tracer watchdog: occupies the one ptrace slot on this process ──────────
static long g_hb_fd = -1;

static void spawn_watchdog() {
    int fds[2];
    if (sc(SYS_pipe2, (long)fds, O_CLOEXEC) < 0) return;
    long pid = sc(SYS_clone, SIGCHLD, 0, 0, 0, 0, 0);  // raw fork: child shares nothing, TLS untouched
    if (pid == 0) {
        sc(SYS_close, fds[0]);
        long ppid = sc(SYS_getppid);
        bool seized = false;
        for (int t = 0; t < 5 && !seized; t++) {
            if (sc(SYS_ptrace, PTRACE_SEIZE, ppid, 0, 0, 0, 0) == 0) seized = true;
            else { timespec ts{ 0, 50 * 1000 * 1000 }; sc(SYS_nanosleep, (long)&ts); }
        }
        if (!seized && sc(SYS_ptrace, PTRACE_ATTACH, ppid, 0, 0, 0, 0) == 0) {
            int st;
            sc(SYS_wait4, ppid, (long)&st, 0, 0, 0, 0);
            sc(SYS_ptrace, PTRACE_CONT, ppid, 0, 0, 0, 0);
        }
        for (;;) {
            uint8_t hb = 1;
            if (sc(SYS_write, fds[1], (long)&hb, 1) != 1) sc(SYS_exit_group);
            timespec ts{ 1, 0 };
            sc(SYS_nanosleep, (long)&ts);
            if (sc(SYS_getppid) != ppid) sc(SYS_exit_group);
        }
    }
    if (pid < 0) { sc(SYS_close, fds[0]); sc(SYS_close, fds[1]); return; }
    sc(SYS_close, fds[1]);
    sc(SYS_prctl, PR_SET_PTRACER, pid, 0, 0, 0);  // Yama: this child is the only permitted tracer
    g.watchdog_pid = pid;
    g_hb_fd = fds[0];
}

static void* wd_monitor(void*) {
    for (;;) {
        uint8_t b;
        long r = sc(SYS_read, g_hb_fd, (long)&b, 1);
        if (r == 0) {
            fire(EV_WATCHDOG_LOST, 0);  // slot just freed — a hooking tool can PTRACE_ATTACH during this window
            sc(SYS_close, g_hb_fd);
            spawn_watchdog();
            if (g_hb_fd < 0) return nullptr;
        } else if (r < 0) {
            timespec ts{ 0, 100 * 1000 * 1000 };
            sc(SYS_nanosleep, (long)&ts);
        }
    }
}

// ─── reader hunt: the direct counter to the pasted scanner ──────────────────
static void respond_scanner(long pid, uint32_t ev) {
    fire(ev, (uintptr_t)pid);
    if (g.kill_scanners) sc(SYS_kill, pid, SIGKILL);  // app-uid can't kill root; when it fails, sealed blobs + hook restores carry the load
}

static bool targets_self(const char* tgt) {
    char pre[40];
    kjoin(pre, "/proc/", g.self_pid, "/");
    if (!kstart(tgt, pre)) return false;
    return kend(tgt, "/mem") || kend(tgt, "/maps") || kend(tgt, "/pagemap");
}

static void inspect_scanner(long pid) {
    char pth[48];
    kjoin(pth, "/proc/", pid, "/fd");
    long ffd = sc(SYS_openat, AT_FDCWD, (long)pth, O_RDONLY | O_CLOEXEC);
    if (ffd >= 0) {
        alignas(8) char fb[4096];
        for (;;) {
            long n = sc(SYS_getdents64, ffd, (long)fb, sizeof(fb));
            if (n <= 0) break;
            for (char* q = fb; q < fb + n;) {
                linux_dirent64* de = (linux_dirent64*)q; q += de->d_reclen;
                if (de->d_type != kDT_Lnk && de->d_type != 0) continue;
                char tgt[160];
                long r = sc(SYS_readlinkat, ffd, (long)de->d_name, (long)tgt, (long)(sizeof(tgt) - 1));
                if (r <= 0) continue;
                tgt[r] = 0;
                if (targets_self(tgt)) { sc(SYS_close, ffd); respond_scanner(pid, EV_READER); return; }
            }
        }
        sc(SYS_close, ffd);
    }
    kjoin(pth, "/proc/", pid, "/cmdline");
    char cl[512];
    long n = read_file(pth, cl, sizeof(cl) - 1);
    if (n <= 0) return;
    cl[n] = 0;
    for (long i = 0; i < n; i++) if (cl[i] == 0) cl[i] = ' ';
    static const char* names[] = { "hooktool", "hamza", "gameguardian" };
    for (unsigned i = 0; i < sizeof(names) / sizeof(names[0]); i++)
        if (kfind(cl, names[i])) { respond_scanner(pid, EV_SCANNER_PROC); return; }
}

static void hunt_readers() {
    alignas(8) char db[8192];
    long dfd = sc(SYS_openat, AT_FDCWD, (long)"/proc", O_RDONLY | O_CLOEXEC);
    if (dfd < 0) return;
    for (;;) {
        long n = sc(SYS_getdents64, dfd, (long)db, sizeof(db));
        if (n <= 0) break;
        for (char* q = db; q < db + n;) {
            linux_dirent64* de = (linux_dirent64*)q; q += de->d_reclen;
            if (!kdig(de->d_name)) continue;
            long pid = katol(de->d_name);
            if (pid == g.self_pid || pid == g.watchdog_pid) continue;
            inspect_scanner(pid);
        }
    }
    sc(SYS_close, dfd);
}

// ─── injector / frida sweep ─────────────────────────────────────────────────
static uint16_t h2n(uint16_t v) { return (uint16_t)((v << 8) | (v >> 8)); }

static void inject_checks() {
    static const uint16_t ports[] = { 27042, 27043 };
    for (unsigned i = 0; i < sizeof(ports) / sizeof(ports[0]); i++) {
        sockaddr_in a{};
        a.sin_family = 2;                 // AF_INET
        a.sin_port = h2n(ports[i]);
        a.sin_addr.s_addr = 0x0100007F;   // 127.0.0.1
        long s = sc(SYS_socket, 2, 1 | SOCK_CLOEXEC, 0);
        if (s < 0) continue;
        long r = sc(SYS_connect, s, (long)&a, (long)sizeof(a));
        sc(SYS_close, s);
        if (r == 0) fire(EV_FRIDA, ports[i]);  // something answered frida-server's default port
    }
    static const char* comm_names[] = { "gum-js-loop", "gmain", "pool-frida", "gdbus", "frida" };
    long dfd = sc(SYS_openat, AT_FDCWD, (long)"/proc/self/task", O_RDONLY | O_CLOEXEC);
    if (dfd >= 0) {
        alignas(8) char db[4096];
        for (;;) {
            long n = sc(SYS_getdents64, dfd, (long)db, sizeof(db));
            if (n <= 0) break;
            for (char* q = db; q < db + n;) {
                linux_dirent64* de = (linux_dirent64*)q; q += de->d_reclen;
                if (!kdig(de->d_name)) continue;
                char cp[64];
                kjoin(cp, "/proc/self/task/", katol(de->d_name), "/comm");
                char comm[64];
                long rn = read_file(cp, comm, sizeof(comm) - 1);
                if (rn <= 0) continue;
                comm[rn] = 0;
                for (unsigned i = 0; i < sizeof(comm_names) / sizeof(comm_names[0]); i++)
                    if (kfind(comm, comm_names[i])) { fire(EV_INJECT_LIB, (uintptr_t)katol(de->d_name)); break; }
            }
        }
        sc(SYS_close, dfd);
    }
    static const char* lib_names[] = { "frida", "gum", "linjector", "xposed", "edxposed", "lsposed", "substrate", "sandhook", "zygisk", "riru", "whale" };
    for (int i = 0; i < g_nmaps; i++) {
        if (!g_maps[i].path[0]) continue;
        for (unsigned j = 0; j < sizeof(lib_names) / sizeof(lib_names[0]); j++)
            if (kfind(g_maps[i].path, lib_names[j])) { fire(EV_INJECT_LIB, g_maps[i].start); i = g_nmaps; break; }
    }
    char env[8192];
    long en = read_file("/proc/self/environ", env, sizeof(env) - 1);
    if (en > 0) {
        env[en] = 0;
        if (kfind(env, "LD_PRELOAD") || kfind(env, "XPOSED") || kfind(env, "zygisk")) fire(EV_INJECT_LIB, 0);
    }
    char st[4096];
    if (read_file("/proc/self/status", st, sizeof(st) - 1) > 0) {
        st[sizeof(st) - 1] = 0;
        const char* tp = kfind(st, "TracerPid:");
        if (tp) {
            tp += 10;
            while (*tp == ' ') tp++;
            long v = katol(tp);
            if (v && v != g.watchdog_pid) fire(EV_TRACER, (uintptr_t)v);
        }
    }
}

// ─── SecureBlob: secrets never sit plaintext on the heap ────────────────────
class SecureBlob {
public:
    bool init(size_t n) {
        long r = sc(SYS_mmap, 0, (long)n, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (r <= 0) return false;
        p_ = (uint8_t*)r; n_ = n;
        sc(SYS_mlock, (long)p_, (long)n_);  // locked: never swaps, never hits encrypted swap late
        uint64_t s = cntvct() ^ (uint64_t)(uintptr_t)p_ ^ ((uint64_t)sc(SYS_getpid) << 17);
        for (int i = 0; i < 4; i++) { s ^= s << 13; s ^= s >> 7; s ^= s << 17; k_[i] = s; }
        if (g_nblobs < 32) g_blobs[g_nblobs++] = this;
        plain_ = true;
        seal();
        return true;
    }
    uint8_t* open() { if (!plain_) { x(); plain_ = true; } return p_; }
    void seal() { if (plain_) { x(); plain_ = false; } }
    ~SecureBlob() {
        for (int i = 0; i < g_nblobs; i++)
            if (g_blobs[i] == this) { g_blobs[i] = g_blobs[--g_nblobs]; break; }
        if (p_) { kzero(p_, n_); sc(SYS_munmap, (long)p_, (long)n_); }
    }
private:
    void x() { const uint8_t* k = (const uint8_t*)k_; for (size_t i = 0; i < n_; i++) p_[i] ^= k[i & 31]; }
    uint8_t* p_ = nullptr; size_t n_ = 0; uint64_t k_[4] = { 0 }; bool plain_ = false;
};

static void lockdown() { for (int i = 0; i < g_nblobs; i++) g_blobs[i]->seal(); }

// ─── scan loop ──────────────────────────────────────────────────────────────
static void* scan_loop(void*) {
    sc(SYS_prctl, PR_SET_NAME, (long)"RenderThread", 0, 0, 0);  // comm blends into a common GPU worker name
    uint32_t tick = 0;
    for (;;) {
        sleep_ms(rnd_range(g.min_ms, g.max_ms));  // randomized cadence: no fixed probe rhythm to time against
        refresh_maps();
        inject_checks();
        got_verify();
        integrity_pass();
        if ((++tick & 3) == 0) hunt_readers();
    }
    return nullptr;
}

static void configure(AttackCb cb, bool kill_scanners, bool kill_on_attack);
static void init(AttackCb cb, bool kill_scanners, bool kill_on_attack, uint32_t min_ms, uint32_t max_ms) {
    if (g.booted) { configure(cb, kill_scanners, kill_on_attack); return; }  // constructor won the race — just apply policy
    g.booted = true;
    g.self_pid = sc(SYS_getpid);
    g.cb = cb;
    g.kill_scanners = kill_scanners;
    g.kill_on_attack = kill_on_attack;
    g.min_ms = min_ms ? min_ms : 250;
    g.max_ms = max_ms > g.min_ms ? max_ms : g.min_ms + 1000;
    rng_seed();
    g_step_ticks = cntfrq() / 1000;  // >1ms inside a guard means someone stepped through it
    spawn_watchdog();
    sc(SYS_prctl, PR_SET_DUMPABLE, 0, 0, 0, 0, 0);  // /proc/self/{mem,maps,cmdline} go root-only — non-root scanners read nothing
    sc(SYS_prctl, PR_SET_PTRACER, 0, 0, 0, 0, 0);   // Yama: no new tracers; the watchdog keeps its slot
    build_baseline();
    got_freeze();
    pthread_t t;
    pthread_create(&t, nullptr, scan_loop, nullptr); pthread_detach(t);
    pthread_create(&t, nullptr, wd_monitor, nullptr); pthread_detach(t);
}

static void configure(AttackCb cb, bool kill_scanners, bool kill_on_attack) {
    g.cb = cb; g.kill_scanners = kill_scanners; g.kill_on_attack = kill_on_attack;
}

__attribute__((constructor(101))) static void ah_bootstrap() {
    init(nullptr, true, false, 250, 1400);
}

}  // namespace antihook

// ─── AntiHook.h connection layer ────────────────────────────────────────────
// header already included at top — the guard makes this a no-op, kept so the
// connection layer stays valid if the top include is ever reordered
#include "AntiHook.h"

extern "C" {

ANTIHOOK_API int antihook_init(AntiHookCb cb, int kill_scanners, int kill_on_attack,
                               uint32_t min_ms, uint32_t max_ms) {
    antihook::init(cb, kill_scanners != 0, kill_on_attack != 0, min_ms, max_ms);
    return 0;
}

ANTIHOOK_API void antihook_configure(AntiHookCb cb, int kill_scanners, int kill_on_attack) {
    antihook::configure(cb, kill_scanners != 0, kill_on_attack != 0);
}

ANTIHOOK_API void antihook_lockdown(void) { antihook::lockdown(); }

ANTIHOOK_API uint64_t ah_guard_enter(void) { return antihook::cntvct(); }

ANTIHOOK_API void ah_guard_exit(uint64_t token) {
    if (antihook::g_step_ticks && antihook::cntvct() - token > antihook::g_step_ticks)
        antihook::fire(antihook::EV_STEP, 0);
}

struct ah_blob { antihook::SecureBlob b; };  // handle page arrives zeroed = implicit-init equivalent

ANTIHOOK_API ah_blob* ah_blob_create(size_t n) {
    long r = antihook::sc(SYS_mmap, 0, (long)sizeof(ah_blob), PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (r <= 0) return nullptr;
    ah_blob* h = (ah_blob*)r;
    if (!h->b.init(n)) { antihook::sc(SYS_munmap, r, (long)sizeof(ah_blob)); return nullptr; }
    return h;
}

ANTIHOOK_API uint8_t* ah_blob_open(ah_blob* h) { return h ? h->b.open() : nullptr; }
ANTIHOOK_API void ah_blob_seal(ah_blob* h) { if (h) h->b.seal(); }

ANTIHOOK_API void ah_blob_destroy(ah_blob* h) {
    if (!h) return;
    h->b.~SecureBlob();  // zero + unregister + unmap payload
    antihook::sc(SYS_munmap, (long)h, (long)sizeof(ah_blob));
}

}  // extern "C"

#ifdef ANTIHOOK_JNI
#include <jni.h>
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    antihook::configure(nullptr, true, false);  // swap in your own AttackCb here
    return JNI_VERSION_1_6;
}
#endif

/*
  usage:
    both files in one target:  AntiHook.h + antiHook.cpp + Main.cpp   # arm64-v8a — compile: -O2 -fno-builtin -fvisibility=hidden
    set -DANTIHOOK_LIBNAME='"libyourapp.so"' so the integrity engine binds to your own ELF
    guard hot paths:  void pay(){ ANTIHOOK_GUARD; ... }
    shield secrets:   ah::Secret s(64); memcpy(s.open(), secret, 64); s.seal();
    custom response:  antihook_init(on_attack_cb, 1, 0, 250, 1400) from Main.cpp — safe to call even
                      though constructor(101) already booted; the booted flag makes it policy-only
*/
