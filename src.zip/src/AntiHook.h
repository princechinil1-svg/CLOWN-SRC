// AntiHook.h — public interface for antiHook.cpp
// C API + C++ RAII (namespace ah). Event values mirror the cpp enum exactly.

#ifndef ANTIHOOK_H
#define ANTIHOOK_H

#include <stdint.h>
#include <stddef.h>

#ifndef ANTIHOOK_API
#define ANTIHOOK_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

enum {
    AH_EV_INIT_HOOKED   = 1,   // hooks present before we even ran — restored from disk ELF
    AH_EV_INLINE_HOOK   = 2,   // own .text patched at runtime — page restored from mirror
    AH_EV_GOT_HOOK      = 3,   // PLT slot redirected to anon memory — slot restored
    AH_EV_READER        = 4,   // foreign process holds open fd on /proc/self/{mem,maps,pagemap}
    AH_EV_SCANNER_PROC  = 5,   // known scanner name in a process cmdline
    AH_EV_FRIDA         = 6,   // frida-server default port answered on loopback
    AH_EV_INJECT_LIB    = 7,   // injection framework mapped / foreign thread / LD_PRELOAD
    AH_EV_TRACER        = 8,   // TracerPid neither 0 nor our watchdog
    AH_EV_WATCHDOG_LOST = 9,   // heartbeat died — ptrace slot briefly free
    AH_EV_STEP          = 10   // guard window exceeded — single-stepped through guarded code
};

typedef void (*AntiHookCb)(uint32_t ev, uintptr_t detail);

/* full boot: watchdog + dumpable-0 + baseline + GOT freeze + scan threads */
ANTIHOOK_API int antihook_init(AntiHookCb cb, int kill_scanners, int kill_on_attack,
                               uint32_t min_ms, uint32_t max_ms);

/* swap callback / policy live, from any thread */
ANTIHOOK_API void antihook_configure(AntiHookCb cb, int kill_scanners, int kill_on_attack);

/* seal every SecureBlob now — call before you suspect a read is imminent */
ANTIHOOK_API void antihook_lockdown(void);

/* single-step canary: token in, check out. >1ms inside means a debugger walked it */
ANTIHOOK_API uint64_t ah_guard_enter(void);
ANTIHOOK_API void     ah_guard_exit(uint64_t token);

/* opaque secret blob: plaintext exists only between open() and seal(), mlocked, never on heap */
typedef struct ah_blob ah_blob;
ANTIHOOK_API ah_blob*  ah_blob_create(size_t n);        /* mmap'd + mlocked + XOR-sealed at rest */
ANTIHOOK_API uint8_t*  ah_blob_open(ah_blob* h);        /* decrypt in place, return pointer */
ANTIHOOK_API void      ah_blob_seal(ah_blob* h);        /* re-encrypt in place */
ANTIHOOK_API void      ah_blob_destroy(ah_blob* h);     /* zero, unregister, unmap */

#ifdef __cplusplus
}  /* extern "C" */

#include <string.h>

namespace ah {

/* RAII secret: constructor allocates + seals, open()/seal() bracket the plaintext window */
class Secret {
public:
    explicit Secret(size_t n) : h_(ah_blob_create(n)) {}
    ~Secret() { ah_blob_destroy(h_); }
    Secret(const Secret&) = delete;
    Secret& operator=(const Secret&) = delete;
    bool ok() const { return h_ != nullptr; }
    uint8_t* open() { return ah_blob_open(h_); }
    void seal() { ah_blob_seal(h_); }
private:
    ah_blob* h_;
};

/* RAII canary: drop it as the first statement of any function worth stepping through */
class Guard {
public:
    Guard() : t_(ah_guard_enter()) {}
    ~Guard() { ah_guard_exit(t_); }
    Guard(const Guard&) = delete;
    Guard& operator=(const Guard&) = delete;
private:
    uint64_t t_;
};

}  // namespace ah

#define AH_CONCAT2(a, b) a##b
#define AH_CONCAT(a, b) AH_CONCAT2(a, b)
#define ANTIHOOK_GUARD ::ah::Guard AH_CONCAT(_ah_guard_, __LINE__)

#endif  /* __cplusplus */
#endif  /* ANTIHOOK_H */

/*
  usage:
    C:   antihook_init(on_attack, 1, 0, 250, 1400);   uint64_t t = ah_guard_enter(); hot(); ah_guard_exit(t);
    C++: ah::Secret s(32); memcpy(s.open(), key, 32); s.seal();   { ANTIHOOK_GUARD; hot(); }
    compile the cpp with: -O2 -fno-builtin -fvisibility=hidden -DANTIHOOK_LIBNAME='"libyourapp.so"'
*/
