#pragma once

#define m_IL2CPPLIB OBFUSCATE("libanogs.so")
#define m_ANOGSLIB OBFUSCATE("libanogs.so")

#define SLEEP_TIME 1000LL / 60LL

uintptr_t Class_Camera_getAllCamera;

class Transform;

class Component {
public:
    Transform *get_transform() {
        auto _Component__get_transform = (Transform *(*)(Component *)) (Class_Component_get_transform);
        return _Component__get_transform(this);
    }
};

class Transform : public Component {
public:
    Vector3 get_position() {
        auto _Transform__get_position = (Vector3 (*)(Transform *)) (Class_Transform_get_position);
        return _Transform__get_position(this);
    }
};

class Camera : public Component {
public:
    static Camera *get_main() {
        auto _Camera__get_main = (Camera *(*)()) (Class_Camera_get_main);
        return _Camera__get_main();
    }

    Vector3 WorldToScreenPoint(Vector3 position) {
        auto main = Camera::get_main();
        if (main) {
            auto _Camera__WorldToScreenPoint = (Vector3 (*)(Camera *, Vector3)) (Class_Camera_WorldToScreenPoint);
            return _Camera__WorldToScreenPoint(main, position);
        }
        return {0, 0, 0};
    }
};

class AttackableTargetInfo {
public:
    float m_Health() {
        return *(float *) ((uintptr_t) this + Class_AttackableTarget_m_Health);
    }

    float m_MaxHealth() {
        return *(float *) ((uintptr_t) this + Class_AttackableTarget_m_MaxHealth);
    }

    float m_ExtraHealth() {
        return *(float *) ((uintptr_t) this + Class_AttackableTarget_m_ExtraHealth);
    }

    float m_MaxExtraHealth() {
        return *(float *) ((uintptr_t) this + Class_AttackableTarget_m_MaxExtraHealth);
    }
};

class AttackableTarget {
public:
    AttackableTargetInfo *m_AttackableInfo() {
        return *(AttackableTargetInfo **) ((uintptr_t) this + Class_AttackableTarget_m_AttackableInfo);
    }
};

class Weapon {
public:
    int get_WeaponID() {
        using GetWeaponIDFunc = int (*)(Weapon*);
        static GetWeaponIDFunc _Weapon__get_WeaponID = (GetWeaponIDFunc)(Weapon_GetWeaponId);
        return _Weapon__get_WeaponID ? _Weapon__get_WeaponID(this) : 0;
    }
}; 

class Pawn : public AttackableTarget {
public:
    Vector3 get_LastPawnPos() {
        auto _Pawn__get_LastPawnPos = (Vector3 (*)(Pawn *)) (Class_Pawn_get_LastPawnPos);
        return _Pawn__get_LastPawnPos(this);
    }

    Vector3 get_HeadPosition() {
        auto _Pawn__get_HeadPosition = (Vector3 (*)(Pawn *)) (Class_Pawn_get_HeadPosition);
        return _Pawn__get_HeadPosition(this);
    }

    bool m_IsBot() {
        return *(bool *) ((uintptr_t) this + Class_Pawn_m_IsBot);
    }

    bool m_IsAlive() {
        return *(bool *) ((uintptr_t) this + Class_Pawn_m_IsAlive);
    }

    String *get_PlayerName() {
        auto _Pawn__get_PlayerName = (String * (*)(Pawn *)) (Class_Pawn_get_PlayerName);
        return _Pawn__get_PlayerName(this);
    }

    unsigned int *get_TeamSeatId() {
        auto _Pawn__get_HeadPosition = (unsigned int *(*)(Pawn *)) (Class_Pawn_get_TeamSeatId);
        return _Pawn__get_HeadPosition(this);
    }

    int m_LastFireWeaponName() {
        return *(int *) ((uintptr_t) this + Class_Pawn_m_LastFireWeaponName);
    }

    Weapon* get_CurrentWeapon() {
        using GetCurrentWeaponFunc = Weapon* (*)(Pawn*);
        static GetCurrentWeaponFunc _Pawn__get_CurrentWeapon = (GetCurrentWeaponFunc)(Pawn_get_CurrentWeapon);
        return _Pawn__get_CurrentWeapon ? _Pawn__get_CurrentWeapon(this) : nullptr;
    } 
};

class PlayerInfo {
public:
    PlayerInfo *m_PlayerInfo(Pawn *thiz) {
        return *(PlayerInfo **) ((uintptr_t) thiz + Class_Pawn_m_PlayerInfo);
    }

    String *m_NickName(PlayerInfo *thiz) {
        return *(String **) ((uintptr_t) thiz + Class_PlayerInfo_m_NickName);
    }
};

class BaseGame {
public:
    List<Pawn *> *EnemyPawns() {
        return *(List<Pawn *> **) ((uintptr_t) this + Class_BaseGame_EnemyPawns);
    }
};

class LethalAndTacticalConfConfig {
public:
    String *MarkOfName() {
        return *(String **) ((uintptr_t) this + Class_LethalAndTacticalConfConfig_MarkOfName);
    }
};

class BRDroppedPickUpNormal : public Component {
public:
    LethalAndTacticalConfConfig *mThrowConf() {
        return *(LethalAndTacticalConfConfig **) ((uintptr_t) this + Class_BRDroppedPickUpNormal_mThrowConf);
    }
};

class BRDroppedPickUpMgr {
public:
    Dictionary<int, BRDroppedPickUpNormal *> *mNormalItemEntityDic() {
        return *(Dictionary<int, BRDroppedPickUpNormal *> **) ((uintptr_t) this + Class_BRDroppedPickUpMgr_mNormalItemEntityDic);
    }
};

class MatchGame : public BaseGame {
public:
    BRDroppedPickUpMgr *get_DroppedPickUpMgr() {
        auto _MatchGame__get_DroppedPickUpMgr = (BRDroppedPickUpMgr *(*)(MatchGame *)) (Class_MatchGame_get_DroppedPickUpMgr);
        return _MatchGame__get_DroppedPickUpMgr(this);
    }
};

class GamePlay {
public:
    static Pawn *get_LocalPawn() {
        auto _GamePlay__get_LocalPawn = (Pawn *(*)()) (Class_Gameplay_get_LocalPawn);
        return _GamePlay__get_LocalPawn();
    }

    static MatchGame *get_MatchGame() {
        auto _GamePlay__get_MatchGame = (MatchGame *(*)()) (Class_Gameplay_get_MatchGame);
        return _GamePlay__get_MatchGame();
    }
};

#define SLEEP_TIME 1000LL / 60LL
