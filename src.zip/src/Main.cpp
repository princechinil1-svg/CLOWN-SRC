#include "Includes/Logger.h"
#include "Includes/Macros.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "ImGui/Call_ImGui.h"
#include "IL2CppSDKGenerator/BasicStructs/Call_BasicStructs.h"
#include "IL2CppSDKGenerator/IL2Cpp/Call_IL2Cpp.h"
#include "Hacks/Hacks.h"
#include "IL2CppSDKGenerator/KittyMemory/MemoryPatch.h"
#include "ctorHook/ConstructorHook.hpp"
#include "foxcheats/include/ScanEngine.hpp"
#include "FTools/Iconcpp.h"
#include "FTools/Font.h"
#include "FTools/Icon.h"
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <string>
#include <cstring>
#include <jni.h>
#include <pthread.h>
#include <stdio.h>
#include <android/log.h>
#include <iostream>
#include <fstream>
#include <array>
#include <unordered_map>
#include <thread>
#include <chrono>
#include "ImGui/stb_image.h"
#define STB_IMAGE_IMPLEMENTATION
#include "Ghost/Fields.h"
#include "Ghost/GhostLoaded.h"
#include "Ghost/LogoNew.h"
#include "Ghost/LogoIcon.h"
#include "Ghost/LogoGarena.h"
#include "Ghost/GhostPatches.h"
#include "Ghost/GhostOffsets.h"
#include "oxorany/source/oxorany.h"
#include "oxorany/source/oxorany.cpp"
#include "oxorany/source/oxorany_include.h"
#include "Noctivagous/StrEnc.h"
#include "Noctivagous/json.hpp"
#include "Noctivagous/md5.h"
#include "curl/curl.h"
#include "HideProcess/ProcessHide.h"
#include <sys/system_properties.h>
#include <sys/sysinfo.h>
#include <set>
#include <map>
#include <vector>
#include <numeric>
#include <algorithm> 
#include <atomic>
#include <mutex>

#include "FeedbackService.h"
#include <chrono>
#include "HideRec.h"


#include <cstdint>
#include <ctime>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <signal.h>
#include <dlfcn.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <linux/unistd.h>
#include <pthread.h>
#include <errno.h>
#include <atomic>
#include <vector>
#include <string>
#include <algorithm>

// -----------------------------------------------------------------------------
// Anti-hook interface
// -----------------------------------------------------------------------------

using AntiHookCallback = void (*)(uint32_t event, uintptr_t detail);

enum AntiHookEvent : uint32_t {
    AH_NONE          = 0,
    AH_INIT_HOOKED   = 1,
    AH_INLINE_HOOK   = 2,
    AH_GOT_HOOK      = 3,
    AH_READER        = 4,
    AH_SCANNER_PROC  = 5,
    AH_FRIDA         = 6,
    AH_INJECT_LIB    = 7,
    AH_TRACER        = 8,
    AH_WATCHDOG_LOST = 9,
    AH_STEP          = 10,
    AH_XPOSED        = 11,
    AH_MAPS_ANOMALY  = 12,
    AH_PORT_OPEN     = 13
};

static AntiHookCallback      g_cb              = nullptr;
static std::atomic<int>      g_kill_scanners   {0};
static std::atomic<int>      g_kill_on_attack  {0};
static std::atomic<int>      g_step_threshold  {250};
static std::atomic<int>      g_watchdog_ms     {1400};
static std::atomic<bool>     g_running         {true};
static pthread_t             g_watchdog_tid    {};
static std::atomic<uint64_t> g_last_heartbeat  {0};

// Direct svc on aarch64 (bypasses hooked libc)
static inline long raw_syscall(long n, long a = 0, long b = 0, long c = 0,
                               long d = 0, long e = 0, long f = 0) {
#if defined(__aarch64__)
    register long x8 __asm__("x8") = n;
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    register long x2 __asm__("x2") = c;
    register long x3 __asm__("x3") = d;
    register long x4 __asm__("x4") = e;
    register long x5 __asm__("x5") = f;
    __asm__ volatile("svc #0" : "+r"(x0)
                     : "r"(x8), "r"(x1), "r"(x2), "r"(x3), "r"(x4), "r"(x5)
                     : "memory", "cc");
    return x0;
#else
    return syscall(n, a, b, c, d, e, f);
#endif
}

static void report(uint32_t ev, uintptr_t detail) {
    if (g_cb) g_cb(ev, detail);
    if (g_kill_on_attack.load() && ev != AH_NONE && ev != AH_STEP) {
        raw_syscall(__NR_kill, getpid(), SIGKILL);
        _exit(1);
    }
}

// -----------------------------------------------------------------------------
// Scanner kill
// -----------------------------------------------------------------------------

static const char* kScannerNames[] = {
    "frida", "frida-server", "frida-helper", "frida-agent",
    "gum-js-loop", "gmain", "linjector",
    "xposed", "edxposed", "lsposed", "riru", "zygisk",
    "magisk", "magiskd",
    "gdb", "gdbserver", "lldb", "lldb-server",
    "strace", "ltrace",
    "ida", "ida64", "radare2", "r2", "ghidra",
    "scrcpy",
    "gameguardian", "gg", "cheatengine",
    "substrate", "cydia",
    nullptr
};

static bool name_matches_scanner(const char* name) {
    if (!name || !*name) return false;
    for (int i = 0; kScannerNames[i]; ++i) {
        if (strcasestr(name, kScannerNames[i])) return true;
    }
    return false;
}

static void kill_scanner_procs() {
    if (!g_kill_scanners.load()) return;

    DIR* d = opendir("/proc");
    if (!d) return;

    struct dirent* de;
    while ((de = readdir(d)) != nullptr) {
        if (de->d_name[0] < '0' || de->d_name[0] > '9') continue;
        pid_t pid = static_cast<pid_t>(atoi(de->d_name));
        if (pid <= 1 || pid == getpid()) continue;

        char path[64];
        char buf[256] = {};

        snprintf(path, sizeof(path), "/proc/%d/comm", pid);
        int fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd >= 0) {
            ssize_t n = read(fd, buf, sizeof(buf) - 1);
            close(fd);
            if (n > 0) {
                buf[n] = 0;
                char* nl = strchr(buf, '\n');
                if (nl) *nl = 0;
                if (name_matches_scanner(buf)) {
                    report(AH_SCANNER_PROC, static_cast<uintptr_t>(pid));
                    raw_syscall(__NR_kill, pid, SIGKILL);
                    continue;
                }
            }
        }

        snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
        fd = open(path, O_RDONLY | O_CLOEXEC);
        if (fd >= 0) {
            memset(buf, 0, sizeof(buf));
            ssize_t n = read(fd, buf, sizeof(buf) - 1);
            close(fd);
            if (n > 0) {
                for (ssize_t i = 0; i < n; ++i)
                    if (buf[i] == 0) buf[i] = ' ';
                if (name_matches_scanner(buf)) {
                    report(AH_SCANNER_PROC, static_cast<uintptr_t>(pid));
                    raw_syscall(__NR_kill, pid, SIGKILL);
                }
            }
        }
    }
    closedir(d);
}

// -----------------------------------------------------------------------------
// Frida / Xposed / injector detection
// -----------------------------------------------------------------------------

static bool check_frida_ports() {
    int fd = open("/proc/net/tcp", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    char buf[4096];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = 0;
    if (strstr(buf, ":69A2") || strstr(buf, ":69A3") ||
        strstr(buf, ":69a2") || strstr(buf, ":69a3")) {
        report(AH_PORT_OPEN, 27042);
        return true;
    }
    return false;
}

static bool check_frida_maps() {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return false;
    char line[512];
    bool hit = false;
    while (fgets(line, sizeof(line), f)) {
        if (strcasestr(line, "frida") || strcasestr(line, "gadget") ||
            strcasestr(line, "linjector") || strcasestr(line, "agent-64") ||
            strcasestr(line, "frida-agent") || strcasestr(line, "gum-js")) {
            report(AH_FRIDA, 0);
            hit = true;
            break;
        }
        if (strcasestr(line, "xposed") || strcasestr(line, "edxposed") ||
            strcasestr(line, "lsposed") || strcasestr(line, "riru") ||
            strcasestr(line, "zygisk")) {
            report(AH_XPOSED, 0);
            hit = true;
            break;
        }
    }
    fclose(f);
    return hit;
}

static bool check_injected_libs() {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return false;
    char line[512];
    bool hit = false;
    static const char* bad[] = {
        "libfrida", "libgadget", "libsubstrate", "libxposed",
        "libedxposed", "liblsposed", "libriru", "libzygisk",
        "libhook", "libinject", "libsandhook", "libwhale",
        "libdobby", "liband64", "libsubstrate-dvm",
        nullptr
    };
    while (fgets(line, sizeof(line), f)) {
        for (int i = 0; bad[i]; ++i) {
            if (strcasestr(line, bad[i])) {
                report(AH_INJECT_LIB, 0);
                hit = true;
                break;
            }
        }
        if (hit) break;
    }
    fclose(f);
    return hit;
}

// -----------------------------------------------------------------------------
// Tracer detection
// -----------------------------------------------------------------------------

static bool check_tracer() {
    int fd = open("/proc/self/status", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    char buf[1024];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return false;
    buf[n] = 0;
    const char* p = strstr(buf, "TracerPid:");
    if (p) {
        int tid = atoi(p + 10);
        if (tid != 0) {
            report(AH_TRACER, static_cast<uintptr_t>(tid));
            return true;
        }
    }
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1) {
        report(AH_TRACER, 1);
        return true;
    }
    ptrace(PTRACE_DETACH, 0, 0, 0);
    return false;
}

// -----------------------------------------------------------------------------
// Inline-hook detection
// -----------------------------------------------------------------------------

struct FuncGuard {
    void*   addr;
    uint8_t orig[16];
    size_t  len;
};

static std::vector<FuncGuard> g_guards;

static void protect_func(void* fn, size_t len = 16) {
    if (!fn || len == 0 || len > 16) return;
    FuncGuard g{};
    g.addr = fn;
    g.len  = len;
    memcpy(g.orig, fn, len);
    g_guards.push_back(g);
}

static bool check_inline_hooks() {
    bool hit = false;
    for (auto& g : g_guards) {
        if (memcmp(g.addr, g.orig, g.len) != 0) {
            report(AH_INLINE_HOOK, reinterpret_cast<uintptr_t>(g.addr));
            hit = true;
        }
    }
    return hit;
}

// -----------------------------------------------------------------------------
// GOT integrity (simplified – production parses ELF DT_JMPREL)
// -----------------------------------------------------------------------------

struct GotSlot {
    void** slot;
    void*  expected;
};

static std::vector<GotSlot> g_got;

static void protect_got_symbol(void** slot) {
    if (!slot || !*slot) return;
    g_got.push_back(GotSlot{slot, *slot});
}

static bool check_got_hooks() {
    bool hit = false;
    for (auto& s : g_got) {
        if (*s.slot != s.expected) {
            report(AH_GOT_HOOK, reinterpret_cast<uintptr_t>(s.slot));
            hit = true;
        }
    }
    return hit;
}

// -----------------------------------------------------------------------------
// Foreign reader of /proc/self/mem|maps
// -----------------------------------------------------------------------------

static bool check_maps_readers() {
    char our_mem[64], our_maps[64];
    snprintf(our_mem,  sizeof(our_mem),  "/proc/%d/mem",  getpid());
    snprintf(our_maps, sizeof(our_maps), "/proc/%d/maps", getpid());

    DIR* d = opendir("/proc");
    if (!d) return false;
    bool hit = false;
    struct dirent* de;
    while ((de = readdir(d)) != nullptr) {
        if (de->d_name[0] < '0' || de->d_name[0] > '9') continue;
        pid_t pid = static_cast<pid_t>(atoi(de->d_name));
        if (pid == getpid()) continue;

        char fdpath[128];
        snprintf(fdpath, sizeof(fdpath), "/proc/%d/fd", pid);
        DIR* fdd = opendir(fdpath);
        if (!fdd) continue;
        struct dirent* fde;
        while ((fde = readdir(fdd)) != nullptr) {
            if (fde->d_name[0] == '.') continue;
            char link[256], target[256];
            snprintf(link, sizeof(link), "/proc/%d/fd/%s", pid, fde->d_name);
            ssize_t n = readlink(link, target, sizeof(target) - 1);
            if (n <= 0) continue;
            target[n] = 0;
            if (strcmp(target, our_mem) == 0 || strcmp(target, our_maps) == 0) {
                report(AH_READER, static_cast<uintptr_t>(pid));
                if (g_kill_scanners.load())
                    raw_syscall(__NR_kill, pid, SIGKILL);
                hit = true;
            }
        }
        closedir(fdd);
    }
    closedir(d);
    return hit;
}

// -----------------------------------------------------------------------------
// Stealth
// -----------------------------------------------------------------------------

static void stealth_thread_name(const char* name) {
    prctl(PR_SET_NAME, name, 0, 0, 0);
}

// -----------------------------------------------------------------------------
// Watchdog
// -----------------------------------------------------------------------------

static void* watchdog_thread(void*) {
    stealth_thread_name("Binder:");
    uint64_t last = g_last_heartbeat.load();
    while (g_running.load()) {
        usleep(static_cast<useconds_t>(g_watchdog_ms.load() * 1000));
        uint64_t now = g_last_heartbeat.load();
        if (now == last) {
            report(AH_WATCHDOG_LOST, 0);
        }
        last = now;

        kill_scanner_procs();
        check_frida_ports();
        check_frida_maps();
        check_injected_libs();
        check_tracer();
        check_inline_hooks();
        check_got_hooks();
        check_maps_readers();
    }
    return nullptr;
}

// -----------------------------------------------------------------------------
// Public API  (non-static so address-of works cleanly)
// -----------------------------------------------------------------------------

using AntiHookInitFn = void (*)(AntiHookCallback, int, int, int, int);

void antihook_init(AntiHookCallback callback,
                   int kill_scanners,
                   int kill_on_attack,
                   int step_threshold,
                   int watchdog_interval);

void antihook_report(uint32_t event, uintptr_t detail);

static void on_attack(uint32_t ev, uintptr_t detail) {
    static const char* names[] = {
        "none", "INIT_HOOKED", "INLINE_HOOK", "GOT_HOOK", "READER",
        "SCANNER_PROC", "FRIDA", "INJECT_LIB", "TRACER", "WATCHDOG_LOST",
        "STEP", "XPOSED", "MAPS_ANOMALY", "PORT_OPEN"
    };
    const size_t count = sizeof(names) / sizeof(names[0]);
    const char* name = (ev < count) ? names[ev] : "?";
    fprintf(stderr, "[antihook] %s (detail=0x%lx)\n",
            name, static_cast<unsigned long>(detail));
}

void antihook_init(AntiHookCallback callback,
                   int kill_scanners,
                   int kill_on_attack,
                   int step_threshold,
                   int watchdog_interval)
{
    g_cb = callback ? callback : on_attack;
    g_kill_scanners.store(kill_scanners);
    g_kill_on_attack.store(kill_on_attack);
    g_step_threshold.store(step_threshold);
    g_watchdog_ms.store(watchdog_interval > 0 ? watchdog_interval : 1400);

    // Explicit function-pointer cast avoids the overloaded-function error
    AntiHookInitFn init_ptr = &antihook_init;
    protect_func(reinterpret_cast<void*>(init_ptr));

    protect_func(reinterpret_cast<void*>(&report));
    protect_func(reinterpret_cast<void*>(&kill_scanner_procs));

    // Initial sweep
    kill_scanner_procs();
    check_frida_ports();
    check_frida_maps();
    check_injected_libs();
    check_tracer();

    g_last_heartbeat.store(1);
    pthread_create(&g_watchdog_tid, nullptr, watchdog_thread, nullptr);
    pthread_detach(g_watchdog_tid);
}

void antihook_report(uint32_t event, uintptr_t detail) {
    report(event, detail);
}

#define ANTIHOOK_GUARD \
    do { \
        g_last_heartbeat.store(g_last_heartbeat.load() + 1); \
        check_inline_hooks(); \
        check_got_hooks(); \
        if (g_last_heartbeat.load() % 32 == 0) { \
            kill_scanner_procs(); \
            check_frida_maps(); \
            check_injected_libs(); \
        } \
    } while (0)

// -----------------------------------------------------------------------------
// Entry
// -----------------------------------------------------------------------------

int main() {
    antihook_init(
        on_attack,
        1,      // kill scanners
        0,      // self-kill on attack (1 = hard mode)
        250,
        1400
    );

    for (int i = 0; i < 100; ++i) {
        ANTIHOOK_GUARD;
        usleep(50000);
    }

    g_running.store(false);
    return 0;
}



static auto lastScreenshotTime = std::chrono::steady_clock::now();
constexpr std::chrono::seconds screenshotInterval(600);

#define MIN_SEARCH_LENGTH 3

static const std::string favFilePath = "/storage/emulated/0/Download/NotaSkins.cpp";
static std::set<std::string> favorites;
static std::mutex g_FavMutex;
static std::atomic<bool> g_NeedsSave(false);
static std::map<std::string, int> toggleCounter;
static std::map<std::string, float> lastToggleTime;

void SaveFavoritesToFile() {
    std::lock_guard<std::mutex> lock(g_FavMutex);
    std::ofstream outFile(favFilePath);
    if (!outFile.is_open()) return;

    for (const auto& fav : favorites) {
        outFile << fav << "\n";
    }
    outFile.close();
}

void BackgroundSaveThread() {
    while (true) {
        if (g_NeedsSave) {
            g_NeedsSave = false;
            SaveFavoritesToFile();
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

void TriggerSave() {
    g_NeedsSave = true;
}

void LoadFavoritesFromFile() {
    std::lock_guard<std::mutex> lock(g_FavMutex);
    std::ifstream inFile(favFilePath);
    if (!inFile.is_open()) return;

    favorites.clear();
    std::string line;
    while (std::getline(inFile, line)) {
        if (!line.empty() && line[line.length() - 1] == '\r') {
            line.resize(line.length() - 1);
        }
        if (!line.empty()) {
            favorites.insert(line);
        }
    }
    inFile.close();
}

void GetDeviceData(char* model, char* osVer, char* ramStr, float* temp) {
    static char staticModel[64] = "";
    static char staticOs[16] = "";
    static bool initialized = false;
    static float startTime = (float)ImGui::GetTime();
    
    static float lastUpdate = -30.0f;
    static char cachedRam[32] = "0.0GB / 0.0GB";
    static float currentRamUsage = 4.5f; 
    static float currentTemp = 40.5f;

    if (!initialized) {
        __system_property_get("ro.product.model", staticModel);
        __system_property_get("ro.build.version.release", staticOs);
        initialized = true;
    }

    if (ImGui::GetTime() - lastUpdate > 30.0f) {
        float runTime = (float)ImGui::GetTime() - startTime;
        float progress = (sinf(runTime * 0.00087f) * 0.5f + 0.5f);
        
        float targetRam = 4.2f + (progress * 1.5f);
        float targetTemp = 39.0f + (progress * 8.0f);

        currentRamUsage += (targetRam - currentRamUsage) * 0.1f;
        currentTemp += (targetTemp - currentTemp) * 0.1f;

        currentRamUsage += ((static_cast<float>(rand() % 9) - 4.0f) / 100.0f);
        currentTemp += ((static_cast<float>(rand() % 7) - 3.0f) / 10.0f);

        struct sysinfo memInfo;
        double actualTotal = 11.2;
        if (sysinfo(&memInfo) == 0) {
            double totalRamGB = (double)memInfo.totalram / 1024.0 / 1024.0 / 1024.0;
            actualTotal = ((double)((long)(totalRamGB * 10.0 + 0.5)) / 10.0);
        }

        snprintf(cachedRam, 32, "%.1fGB / %.1fGB", currentRamUsage, actualTotal);
        
        lastUpdate = (float)ImGui::GetTime();
    }

    strncpy(model, staticModel, 64);
    strncpy(osVer, staticOs, 16);
    strncpy(ramStr, cachedRam, 32);
    *temp = currentTemp;
}

std::string GetBaseWeaponName(const std::string& fullName)
{
    size_t dashPos = fullName.find(" - ");
    if (dashPos == std::string::npos)
        return fullName;
    std::string base = fullName.substr(0, dashPos);
    size_t tagEnd = base.find("] ");
    if (tagEnd != std::string::npos && tagEnd + 2 < base.length())
        base = base.substr(tagEnd + 2);
    return base;
}

void SelectSnowboardSkin(int skinId)
{
    void* selectedSkin = FindVehicleSkinConfigById(skinId);
    if (!SkinPtr(selectedSkin))
        return;

    auto* fields = (VehicleSkinConfFields*)((uintptr_t)selectedSkin + 0x10);
    if (!SkinPtr(fields))
        return;

    activeVehicleSkins[31707110] = skinId;
    activeVehicleSkinsById[(int)fields->VehicleId] = skinId;
    activeVehicleSkinConfs[skinId] = selectedSkin;
}

void RenderRarityBadge(const char* name) {
    if (!name) return;

    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    
    ImVec4 badgeColor = ImVec4(0.5f, 0.5f, 0.5f, 1.0f);
    const char* label = "C";

    if (name[0] == '[' && name[2] == ']') {
        char rarity = name[1];
        if (rarity >= 'a' && rarity <= 'z') {
            rarity = rarity - ('a' - 'A');
        }

        if (rarity == 'M') {
            badgeColor = ImVec4(0.75f, 0.15f, 0.15f, 1.0f);
            label = "M";
        } else if (rarity == 'L') {
            badgeColor = ImVec4(0.85f, 0.70f, 0.10f, 1.0f);
            label = "L";
        } else if (rarity == 'E') {
            badgeColor = ImVec4(0.55f, 0.25f, 0.75f, 1.0f);
            label = "E";
        } else if (rarity == 'C') {
            badgeColor = ImVec4(0.20f, 0.60f, 0.20f, 1.0f);
            label = "C";
        }
    }

    float badgeSize = 23.0f;
    float yOffset = 0.1f;

    draw_list->AddRectFilled(
        ImVec2(p.x, p.y + yOffset), 
        ImVec2(p.x + badgeSize, p.y + badgeSize + yOffset), 
        ImGui::GetColorU32(badgeColor), 5.0f
    );

    ImVec2 textSize = ImGui::CalcTextSize(label);
    ImVec2 textPos = ImVec2(
        p.x + (badgeSize - textSize.x) * 0.5f,
        p.y + yOffset + (badgeSize - textSize.y) * 0.5f
    );
    
    draw_list->AddText(textPos, ImColor(255, 255, 255), label);

    ImGui::SetCursorScreenPos(ImVec2(p.x + badgeSize + 8, p.y));
  }

void ApplyBestSkinToAllWeapons() {
    if (bestSkinForWeapon.empty()) return;

    for (auto& kv : bestSkinForWeapon) {
        int baseID = kv.first;
        int skinID = kv.second;

        for (auto conf : weaponConfInstance) {
            if (!conf) continue;
            weaponconfFields = (WeaponConfFields*)((uintptr_t)conf + 0x20);
            if (weaponconfFields->ID == baseID || weaponconfFields->ID == skinID) {
                weaponconfFields->DefWeaponSkinID = skinID;
                break;
            }
        }
    }

    for (auto& gi : itemData) {
        int baseID = gi.WeaponConf.empty() ? 0 : gi.WeaponConf[0];
        if (baseID == 0) continue;

        auto it = bestSkinForWeapon.find(baseID);
        if (it == bestSkinForWeapon.end()) continue;
        int skinID = it->second;

        for (auto item : itemInventoryInstance) {
            if (!item) continue;
            item2Fields = (Item2InventoryFields*)((uintptr_t)item + 0x20);
            if (item2Fields->ItemID == gi.Item2Inventory[0] ||
                item2Fields->ItemID == gi.Item2Inventory[0] + 200) {
                item2Fields->WeaponAssetGroupID = gi.Item2Inventory[1];
                item2Fields->WeaponIconID       = gi.Item2Inventory[2];
            }
        }

        for (auto extra : weaponExtraInstance) {
            if (!extra) continue;
            weaponextraFields = (WeaponConfExtraFields*)((uintptr_t)extra + 0x10);
            if (weaponextraFields->ID == gi.WeaponExtra[0] ||
                weaponextraFields->ID == gi.WeaponConf[2]  ||
                gi.Item2Inventory[0] + 200 == weaponextraFields->ID) {
                if (gi.itemName.find("[M]") != std::string::npos) {
                    weaponextraFields->DefaultMythicArmor = 0;
                    if (gi.WeaponExtra[2] > 0)
                        weaponextraFields->DefaultMythicSig = gi.WeaponExtra[2];
                }
                weaponextraFields->DefaultDeadReplayEffectId = gi.WeaponExtra[3];
                weaponextraFields->DefaultKillEffectId       = gi.WeaponExtra[4];
            }
        }

        for (auto conf : weaponConfInstance) {
            if (!conf) continue;
            weaponconfFields = (WeaponConfFields*)((uintptr_t)conf + 0x20);
            if (gi.WeaponConf[0] == weaponconfFields->ID ||
                gi.Item2Inventory[0] + 200 == weaponconfFields->ID) {
                weaponconfFields->ColorID            = gi.WeaponConf[1];
                weaponconfFields->DefWeaponSkinID    = skinID;
                weaponconfFields->DefaultKillBrocast = gi.WeaponConf[3];
                if (gi.LOCID_Name) weaponconfFields->LOCID_Name = gi.LOCID_Name;
                if (gi.LOCID_Desc) weaponconfFields->LOCID_Desc = gi.LOCID_Desc;
            }
        }

        for (auto asset : weaponAssetGroupInstance) {
            if (!asset) continue;
            weaponAssetFields = (WeaponAssetGroupFields*)((uintptr_t)asset + 0x40);
            if (weaponAssetFields->Id == gi.WeaponAsset[0]) {
                if (gi.WeaponAsset[1] / 10 == gi.WeaponAsset[2] / 10 &&
                    gi.WeaponAsset[1] > 0)
                    weaponAssetFields->FireEffectGroupID = gi.WeaponAsset[1];
            }
        }

        for (auto ir : itemResourceConfigInstance) {
            if (!ir) continue;
            itemFields = (ItemResourceFields*)((uintptr_t)ir + 0x10);
            if (itemFields->ID == gi.Item2Inventory[0]) {
                itemFields->FxAssetID          = gi.ItemResInt[0];
                itemFields->InventoryModelID   = gi.ItemResInt[1];
                itemFields->ModelAssetIDRaw    = gi.ItemResInt[2];
                itemFields->UIMiniSpriteName   = gi.ItemRes[0];
                itemFields->UISmallSpriteName  = gi.ItemRes[1];
                itemFields->UISpriteName       = gi.ItemRes[2];
                itemFields->UISquareSpriteName = gi.ItemRes[3];
            }
        }

        applykilleffects[gi.Item2Inventory[0]]       = gi.WeaponExtra[4];
        applykilleffects[gi.Item2Inventory[0] + 200] = gi.WeaponExtra[4];
        applyBrocast[gi.Item2Inventory[0]]           = gi.WeaponConf[3];
        applyBrocast[gi.Item2Inventory[0] + 200]     = gi.WeaponConf[3];

        xBool[gi.itemName] = true;
    }
}

std::string GetCleanName(std::string name) {
    size_t pos = name.find("] ");
    if (pos != std::string::npos) {
        return name.substr(pos + 2);
    }
    return name;
}

class _BYTE;

class _BOOL4;

class _BOOL8;

class _WORD;

class _DWORD;

class _QWORD;

bool ClearDisplay = false;
bool g_HideFromRecord = false;
bool SnowB = false;
float SnowBsize = 0.0f;
bool isSpeedHackEnabled = false;
float speedHackMultiplier = 0.0f;
bool isJumpAdjustmentEnabled = false;
float jumpHeightMultiplier = 1.0f;


// -----------------------------------------------------------------------------
// Animated menu backdrop — presentation only.
// Drawn behind the feature cards so the menu has a subtle living background.
// -----------------------------------------------------------------------------
static void DrawAnimatedMenuBackdrop(ImDrawList* dl, const ImVec2& mn, const ImVec2& mx, float t)
{
    if (!dl) return;

    const float w = mx.x - mn.x;
    const float h = mx.y - mn.y;
    const ImVec2 c(mn.x + w * 0.5f, mn.y + h * 0.5f);

    // Dark translucent base so the animation remains visible through the
    // feature cards instead of looking like a static black rectangle.
    dl->AddRectFilled(mn, mx, IM_COL32(2, 2, 5, 145), 12.0f);

    // Large moving neon "aurora" blobs.
    for (int i = 0; i < 8; ++i) {
        const float fi = (float)i;
        const float a = t * (0.16f + fi * 0.013f) + fi * 0.82f;
        const float px = c.x + cosf(a) * (w * (0.18f + (i % 3) * 0.10f));
        const float py = c.y + sinf(a * 1.23f) * (h * (0.20f + (i % 4) * 0.055f));
        const float r = 75.0f + 35.0f * (0.5f + 0.5f * sinf(t * 1.2f + fi));

        dl->AddCircleFilled(
            ImVec2(px, py), r,
            (i & 1)
                ? IM_COL32(145, 105, 255, 34)
                : IM_COL32(220, 215, 255, 30),
            64
        );

        dl->AddCircle(
            ImVec2(px, py), r * 0.72f,
            (i & 1)
                ? IM_COL32(150, 115, 255, 58)
                : IM_COL32(230, 225, 255, 46),
            64, 1.2f
        );
    }

    // Perspective-like moving grid.
    const float grid = 36.0f;
    const float sx = fmodf(t * 18.0f, grid);
    const float sy = fmodf(t * 11.0f, grid);

    for (float x = -grid + sx; x < w + grid; x += grid) {
        dl->AddLine(
            ImVec2(mn.x + x, mn.y),
            ImVec2(mn.x + x + h * 0.18f, mx.y),
            IM_COL32(115, 92, 180, 46), 1.0f
        );
    }

    for (float y = -grid + sy; y < h + grid; y += grid) {
        dl->AddLine(
            ImVec2(mn.x, mn.y + y),
            ImVec2(mx.x, mn.y + y),
            IM_COL32(135, 110, 205, 36), 1.0f
        );
    }

    // 55 drifting particles with brighter pulses.
    constexpr int particleCount = 55;
    ImVec2 pts[particleCount];

    for (int i = 0; i < particleCount; ++i) {
        const float fi = (float)i;
        const float bx = fmodf(fi * 97.37f + 31.0f, 997.0f) / 997.0f;
        const float by = fmodf(fi * 53.11f + 77.0f, 991.0f) / 991.0f;

        float x = fmodf(bx * w + t * (8.0f + (i % 6) * 2.4f), w);
        float y = fmodf(by * h - t * (5.0f + (i % 5) * 1.7f) + h, h);

        x += sinf(t * 0.8f + fi) * 18.0f;
        y += cosf(t * 0.65f + fi * 0.73f) * 14.0f;

        if (x < 0) x += w;
        if (x >= w) x -= w;
        if (y < 0) y += h;
        if (y >= h) y -= h;

        pts[i] = ImVec2(mn.x + x, mn.y + y);

        const float pulse = 0.5f + 0.5f * sinf(t * 2.4f + fi * 0.61f);
        const float r = 1.3f + pulse * 2.0f;
        const int alpha = (int)(65.0f + pulse * 95.0f);

        dl->AddCircleFilled(
            pts[i], r,
            (i % 3 == 0)
                ? IM_COL32(190, 165, 255, alpha)
                : IM_COL32(225, 220, 255, alpha - 10),
            16
        );

        if (i % 4 == 0) {
            dl->AddLine(
                pts[i],
                ImVec2(pts[i].x - 22.0f, pts[i].y + 10.0f),
                IM_COL32(180, 150, 255, 110), 1.2f
            );
        }
    }

    // Animated constellation connections.
    for (int i = 0; i < particleCount; ++i) {
        for (int j = i + 1; j < particleCount; ++j) {
            const float dx = pts[i].x - pts[j].x;
            const float dy = pts[i].y - pts[j].y;
            const float d2 = dx * dx + dy * dy;

            if (d2 < 72.0f * 72.0f) {
                const float d = sqrtf(d2);
                const float fade = 1.0f - d / 72.0f;
                dl->AddLine(
                    pts[i], pts[j],
                    IM_COL32(175, 145, 255, (int)(fade * 105.0f)),
                    1.0f
                );
            }
        }
    }

    // Two clearly visible diagonal light sweeps.
    const float sweep = fmodf(t * 120.0f, w + h + 240.0f) - h;
    dl->AddLine(
        ImVec2(mn.x + sweep, mx.y),
        ImVec2(mn.x + sweep + h, mn.y),
        IM_COL32(205, 180, 255, 150), 3.0f
    );
    dl->AddLine(
        ImVec2(mn.x + sweep + 20.0f, mx.y),
        ImVec2(mn.x + sweep + h + 20.0f, mn.y),
        IM_COL32(190, 160, 255, 75), 1.0f
    );

    // Horizontal scan beam.
    const float scanY = mn.y + fmodf(t * 42.0f, h + 100.0f) - 50.0f;
    dl->AddRectFilled(
        ImVec2(mn.x, scanY),
        ImVec2(mx.x, scanY + 5.0f),
        IM_COL32(180, 145, 255, 70),
        2.0f
    );

    // Soft animated vignette rings.
    const float ringPulse = 0.5f + 0.5f * sinf(t * 1.7f);
    for (int i = 0; i < 4; ++i) {
        dl->AddCircle(
            c,
            120.0f + i * 75.0f + ringPulse * 12.0f,
            IM_COL32(135, 105, 210, 28 - i * 3),
            96, 1.0f
        );
    }
}

void RenderStyledToggle(const char *label, bool *v)
{
    ImGui::PushID(label);

    ImDrawList* draw_list = ImGui::GetWindowDrawList();

    const float box = 24.0f;
    const float rounding = 7.0f;

    ImGui::TextUnformatted(label);
    const float rightSide =
        ImGui::GetContentRegionMax().x - box -
        ImGui::GetStyle().ItemSpacing.x;
    ImGui::SameLine(rightSide);

    const ImVec2 p = ImGui::GetCursorScreenPos();

    if (ImGui::InvisibleButton("##check_toggle", ImVec2(box, box)))
        *v = !*v;

    const bool hovered = ImGui::IsItemHovered();

    // Compact rounded checkbox: OFF = dark glass, ON = cyan with a ✓.
    const ImU32 bg = *v
        ? (hovered ? IM_COL32(45, 220, 255, 255) : IM_COL32(20, 185, 235, 245))
        : (hovered ? IM_COL32(35, 55, 68, 235) : IM_COL32(18, 27, 35, 225));

    const ImU32 border = *v
        ? IM_COL32(125, 245, 255, 255)
        : IM_COL32(80, 105, 120, 220);

    draw_list->AddRectFilled(
        p, ImVec2(p.x + box, p.y + box),
        bg, rounding
    );
    draw_list->AddRect(
        p, ImVec2(p.x + box, p.y + box),
        border, rounding, 0, 1.4f
    );

    if (*v) {
        const ImVec2 a(p.x + 5.0f, p.y + 12.5f);
        const ImVec2 b(p.x + 10.0f, p.y + 17.0f);
        const ImVec2 c(p.x + 19.0f, p.y + 7.0f);

        draw_list->AddLine(a, b, IM_COL32(255,255,255,255), 2.4f);
        draw_list->AddLine(b, c, IM_COL32(255,255,255,255), 2.4f);
    }

    ImGui::PopID();
}

void RenderStyledSlider(const char* label, float* v, float v_min, float v_max)
{
    ImGui::PushID(label);
    
    if (label[0] != '#' || label[1] != '#') {
        ImGui::TextUnformatted(label);
    }
    
    ImVec2 p = ImGui::GetCursorScreenPos();
    p.x += 6.0f;
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    float width = ImGui::GetContentRegionAvail().x - 12.0f;
    float height = 30.0f;
    float radius = 10.0f;
    float track_height = 5.0f;
    

    ImGui::InvisibleButton("##slider_btn", ImVec2(width, height));
    
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0))
    {
        float mouse_x = ImGui::GetIO().MousePos.x;
        float clicked_pos = (mouse_x - p.x) / width;
        if (clicked_pos < 0.0f) clicked_pos = 0.0f;
        if (clicked_pos > 1.0f) clicked_pos = 1.0f;
        *v = v_min + (v_max - v_min) * clicked_pos;
    }

    float t = (*v - v_min) / (v_max - v_min);
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;

    ImVec2 track_start = ImVec2(p.x, p.y + height * 0.5f);
    ImVec2 track_end = ImVec2(p.x + width, p.y + height * 0.5f);
    ImVec2 grab_pos = ImVec2(p.x + (t * width), p.y + height * 0.5f);

    draw_list->AddLine(track_start, track_end, IM_COL32(60, 60, 60, 255), track_height);
    draw_list->AddLine(track_start, grab_pos, IM_COL32(55, 220, 255, 255), track_height);
    draw_list->AddCircleFilled(grab_pos, radius, IM_COL32(255, 255, 255, 255));

    ImGui::PopID();
}
    
struct ConfigData {
    bool Esp;
    bool PlayerLine;
    bool Box;
    bool Health;
    bool Name;
    bool Distance;
    bool Count;
    bool Alert;
    int CrosshairType;
    float AimSize;
    bool Crosshair;
    bool Aimline;
    bool AimAssist;
    float AimAssistSize;
    bool Kinetic;
    bool Recoil;
    bool Spread;
    bool Reload;
    bool Scope;
    bool Switch;
    bool Shake;
    bool Flash;
    bool Small;
    bool Cost;
    bool Rpd;
    bool Range;
    bool AutoSnipe;
    bool Hit;
    bool Auto;
    bool Fire;
    bool SnowB;
    float SnowBsize;
    bool SlideTackle;
    float SlideRange;
    bool SpeedHack;
    float SpeedMultiplier;
    bool JumpAdjustment;
    float JumpMultiplier;
    bool Spectate;
    bool Outline;
    bool RedWallhack;
    bool WallHack;
    bool Red;
    bool JetJ;
    bool JetS;
    bool Execute;
    bool Radar1;
    bool Parachute;
    bool Diving;
    bool Aimbot360;
    bool BulletTrack;
    int Target;
    int Trigger;
    int By;
    bool Memento;
    bool Morning;
    bool Amoeba;
    bool Aks;
    bool Quan;
    bool Glorious;
    bool Neon;
    bool Celestial;
    bool Bam;
    bool Demon;
    bool Lotus;
    bool Phoenix;
    bool Qq;
    bool Song;
    bool Siege;
    bool Templar;
    bool Spectre;
    bool Darkside;
    bool FpsLevel;                
    float FpsLevel1;             
    bool showFPSLevelSlider;      
    bool FpsLevelUltra;           
    float FpsLevelUltra1;        
    bool showFPSLevelUltraSlider; 
    bool Frame;                  
    bool Fpss;                    
};

void saveAllConfig() {
    ConfigData config;
       
    config.Esp = Config.ESPMenu.Esp;
    config.PlayerLine = Config.ESPMenu.isPlayerLine;
    config.Box = Config.ESPMenu.Box;
    config.Health = Config.ESPMenu.Health;
    config.Name = Config.ESPMenu.Name;
    config.Distance = Config.ESPMenu.Distance;
    config.Count = Config.ESPMenu.Count;
    config.Alert = Config.ESPMenu.Alert;
    config.CrosshairType = static_cast<int>(Config.ESPMenu.CrosshairType);
    config.AimSize = Config.Aim.size;
    config.Crosshair = Config.ESPMenu.Crosshair;
    config.Aimline = Config.ESPMenu.Aimline;
  
    config.AimAssist = Config.Aim.AimAssist;
    config.AimAssistSize = Config.Aim.AimAssistSize;
    config.Kinetic = Config.ExtraMenu.Kinetic;
    config.Recoil = Config.ExtraMenu.Recoil;
    config.Spread = Config.ExtraMenu.Spread;
    config.Reload = Config.ExtraMenu.Reload;
    config.Scope = Config.ExtraMenu.Scope;
    config.Switch = Config.ExtraMenu.Switch;
    config.Shake = Config.ExtraMenu.Shake;
    config.Flash = Config.ExtraMenu.Flash;
    config.Small = Config.ExtraMenu.Small;
    config.Cost = Config.ExtraMenu.Cost;
    config.Rpd = Config.ExtraMenu.Rpd;
    config.Range = Config.ExtraMenu.Range;
    config.AutoSnipe = Config.ExtraMenu.AutoSnipe;
    config.Hit = Config.ExtraMenu.Hit;
    config.Auto = Config.ExtraMenu.Auto;

    config.SnowB = SnowB;
    config.SnowBsize = SnowBsize;
    config.SlideTackle = SlideTackle;
    config.SlideRange = SlideRange;
    config.SpeedHack = isSpeedHackEnabled;
    config.SpeedMultiplier = speedHackMultiplier;
    config.JumpAdjustment = isJumpAdjustmentEnabled;
    config.JumpMultiplier = jumpHeightMultiplier;
    config.Spectate = Config.ExtraMenu.Spectate;
    config.Outline = Config.ExtraMenu.Outline;
    config.RedWallhack = Config.ExtraMenu.RedWallhack;
    config.WallHack = Config.ExtraMenu.WallHack;
    config.Red = Config.ExtraMenu.Red;
    config.JetJ = Config.ExtraMenu.JetJ;
    config.JetS = Config.ExtraMenu.JetS;
    config.Execute = isExecute;
    config.Radar1 = Config.ExtraMenu.Radar1;
    config.Parachute = Config.ExtraMenu.Parachute;
    config.Diving = Config.ExtraMenu.Diving;

    config.Aimbot360 = Config.Aim.Aimbot360;
    config.BulletTrack = Config.Aim.BulletTrack;
    config.Target = static_cast<int>(Config.Aim.Target);
    config.Trigger = static_cast<int>(Config.Aim.Trigger);
    config.By = static_cast<int>(Config.Aim.By);

    config.Memento = Config.ExtraMenu.Memento;
    config.Morning = Config.ExtraMenu.Morning;
    config.Amoeba = Config.ExtraMenu.Amoeba;
    config.Aks = Config.ExtraMenu.Aks;
    config.Quan = Config.ExtraMenu.Quan;
    config.Glorious = Config.ExtraMenu.Glorious;
    config.Neon = Config.ExtraMenu.Neon;
    config.Celestial = Config.ExtraMenu.Celestial;
    config.Bam = Config.ExtraMenu.Bam;
    config.Demon = Config.ExtraMenu.Demon;
    config.Lotus = Config.ExtraMenu.Lotus;
    config.Phoenix = Config.ExtraMenu.Phoenix;
    config.Qq = Config.ExtraMenu.Qq;
    config.Song = Config.ExtraMenu.Song;
    config.Siege = Config.ExtraMenu.Siege;
    config.Templar = Config.ExtraMenu.Templar;
    config.Spectre = Config.ExtraMenu.Spectre;
    config.Darkside = Config.ExtraMenu.Darkside;

    config.FpsLevel = Config.Aim.FpsLevel;
    config.FpsLevel1 = Config.Aim.FpsLevel1;
    config.Frame = Config.ExtraMenu.Frame;
    config.Fpss = Config.ExtraMenu.Fpss;

    std::ofstream file("/storage/emulated/0/Download/tan_config.dat", std::ios::binary);
    if (file.is_open()) {
        file.write(reinterpret_cast<char*>(&config), sizeof(ConfigData));
        file.close();
        ImGui::OpenPopup("Config Saved");
    } else {
        ImGui::OpenPopup("Config Save Error");
    }
}

bool loadAllConfig() {
    ConfigData config;
    std::ifstream file("/storage/emulated/0/Download/tan_config.dat", std::ios::binary);
    if (file.is_open()) {
        file.read(reinterpret_cast<char*>(&config), sizeof(ConfigData));
        file.close();

        Config.ESPMenu.Esp = config.Esp;
        Config.ESPMenu.isPlayerLine = config.PlayerLine;
        Config.ESPMenu.Box = config.Box;
        Config.ESPMenu.Health = config.Health;
        Config.ESPMenu.Name = config.Name;
        Config.ESPMenu.Distance = config.Distance;
        Config.ESPMenu.Count = config.Count;
        Config.ESPMenu.Alert = config.Alert;
        Config.ESPMenu.CrosshairType = static_cast<decltype(Config.ESPMenu.CrosshairType)>(config.CrosshairType);
        Config.Aim.size = config.AimSize;
        Config.ESPMenu.Crosshair = config.Crosshair;
        Config.ESPMenu.Aimline = config.Aimline;

        Config.Aim.AimAssist = config.AimAssist;
        Config.Aim.AimAssistSize = config.AimAssistSize;
        Config.Aim.showAimAssistSlider = config.AimAssist;
        Config.ExtraMenu.Kinetic = config.Kinetic;
        Config.ExtraMenu.Recoil = config.Recoil;
        Config.ExtraMenu.Spread = config.Spread;
        Config.ExtraMenu.Reload = config.Reload;
        Config.ExtraMenu.Scope = config.Scope;
        Config.ExtraMenu.Switch = config.Switch;
        Config.ExtraMenu.Shake = config.Shake;
        Config.ExtraMenu.Flash = config.Flash;
        Config.ExtraMenu.Small = config.Small;
        Config.ExtraMenu.Cost = config.Cost;
        Config.ExtraMenu.Rpd = config.Rpd;
        Config.ExtraMenu.Range = config.Range;
        Config.ExtraMenu.AutoSnipe = config.AutoSnipe;
        Config.ExtraMenu.Hit = config.Hit;
        Config.ExtraMenu.Auto = config.Auto;

        SnowB = config.SnowB;
        SnowBshow = config.SnowB;
        SnowBsize = config.SnowBsize;
        SlideTackle = config.SlideTackle;
        SlideShow = config.SlideTackle;
        SlideRange = config.SlideRange;
        isSpeedHackEnabled = config.SpeedHack;
        showSpeedHackSlider = config.SpeedHack;
        speedHackMultiplier = config.SpeedMultiplier;
        isJumpAdjustmentEnabled = config.JumpAdjustment;
        jumpHeightMultiplier = config.JumpMultiplier;
        Config.ExtraMenu.Spectate = config.Spectate;
        Config.ExtraMenu.Outline = config.Outline;
        config.RedWallhack = Config.ExtraMenu.RedWallhack;
        Config.ExtraMenu.WallHack = config.WallHack;
        Config.ExtraMenu.Red = config.Red;
        Config.ExtraMenu.JetJ = config.JetJ;
        Config.ExtraMenu.JetS = config.JetS;
        isExecute = config.Execute;
        Config.ExtraMenu.Radar1 = config.Radar1;
        Config.ExtraMenu.Parachute = config.Parachute;
        Config.ExtraMenu.Diving = config.Diving;

        Config.Aim.Aimbot360 = config.Aimbot360;
        Config.Aim.BulletTrack = config.BulletTrack;
        Config.Aim.Target = static_cast<decltype(Config.Aim.Target)>(config.Target);
        Config.Aim.Trigger = static_cast<decltype(Config.Aim.Trigger)>(config.Trigger);
        Config.Aim.By = static_cast<decltype(Config.Aim.By)>(config.By);

        Config.ExtraMenu.Memento = config.Memento;
        Config.ExtraMenu.Morning = config.Morning;
        Config.ExtraMenu.Amoeba = config.Amoeba;
        Config.ExtraMenu.Aks = config.Aks;
        Config.ExtraMenu.Quan = config.Quan;
        Config.ExtraMenu.Glorious = config.Glorious;
        Config.ExtraMenu.Neon = config.Neon;
        Config.ExtraMenu.Celestial = config.Celestial;
        Config.ExtraMenu.Bam = config.Bam;
        Config.ExtraMenu.Demon = config.Demon;
        Config.ExtraMenu.Lotus = config.Lotus;
        Config.ExtraMenu.Phoenix = config.Phoenix;
        Config.ExtraMenu.Qq = config.Qq;
        Config.ExtraMenu.Song = config.Song;
        Config.ExtraMenu.Siege = config.Siege;
        Config.ExtraMenu.Templar = config.Templar;
        Config.ExtraMenu.Spectre = config.Spectre;
        Config.ExtraMenu.Darkside = config.Darkside;

        Config.Aim.FpsLevel = config.FpsLevel;
        Config.Aim.showFPSLevelSlider = config.FpsLevel;
        Config.Aim.FpsLevel1 = config.FpsLevel1;
        Config.ExtraMenu.Frame = config.Frame;
        Config.ExtraMenu.Fpss = config.Fpss;

        return true;
    }
    return false;
}

#define _BYTE uint8_t
#define _WORD  uint8_t
#define _DWORD uint64_t
#define _QWORD uint64_t
#define _BOOL4 uint8_t

#define SPAMSINT1() int __xbypass_any = __LINE__; int any_xbypass = __LINE__; if (!strstr(oxorany("stoler"), oxorany("relots"))) { __xbypass_any--; any_xbypass++; if (__xbypass_any != any_xbypass && strstr(oxorany("better"), oxorany("better"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("learn"), oxorany("nrael"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("first"), oxorany("tsrif"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("you"), oxorany("you"))) { __xbypass_any++; any_xbypass--; if (!strstr(oxorany("are"), oxorany("era"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("DUMB"), oxorany("DUMB"))) { __xbypass_any = __xbypass_any - any_xbypass; any_xbypass = any_xbypass + __xbypass_any; } else { __xbypass_any = __xbypass_any + any_xbypass; any_xbypass = any_xbypass - __xbypass_any; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; }  } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } __xbypass_any++; return 1
#define SPAMS() int __xbypass_any = __LINE__; int any_xbypass = __LINE__; if (!strstr(oxorany("stoler"), oxorany("relots"))) { __xbypass_any--; any_xbypass++; if (__xbypass_any != any_xbypass && strstr(oxorany("better"), oxorany("better"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("learn"), oxorany("nrael"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("first"), oxorany("tsrif"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("you"), oxorany("you"))) { __xbypass_any++; any_xbypass--; if (!strstr(oxorany("are"), oxorany("era"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("DUMB"), oxorany("DUMB"))) { __xbypass_any = __xbypass_any - any_xbypass; any_xbypass = any_xbypass + __xbypass_any; } else { __xbypass_any = __xbypass_any + any_xbypass; any_xbypass = any_xbypass - __xbypass_any; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; }  } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } any_xbypass = any_xbypass + __xbypass_any
#define SPAMSINT0() int __xbypass_any = __LINE__; int any_xbypass = __LINE__; if (!strstr(oxorany("stoler"), oxorany("relots"))) { __xbypass_any--; any_xbypass++; if (__xbypass_any != any_xbypass && strstr(oxorany("better"), oxorany("better"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("learn"), oxorany("nrael"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("first"), oxorany("tsrif"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("you"), oxorany("you"))) { __xbypass_any++; any_xbypass--; if (!strstr(oxorany("are"), oxorany("era"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("DUMB"), oxorany("DUMB"))) { __xbypass_any = __xbypass_any - any_xbypass; any_xbypass = any_xbypass + __xbypass_any; } else { __xbypass_any = __xbypass_any + any_xbypass; any_xbypass = any_xbypass - __xbypass_any; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; }  } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } return (__xbypass_any & any_xbypass)
#define SPAMSINTTYPE(typex, any) int __xbypass_any = __LINE__; int any_xbypass = __LINE__; if (!strstr(oxorany("stoler"), oxorany("relots"))) { __xbypass_any--; any_xbypass++; if (__xbypass_any != any_xbypass && strstr(oxorany("better"), oxorany("better"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("learn"), oxorany("nrael"))) { __xbypass_any--; any_xbypass++; if (!strstr(oxorany("first"), oxorany("tsrif"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("you"), oxorany("you"))) { __xbypass_any++; any_xbypass--; if (!strstr(oxorany("are"), oxorany("era"))) { __xbypass_any++; any_xbypass--; if (strstr(oxorany("DUMB"), oxorany("DUMB"))) { __xbypass_any = __xbypass_any - any_xbypass; any_xbypass = any_xbypass + __xbypass_any; } else { __xbypass_any = __xbypass_any + any_xbypass; any_xbypass = any_xbypass - __xbypass_any; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; } } else { __xbypass_any--; any_xbypass++; }  } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } } else { __xbypass_any++; any_xbypass--; } return (typex)(__xbypass_any & any_xbypass)

#include <fstream>
using namespace std;

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>


ImFont* medium;
ImFont* bold;
ImFont* tab_icons;
ImFont* logo;
ImFont* tab_title;
ImFont* tab_title_icon;
ImFont* subtab_title;
ImFont* combo_arrow;
ImFont* F50;

float AVIWA = 119.167f;

bool wallh, smoke;
bool Memento, Glorious, Neon, Radiance, Celestial, Bam,
     Demon, Lotus, Qq, Phoenix, Song, Siege,
     Templar, Spectre, Darkside, Amoeba, Morning, Aks, Quan = false;

struct sRegion
{
    uintptr_t start, end;

};

std::chrono::steady_clock::time_point appStartTime = std::chrono::steady_clock::now();

std::string FormatTimeDuration(std::chrono::steady_clock::duration duration) {
    auto hours = std::chrono::duration_cast<std::chrono::hours>(duration).count();
    auto minutes = std::chrono::duration_cast<std::chrono::minutes>(duration % std::chrono::hours(1)).count();
    auto seconds = std::chrono::duration_cast<std::chrono::seconds>(duration % std::chrono::minutes(1)).count();

    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%02d:%02d:%02d", hours, minutes, seconds);
    return std::string(buffer);
}

static std::string EXP ="";
static std::string storedKey ="";

// Login/account state used by the login UI.
std::string usedKey;
std::string userType;
std::time_t expiryTimestamp = 0;

// Parses the server expiry date in YYYY-MM-DD or YYYY-MM-DD HH:MM:SS format.
std::time_t parseExpiryDate(const std::string& value) {
    std::tm parsed = {};
    const char* formats[] = {"%Y-%m-%d %H:%M:%S", "%Y-%m-%d"};
    for (const char* format : formats) {
        parsed = {};
        char* end = strptime(value.c_str(), format, &parsed);
        if (end != nullptr && *end == '\\0') {
            parsed.tm_isdst = -1;
            return std::mktime(&parsed);
        }
    }
    return 0; // Invalid/unrecognized expiry date.
}

static char s[256];

int g_TotalMatches = 0;

void RenderFloatingInfo(ImDrawList* draw, float screenWidth, float screenHeight)
{
    static bool wasInMatch = false;
    static float lastTimeUpdate = 0;
    static float lastMatchCheck = 0;
    static bool isInMatch = false;
    static char dateStr[64] = {0}, timeStr[64] = {0};
    static char matchStr[16] = "0"; 

    if (Config.ExtraMenu.ClearDisplay) return;

    float time = (float)ImGui::GetTime();

    if (time - lastMatchCheck > 0.5f) {
        typedef void* (*t_get_MatchGame)();
        auto get_MatchGame = (t_get_MatchGame)(Class_Gameplay_get_MatchGame); 
        
        if (get_MatchGame != nullptr) {
            void* matchInstance = get_MatchGame();
            isInMatch = Tools::IsPtrValid(matchInstance);
        }
        lastMatchCheck = time;
    }

    if (isInMatch && !wasInMatch) {
        g_TotalMatches++;
        snprintf(matchStr, sizeof(matchStr), "%d", g_TotalMatches);
        wasInMatch = true;
    } else if (!isInMatch && wasInMatch) {
        wasInMatch = false;
    }

    if (time - lastTimeUpdate > 1.0f) {
        auto now = std::chrono::system_clock::now();
        std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
        std::tm localTime;
        localtime_r(&currentTime, &localTime);
        strftime(dateStr, sizeof(dateStr), "%b %d, 2026", &localTime);
        strftime(timeStr, sizeof(timeStr), "%I:%M %p", &localTime);
        lastTimeUpdate = time;
    }

    float glowPulse = (sinf(time * 3.0f) * 0.5f) + 0.5f; 
    float rainbowSpeed = 0.4f; 
    float hue = fmodf(time * rainbowSpeed, 1.0f);
    ImU32 titleRGB = ImGui::GetColorU32((ImVec4)ImColor::HSV(hue, 0.7f, 1.0f));

    ImU32 bgColor = IM_COL32(10, 10, 15, 210);
    ImU32 textColor = IM_COL32(230, 230, 230, 255);
    ImU32 labelColor = IM_COL32(180, 180, 180, 200);
    ImU32 dimBlueDevColor = IM_COL32(50, 110, 170, 150); 

    ImVec4 activeBlue = ImVec4(0.12f, 1.0f, 0.32f, 1.0f);
    ImU32 pulsedGlow = ImGui::GetColorU32(ImVec4(activeBlue.x, activeBlue.y, activeBlue.z, 0.4f + (glowPulse * 0.4f)));

    auto currentDuration = std::chrono::steady_clock::now() - appStartTime;
    std::string playTime = FormatTimeDuration(currentDuration);

    float pW = 260.0f;          
    float pH = 145.0f;          
    float pX = 15.0f;           
    float pY = screenHeight - pH - 15.0f; 

    ImVec2 min_p = ImVec2(pX, pY);
    ImVec2 max_p = ImVec2(pX + pW, pY + pH);

    draw->AddRectFilled(min_p, max_p, bgColor, 0.0f);

    float sideGlowWidth = 1.2f;
    float lineLength = 20.0f;

    auto DrawCornerGlow = [&](ImVec2 pos, ImVec2 d1, ImVec2 d2) {
        draw->AddLine(pos, ImVec2(pos.x + d1.x * lineLength, pos.y), pulsedGlow, sideGlowWidth);
        draw->AddLine(pos, ImVec2(pos.x, pos.y + d2.y * lineLength), pulsedGlow, sideGlowWidth);
    };

    DrawCornerGlow(min_p, ImVec2(1, 0), ImVec2(0, 1));
    DrawCornerGlow(ImVec2(max_p.x, min_p.y), ImVec2(-1, 0), ImVec2(0, 1));
    DrawCornerGlow(ImVec2(max_p.x, max_p.y), ImVec2(-1, 0), ImVec2(0, -1));
    DrawCornerGlow(ImVec2(min_p.x, max_p.y), ImVec2(1, 0), ImVec2(0, -1));

    ImGuiIO& io = ImGui::GetIO();
    ImFont* targetFont = nullptr;
    if (!io.Fonts->Fonts.empty()) {
        targetFont = io.Fonts->Fonts[0];
    }

    if (F50 && targetFont) {
        float baseFS = 30.0f * 0.6f; 
        float currY = pY + 10.0f; 

        draw->AddText(F50, baseFS + 3.0f, ImVec2(pX + 15, currY), titleRGB, "Call Of Duty | 1.6.56");
        
        draw->AddRectFilled(
            ImVec2(pX + 15, currY + 26), 
            ImVec2(pX + 85, currY + 28), 
            ImGui::GetColorU32(ImVec4(activeBlue.x, activeBlue.y, activeBlue.z, 0.6f)), 0.0f
        );
        
        currY += 32.0f; 
        float labelX = pX + 15.0f;
        float valueX = pX + 135.0f; 
        float spacing = 18.0f; 

        auto DrawRowOptimized = [&](const char* label, const char* value) {
            draw->AddText(targetFont, baseFS, ImVec2(labelX, currY), labelColor, label);
            draw->AddText(targetFont, baseFS, ImVec2(valueX - 12, currY), labelColor, ":");
            draw->AddText(targetFont, baseFS, ImVec2(valueX, currY), textColor, value);
            currY += spacing;
        };

        DrawRowOptimized("Date", dateStr);
        DrawRowOptimized("Time", timeStr);
        DrawRowOptimized("Session", playTime.c_str());
        DrawRowOptimized("Game Count", matchStr); 
        
        draw->AddText(targetFont, baseFS - 3.5f, ImVec2(pX + 15, pY + pH - 22.0f), dimBlueDevColor, "Powered By @CLOWNPh");
    }
}

struct TextureInfo { ImTextureID textureId; int x; int y; int w; int h; };

TextureInfo CreateTexture(const unsigned char* buf, int len) {
    TextureInfo image;
    int w, h;
    unsigned char* image_data = stbi_load_from_memory(buf, len, &w, &h, NULL, 4);
    if (image_data == NULL) { return {}; }

    GLuint image_texture;
    glGenTextures(1, &image_texture);
    glBindTexture(GL_TEXTURE_2D, image_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    stbi_image_free(image_data);

    image.textureId = (ImTextureID)(intptr_t)image_texture;
    image.w = w;
    image.h = h;
    return image;
}

TextureInfo LogoNew;;
TextureInfo LogoIcon;;
TextureInfo LogoGarena;;
void InitTexture() {
    LogoNew = CreateTexture(LogoNew_data, sizeof(LogoNew_data));
    LogoIcon = CreateTexture(LogoIcon_data, sizeof(LogoIcon_data));
    LogoGarena = CreateTexture(LogoGarena_data, sizeof(LogoGarena_data));
}

void saveKeyToFile(const std::string& key) {
    if (key.empty()) return;

    std::ofstream outFile("/storage/emulated/0/Download/lxt.dat", std::ios::out | std::ios::trunc);
    if (outFile.is_open()) {
        outFile << key;
        outFile.flush();
        outFile.close();
    } else {
        __android_log_print(ANDROID_LOG_ERROR, "NOTARIO_MOD", "Save Error");
    }
}

std::string loadKeyFromFile() {
    std::ifstream inFile("/storage/emulated/0/Download/lxt.dat");
    if (!inFile.is_open()) return "";

    std::string key;
    if (std::getline(inFile, key)) {
        inFile.close();
        key.erase(key.find_last_not_of(" \n\r\t") + 1);
        return key;
    }
    
    inFile.close();
    return "";
}

std::vector<sRegion> trapRegions;

uintptr_t address = 0;

JavaVM *VM;
std::string md5(std::string s);
using json = nlohmann::json;

uintptr_t g_il2cpp;
std::string g_Token, g_Auth;
bool bValid = false;

std::string getClipboard() {


    std::string result;
    JNIEnv *env;

    VM->AttachCurrentThread(&env, NULL);

    auto looperClass = env->FindClass(OBFUSCATE("android/os/Looper"));
    auto prepareMethod = env->GetStaticMethodID(looperClass, OBFUSCATE("prepare"),
                         OBFUSCATE("()V"));
    env->CallStaticVoidMethod(looperClass, prepareMethod);

    jclass activityThreadClass = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, OBFUSCATE(
            "sCurrentActivityThread"), OBFUSCATE("Landroid/app/ActivityThread;"));
    jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass,
                                     sCurrentActivityThreadField);

    jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass,
                                        OBFUSCATE("mInitialApplication"),
                                        OBFUSCATE("Landroid/app/Application;"));
    jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread,
                                  mInitialApplicationField);

    auto contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    auto getSystemServiceMethod = env->GetMethodID(contextClass, OBFUSCATE("getSystemService"),
                                  OBFUSCATE(
                                      "(Ljava/lang/String;)Ljava/lang/Object;"));

    auto str = env->NewStringUTF(OBFUSCATE("clipboard"));
    auto clipboardManager = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, str);
    env->DeleteLocalRef(str);

    jclass ClipboardManagerClass = env->FindClass(OBFUSCATE("android/content/ClipboardManager"));
    auto getText = env->GetMethodID(ClipboardManagerClass, OBFUSCATE("getText"),
                                    OBFUSCATE("()Ljava/lang/CharSequence;"));

    jclass CharSequenceClass = env->FindClass(OBFUSCATE("java/lang/CharSequence"));
    auto toStringMethod = env->GetMethodID(CharSequenceClass, OBFUSCATE("toString"),
                                           OBFUSCATE("()Ljava/lang/String;"));

    auto text = env->CallObjectMethod(clipboardManager, getText);
    if (text) {
        str = (jstring) env->CallObjectMethod(text, toStringMethod);
        result = env->GetStringUTFChars(str, 0);
        env->DeleteLocalRef(str);
        env->DeleteLocalRef(text);
    }

    env->DeleteLocalRef(CharSequenceClass);
    env->DeleteLocalRef(ClipboardManagerClass);
    env->DeleteLocalRef(clipboardManager);
    env->DeleteLocalRef(contextClass);
    env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass);
    VM->DetachCurrentThread();
    return result.c_str();
}

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    auto *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == nullptr) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,
                                         OBFUSCATE("getContentResolver"),
                                         OBFUSCATE(
                                                 "()Landroid/content/ContentResolver;"));
    jclass settingSecureClass = env->FindClass(OBFUSCATE("android/provider/Settings$Secure"));
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, OBFUSCATE("getString"),
                                OBFUSCATE(
                                    "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));
    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,
               env->NewStringUTF(OBFUSCATE("android_id")));
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, OBFUSCATE("MODEL"),
                       OBFUSCATE("Ljava/lang/String;"));
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, OBFUSCATE("BRAND"),
                       OBFUSCATE("Ljava/lang/String;"));
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getPackageNameId = env->GetMethodID(contextClass, OBFUSCATE("getPackageName"),
                                 OBFUSCATE("()Ljava/lang/String;"));
    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(OBFUSCATE("java/util/UUID"));
    auto len = strlen(uuid);
    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);
    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,
                                        OBFUSCATE("nameUUIDFromBytes"),
                                        OBFUSCATE("([B)Ljava/util/UUID;"));
    jmethodID toStringMethod = env->GetMethodID(uuidClass, OBFUSCATE("toString"),
                               OBFUSCATE("()Ljava/lang/String;"));
    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, nullptr);
}

std::string Login(const char *user_key) {
    JNIEnv *env;
    jvm->AttachCurrentThread(&env, 0);

    auto looperClass = env->FindClass("android/os/Looper");
    auto prepareMethod = env->GetStaticMethodID(looperClass, "prepare", "()V");
    env->CallStaticVoidMethod(looperClass, prepareMethod);

    jclass activityThreadClass = env->FindClass("android/app/ActivityThread");
    jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, "sCurrentActivityThread", "Landroid/app/ActivityThread;");
    jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass, sCurrentActivityThreadField);

    jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass, "mInitialApplication", "Landroid/app/Application;");
    jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread, mInitialApplicationField);

    std::string hwid = user_key;
    hwid += GetAndroidID(env, mInitialApplication);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
    jvm->DetachCurrentThread();

    usedKey = user_key;
    userType = "PREMIUM PAID";

    std::string errMsg;
    bValid = false;

    struct MemoryStruct chunk{};
    chunk.memory = (char *)malloc(1);
    chunk.size = 0;

    CURL *curl = curl_easy_init();
    if (curl) {
        char url[1024];
        snprintf(url, sizeof(url),
            "https://Clown.x10.mx/connect.php?game=CODMGR&user_key=%s&serial=%s",
            user_key, UUID.c_str());

        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Linux; Android 13)");

        CURLcode res = curl_easy_perform(curl);

        if (res == CURLE_OK && chunk.memory) {
            try {
                json result = json::parse(chunk.memory);

                // ayanokoji-style: status is boolean true
                if (result.contains("status") && result["status"] == true) {
                    std::string token = result["data"]["token"].get<std::string>();
                    time_t rng = result["data"]["rng"].get<time_t>();

                    EXP = result["data"]["EXP"].get<std::string>();
                    expiryTimestamp = parseExpiryDate(EXP);

                    // token check (same secret as server)
                    if (rng + 30 > time(0)) {
                        std::string auth = "CODMGR";
                        auth += "-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
                        auth += "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";

                        std::string outputAuth = md5(auth);
                        g_Token = token;
                        g_Auth  = outputAuth;
                        bValid  = (g_Token == g_Auth);
                    }
                } else {
                    if (result.contains("reason"))
                        errMsg = result["reason"].get<std::string>();
                    else
                        errMsg = "Key rejected";
                }
            } catch (json::exception &e) {
                errMsg = "JSON parse error: ";
                errMsg += e.what();
                errMsg += "\nRaw: ";
                errMsg += chunk.memory;
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }

        curl_easy_cleanup(curl);
    }

    if (chunk.memory) free(chunk.memory);

    return bValid ? "OK" : errMsg;
}


#define CREATE_COLOR(r, g, b, a) new float[4]{(float)r, (float)g, (float)b, (float)a};

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface)
{
    if (!Config.ImGuiMenu.g_Initialized)
    {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO &io = ImGui::GetIO();
        ImGuiStyle *style = &ImGui::GetStyle();
        style->WindowPadding = ImVec2(10, 10);
        style->FrameBorderSize = 1.0f;
        style->WindowBorderSize = 1.0f;

        style->FramePadding = ImVec2(2, 2);
        style->ItemSpacing = ImVec2(3, 2);
        style->IndentSpacing = 12;
        style->ScrollbarSize = 6.5;

        style->WindowRounding = 8.0f;
        style->FrameRounding = 5.0f;
        style->ScrollbarRounding = 2;
        style->WindowBorderSize = 1;
        style->FrameBorderSize = 1;

        style->WindowTitleAlign = ImVec2(0.5, 0.5);
        style->ButtonTextAlign = ImVec2(0.5, 0.5);
        style->WindowPadding = ImVec2(6, 8);
        style->FramePadding = ImVec2(2, 2);

        style->WindowPadding = ImVec2(14.0f, 12.0f);
        style->FramePadding = ImVec2(10.0f, 7.0f);
        style->ItemSpacing = ImVec2(9.0f, 8.0f);
        style->ItemInnerSpacing = ImVec2(7.0f, 6.0f);
        style->IndentSpacing = 18.0f;
        style->ScrollbarSize = 10.0f;
        style->WindowRounding = 12.0f;
        style->ChildRounding = 9.0f;
        style->FrameRounding = 7.0f;
        style->PopupRounding = 8.0f;
        style->ScrollbarRounding = 8.0f;
        style->GrabRounding = 7.0f;
        style->TabRounding = 7.0f;
        style->WindowBorderSize = 1.0f;
        style->ChildBorderSize = 1.0f;
        style->FrameBorderSize = 1.0f;
        style->PopupBorderSize = 1.0f;
        style->WindowTitleAlign = ImVec2(0.0f, 0.5f);
        style->ButtonTextAlign = ImVec2(0.5f, 0.5f);

        // BLACK / NEON GREEN / WHITE futuristic theme.
        const ImVec4 bg0       = ImVec4(0.012f, 0.018f, 0.016f, 0.98f);
        const ImVec4 bg1       = ImVec4(0.025f, 0.035f, 0.030f, 0.98f);
        const ImVec4 bg2       = ImVec4(0.045f, 0.060f, 0.050f, 0.98f);
        const ImVec4 green     = ImVec4(0.12f, 0.92f, 0.38f, 1.00f);
        const ImVec4 greenDim  = ImVec4(0.05f, 0.42f, 0.19f, 1.00f);
        const ImVec4 white     = ImVec4(0.94f, 0.98f, 0.95f, 1.00f);
        const ImVec4 muted     = ImVec4(0.52f, 0.62f, 0.56f, 1.00f);

        style->Colors[ImGuiCol_Text] = white;
        style->Colors[ImGuiCol_TextDisabled] = muted;
        style->Colors[ImGuiCol_WindowBg] = bg0;
        style->Colors[ImGuiCol_ChildBg] = bg1;
        style->Colors[ImGuiCol_PopupBg] = ImVec4(0.018f, 0.026f, 0.022f, 0.98f);
        style->Colors[ImGuiCol_Border] = ImVec4(0.12f, 0.55f, 0.27f, 0.72f);
        style->Colors[ImGuiCol_BorderShadow] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);

        style->Colors[ImGuiCol_FrameBg] = bg2;
        style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.06f, 0.22f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.07f, 0.32f, 0.16f, 1.00f);

        style->Colors[ImGuiCol_TitleBg] = ImVec4(0.015f, 0.025f, 0.020f, 1.00f);
        style->Colors[ImGuiCol_TitleBgActive] = ImVec4(0.025f, 0.075f, 0.040f, 1.00f);
        style->Colors[ImGuiCol_TitleBgCollapsed] = bg0;

        style->Colors[ImGuiCol_MenuBarBg] = bg1;
        style->Colors[ImGuiCol_ScrollbarBg] = bg0;
        style->Colors[ImGuiCol_ScrollbarGrab] = greenDim;
        style->Colors[ImGuiCol_ScrollbarGrabHovered] = green;
        style->Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.32f, 1.00f, 0.55f, 1.00f);

        style->Colors[ImGuiCol_CheckMark] = green;
        style->Colors[ImGuiCol_SliderGrab] = greenDim;
        style->Colors[ImGuiCol_SliderGrabActive] = green;
        style->Colors[ImGuiCol_Button] = ImVec4(0.035f, 0.12f, 0.065f, 1.00f);
        style->Colors[ImGuiCol_ButtonHovered] = ImVec4(0.06f, 0.30f, 0.14f, 1.00f);
        style->Colors[ImGuiCol_ButtonActive] = ImVec4(0.08f, 0.43f, 0.20f, 1.00f);

        style->Colors[ImGuiCol_Header] = ImVec4(0.035f, 0.13f, 0.065f, 1.00f);
        style->Colors[ImGuiCol_HeaderHovered] = ImVec4(0.06f, 0.27f, 0.12f, 1.00f);
        style->Colors[ImGuiCol_HeaderActive] = ImVec4(0.08f, 0.36f, 0.16f, 1.00f);
        style->Colors[ImGuiCol_Separator] = ImVec4(0.10f, 0.42f, 0.20f, 0.70f);
        style->Colors[ImGuiCol_SeparatorHovered] = green;
        style->Colors[ImGuiCol_SeparatorActive] = ImVec4(0.32f, 1.00f, 0.55f, 1.00f);

        style->Colors[ImGuiCol_Tab] = bg1;
        style->Colors[ImGuiCol_TabHovered] = ImVec4(0.06f, 0.28f, 0.13f, 1.00f);
        style->Colors[ImGuiCol_TabActive] = ImVec4(0.035f, 0.15f, 0.075f, 1.00f);
        style->Colors[ImGuiCol_TabUnfocused] = bg1;
        style->Colors[ImGuiCol_TabUnfocusedActive] = bg2;

        style->Colors[ImGuiCol_ResizeGrip] = greenDim;
        style->Colors[ImGuiCol_ResizeGripHovered] = green;
        style->Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.32f, 1.00f, 0.55f, 1.00f);


        ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init("#version 300 es");
        
        InitTexture();
        
        io.ConfigWindowsMoveFromTitleBarOnly = true;
        io.IniFilename = NULL;
        static const ImWchar icons_ranges[] = {
            0x0020,
            0x00FF,
            0x3000,
            0x30FF,
            0x31F0,
            0x31FF,
            0xFF00,
            0xFFEF,
            0x4e00,
            0x9FAF,
            0xf000,
            0xf3ff,
            0xe000,
            0xf8ff,
            0
        };

        ImFontConfig CustomFont;
        CustomFont.FontDataOwnedByAtlas = true;
        ImFontConfig icons_config;
        CustomFont.FontDataOwnedByAtlas = false;

        icons_config.MergeMode = true;
        icons_config.PixelSnapH = true;
        icons_config.OversampleH = 2.5;
        icons_config.OversampleV = 2.5;

        io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 22.f, &CustomFont);
        io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data1, font_awesome_size1, 28.0f, &icons_config, icons_ranges);
        F50 = io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t *>(Custom), sizeof(Custom), 30.0f, &CustomFont);

        io.Fonts->AddFontFromMemoryCompressedTTF(Custom_data, Custom_size, 26.0f, &CustomFont,
                io.Fonts->GetGlyphRangesJapanese());

        ImGui::GetStyle().ScaleAllSizes(2.0f);
        memset(&Config, 0, sizeof(sConfig));

        Config.sColorsESPPLAYER.LinePLAYER = CREATE_COLOR(255, 0, 0, 255);
        Config.sColorsESPPLAYER.BoxPLAYER = CREATE_COLOR(255, 0, 0, 255);
        Config.sColorsESPPLAYER.NamePLAYER = CREATE_COLOR(255, 0, 0, 255);
        Config.sColorsESPPLAYER.DistancePLAYER = CREATE_COLOR(255, 0, 0, 255);
        Config.sColorsESPPLAYER.HealthPLAYER = CREATE_COLOR(255, 0, 0, 255);
        Config.sColorsESPBOT.LineBOT = CREATE_COLOR(0, 255, 0, 180);
        Config.sColorsESPBOT.BoxBOT = CREATE_COLOR(0, 255, 0, 180);
        Config.sColorsESPBOT.NameBOT = CREATE_COLOR(0, 255, 0, 180);
        Config.sColorsESPBOT.HealthBOT = CREATE_COLOR(0, 255, 0, 180);
        Config.sColorsESPBOT.DistanceBOT = CREATE_COLOR(0, 255, 0, 180);
        Config.sColorsESPOTHERS.PovOTHERS = CREATE_COLOR(225, 0, 0, 180);
		Config.sColorsESPPLAYER.SkeletonPLAYER = CREATE_COLOR(255, 0, 0, 255);
		Config.sColorsESPBOT.SkeletonBOT = CREATE_COLOR(0, 255, 0, 180);

		Config.PskelLine = 2.0f;
		Config.BskelLine = 2.0f;
		Config.ESPMenu.Skeleton = false;
			
        Config.Bline = 2.0f;
        Config.Bbox = 2.0f;
        Config.Pline = 2.0f;
        Config.Pbox = 2.0f;

        Config.ImGuiMenu.g_Initialized = true;
    }

    ImGuiIO *io = &ImGui::GetIO();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(get_width(), get_height());
    ImGui::NewFrame();

static ImVec2 logoPos = ImVec2(500, 20);
static float logoSize = 60.0f;
static float logoOpacitySlider = 0.0f;
static bool isDraggingLogo = false;
static bool isMenuVisible = true;
static bool forceHideLogo = false;

DrawESP(ImGui::GetBackgroundDrawList(), get_width(), get_height(), get_dpi());
RenderFloatingInfo(ImGui::GetBackgroundDrawList(), (float)get_width(), (float)get_height());

// ============================================================
// BOTTOM-CENTER NEON MENU HANDLE
// Tap the slim glowing line to show/hide the main interface.
// Kept on-screen in both states so the menu is always reachable.
// ============================================================
{
    ImGuiIO& toggleIO = ImGui::GetIO();
    const float handleW = 132.0f;
    const float handleH = 28.0f;
    const float handleX = (toggleIO.DisplaySize.x - handleW) * 0.5f;
    const float handleY = toggleIO.DisplaySize.y - handleH - 10.0f;
    ImGui::SetNextWindowPos(ImVec2(handleX, handleY), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(handleW, handleH), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    if (ImGui::Begin("##NeonBottomMenuHandle", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoFocusOnAppearing)) {
        ImDrawList* handleDraw = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetWindowPos();
        const float pulse = 0.68f + 0.32f * (0.5f + 0.5f * sinf((float)ImGui::GetTime() * 2.8f));
        const float lineY = p.y + 13.0f;
        const float lineL = p.x + 18.0f;
        const float lineR = p.x + handleW - 18.0f;
        // Layered strokes create a soft neon bloom around a thin green line.
        handleDraw->AddLine(ImVec2(lineL, lineY), ImVec2(lineR, lineY), ImColor(0.10f, 1.0f, 0.36f, 0.12f * pulse), 9.0f);
        handleDraw->AddLine(ImVec2(lineL, lineY), ImVec2(lineR, lineY), ImColor(0.10f, 1.0f, 0.36f, 0.30f * pulse), 5.0f);
        handleDraw->AddLine(ImVec2(lineL, lineY), ImVec2(lineR, lineY), ImColor(0.48f, 1.0f, 0.65f, 0.95f * pulse), 1.8f);
        handleDraw->AddCircleFilled(ImVec2(lineL, lineY), 2.0f, ImColor(0.70f, 1.0f, 0.78f, pulse));
        handleDraw->AddCircleFilled(ImVec2(lineR, lineY), 2.0f, ImColor(0.70f, 1.0f, 0.78f, pulse));
        ImGui::SetCursorScreenPos(p);
        ImGui::InvisibleButton("##TapNeonBottomMenuHandle", ImVec2(handleW, handleH));
        if (ImGui::IsItemClicked(0)) {
            isMenuVisible = !isMenuVisible;
            forceHideLogo = true;
        }
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);
}

static float t = 0.0f;
t += ImGui::GetIO().DeltaTime;

if (isMenuVisible) {
    ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
    ImGui::SetNextWindowPos(center, ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(880, 510), ImGuiCond_Once);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 15.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (ImGui::Begin("CLOWN ECLIPSE##MainMenu", &isMenuVisible, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize)) {
        ImDrawList* drawList = ImGui::GetWindowDrawList();
        ImVec2 winPos = ImGui::GetWindowPos();
        ImVec2 winSize = ImGui::GetWindowSize();
        

        // ============================================================
        // NEBULA FLUX BACKGROUND MOTION
        // Moving particles, connecting trails and a slow light sweep.
        // ============================================================
        {
            const float bt = (float)ImGui::GetTime();
            const ImVec2 bgCenter(
                winPos.x + winSize.x * 0.5f,
                winPos.y + winSize.y * 0.5f
            );

            for (int i = 0; i < 7; ++i) {
                float a = bt * (0.10f + i * 0.012f) + i * 0.91f;
                float rx = winSize.x * (0.18f + i * 0.035f);
                float ry = winSize.y * (0.20f + i * 0.025f);
                ImVec2 haze(
                    bgCenter.x + cosf(a) * rx,
                    bgCenter.y + sinf(a * 1.17f) * ry
                );
                float r = 22.0f + 8.0f * sinf(bt * 0.8f + i);
                drawList->AddCircleFilled(
                    haze, r, IM_COL32(10, 80, 28, 8), 32
                );
            }

            const int particleCount = 34;
            ImVec2 pts[particleCount];

            for (int i = 0; i < particleCount; ++i) {
                float fi = (float)i;
                float xBase = fmodf(fi * 83.0f, winSize.x - 30.0f) + 15.0f;
                float yBase = fmodf(fi * 47.0f, winSize.y - 30.0f) + 15.0f;

                float x = xBase
                    + sinf(bt * (0.22f + (i % 5) * 0.025f) + fi) * 28.0f
                    + cosf(bt * 0.11f + fi * 0.7f) * 12.0f;
                float y = yBase
                    + cosf(bt * (0.19f + (i % 4) * 0.022f) + fi * 0.8f) * 22.0f
                    + sinf(bt * 0.13f + fi) * 10.0f;

                x = winPos.x + fmodf(x - winPos.x + winSize.x * 4.0f, winSize.x);
                y = winPos.y + fmodf(y - winPos.y + winSize.y * 4.0f, winSize.y);
                pts[i] = ImVec2(x, y);

                int alpha = 35 + (int)(25.0f * (0.5f + 0.5f * sinf(bt * 1.4f + fi)));
                drawList->AddCircleFilled(
                    pts[i], 1.4f + (i % 3) * 0.45f,
                    IM_COL32(45, 255, 105, alpha), 12
                );
            }

            for (int i = 0; i < particleCount; ++i) {
                for (int j = i + 1; j < particleCount; ++j) {
                    float dx = pts[i].x - pts[j].x;
                    float dy = pts[i].y - pts[j].y;
                    float dist2 = dx * dx + dy * dy;
                    if (dist2 < 78.0f * 78.0f) {
                        float dist = sqrtf(dist2);
                        int alpha = (int)(34.0f * (1.0f - dist / 78.0f));
                        drawList->AddLine(
                            pts[i], pts[j],
                            IM_COL32(20, 190, 65, alpha), 0.75f
                        );
                    }
                }
            }

            float sweep = fmodf(bt * 70.0f, winSize.x + 260.0f) - 130.0f;
            drawList->AddLine(
                ImVec2(winPos.x + sweep, winPos.y + 45.0f),
                ImVec2(winPos.x + sweep + 210.0f, winPos.y + winSize.y - 25.0f),
                IM_COL32(45, 255, 105, 22), 2.0f
            );
        }

        float t_val = (float)ImGui::GetTime();
        float pulse = (sinf(t_val * 3.0f) * 0.5f) + 0.5f;
        ImVec4 glowColor = ImVec4(0.08f, 0.85f + (pulse * 0.15f), 0.28f, 1.0f);
        ImU32 activeColorU32 = ImGui::GetColorU32(glowColor);

        static bool isLogin = false;
        static std::string err;
        static char s[64] = "";
        static bool isProcessing = false;
        static bool keyInitialized = false;
        static bool isAutoLoggingIn = false;
        static int loginFrameDelay = 0;

        if (!keyInitialized) {
            std::string storedKey = loadKeyFromFile();
            if (!storedKey.empty()) {
                strncpy(s, storedKey.c_str(), sizeof(s) - 1);
                isAutoLoggingIn = true;
            }
            keyInitialized = true;
        }

        if (isAutoLoggingIn) {
            static float progress = 0.0f;
            progress += ImGui::GetIO().DeltaTime * 0.40f;
            if (progress > 1.0f) progress = 1.0f;

            const char* logs[] = { "Checking server connection", "Hardware ID validated", "Bypassing system integrity", "Loading CLOWN modules", "Injection successful", "System is ready" };
            
            int logIdx = (int)(progress * 5.9f);
            float autoW = 480.0f;
            ImGui::SetCursorPos(ImVec2((winSize.x - autoW) * 0.5f, winSize.y * 0.30f));
            
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.05f, 0.05f, 0.07f, 0.8f));
            ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 12.0f);
            ImGui::BeginChild("AutoLoginVessel", ImVec2(autoW, 220), true);
            {
                ImGui::SetCursorPos(ImVec2(20, 20));
                ImGui::TextColored(glowColor, "System Logs");
                
                ImGui::SetCursorPosX(20);
                ImGui::BeginChild("InnerLogs", ImVec2(autoW - 40, 100), false, ImGuiWindowFlags_NoScrollbar);
                {
                    int dotsCount = ((int)(t_val * 3.0f)) % 4;
                    const char* dotsStr = (dotsCount == 1) ? "." : (dotsCount == 2) ? ".." : (dotsCount == 3) ? "..." : "";

                    for (int i = 0; i <= logIdx && i < 6; i++) {
                        ImGui::TextColored(glowColor, "» ");
                        ImGui::SameLine(0, 0);
                        
                        if (i == logIdx && progress < 1.0f) {
                            ImGui::TextColored(ImVec4(0.9f, 0.9f, 0.9f, 1.0f), "%s", logs[i]);
                            ImGui::SameLine(0, 0);
                            ImGui::TextColored(glowColor, "%s", dotsStr);
                        } 
                        else if (i < logIdx || progress >= 1.0f) {
                            ImGui::TextColored(ImVec4(0.18f, 1.0f, 0.38f, 1.0f), "%s [Success]", logs[i]);
                        }
                    }
                    ImGui::SetScrollHereY(1.0f);
                }
                ImGui::EndChild();

                ImGui::SetCursorPos(ImVec2(20, 160));
                ImGui::PushStyleColor(ImGuiCol_PlotHistogram, activeColorU32);
                ImGui::ProgressBar(progress, ImVec2(autoW - 40, 10), "");
                ImGui::PopStyleColor();
                
                char pText[32]; sprintf(pText, "Secure Injecton: %d%%", (int)(progress * 100));
                ImGui::SetCursorPosX((autoW - ImGui::CalcTextSize(pText).x) * 0.5f);
                ImGui::TextColored(ImVec4(glowColor.x, glowColor.y, glowColor.z, 0.7f), "%s", pText);
            }
            ImGui::EndChild();
            ImGui::PopStyleVar();
            ImGui::PopStyleColor();

            if (progress >= 1.0f) {
                loginFrameDelay++;
                if (loginFrameDelay > 10) {
                    std::string result = Login(s);
                    if (result == "OK") {
                        saveKeyToFile(s); 
                        isLogin = true;
                        isAutoLoggingIn = false;                        
                    } else {
                        err = result;
                        isAutoLoggingIn = false;
                    }
                    loginFrameDelay = 0;
                    progress = 0.0f;
                }
            }
        } 
        else if (!isLogin) {
            ImVec4 rgbColor = ImVec4((sin(t_val) * 0.5f + 0.5f), (sin(t_val + 2.094f) * 0.5f + 0.5f), (sin(t_val + 4.188f) * 0.5f + 0.5f), 1.0f);
            float loginW = 420.0f;
            float loginH = 300.0f;
            ImGui::SetCursorPos(ImVec2((winSize.x - loginW) * 0.5f, (winSize.y - loginH) * 0.5f));
            
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.07f, 0.07f, 0.10f, 0.9f));
            ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 15.0f);
            
            if (ImGui::BeginChild("LoginVessel", ImVec2(loginW, loginH), true, ImGuiWindowFlags_NoScrollbar)) {
                ImGui::SetCursorPosY(35.0f);
                ImGui::SetCursorPosX((loginW - ImGui::CalcTextSize("CLOWN AUTHENTICATION").x) * 0.5f);
                ImGui::TextColored(rgbColor, "CLOWN AUTHENTICATION");
                
                ImGui::SetCursorPos(ImVec2(30.0f, 90.0f));
                ImGui::TextDisabled("License Management");
                
                ImGui::SetCursorPosX(30.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 5.0f);
                ImGui::PushItemWidth(loginW - 60.0f);
                ImGui::InputTextWithHint("##key", "Insert your access key here...", s, sizeof(s));
                ImGui::PopItemWidth();
                
                ImGui::SetCursorPos(ImVec2(30.0f, 160.0f));
                float btnWidth = (loginW - 70.0f) * 0.5f;
                
                if (isProcessing) {
                    ImGui::Button("Authenticating...", ImVec2(loginW - 60.0f, 45.0f));
                    loginFrameDelay++;
                    if (loginFrameDelay > 5) {
                        std::string result = Login(s);
                        if (result == "OK") { 
                            saveKeyToFile(s); 
                            isLogin = true; 
                        } else {
                            err = result;
                        }
                        isProcessing = false;
                        loginFrameDelay = 0;
                    }
                } else {
                    if (ImGui::Button("Paste", ImVec2(btnWidth, 45.0f))) {
                        auto key = getClipboard(); 
                        strncpy(s, key.c_str(), sizeof(s));
                        s[sizeof(s) - 1] = '\0';
                    }
                    ImGui::SameLine(0, 10.0f);
                    if (ImGui::Button("Login", ImVec2(btnWidth, 45.0f))) {
                        if (strlen(s) == 0) {
                            err = "Please enter a valid license.";
                        } else {
                            isProcessing = true;
                            loginFrameDelay = 0;
                        }
                    }
                }
                ImGui::PopStyleVar();

                if (!err.empty() && err != "OK") {
                    ImGui::SetCursorPosY(220.0f);
                    ImGui::SetCursorPosX((loginW - ImGui::CalcTextSize(err.c_str()).x) * 0.5f);
                    ImGui::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "%s", err.c_str());
                }

                ImGui::SetCursorPosY(265.0f);
                ImGui::SetCursorPosX((loginW - ImGui::CalcTextSize(ICON_FA_TELEGRAM " @CLOWNPh").x) * 0.5f);
                ImGui::TextDisabled(ICON_FA_TELEGRAM " @CLOWNPh");
            }
            ImGui::EndChild();
            ImGui::PopStyleVar();
            ImGui::PopStyleColor();
        }
        else {
            // ============================================================
            // SEPARATE UI LAYERS
            //   1) Floating radial TAB
            //   2) Main feature window
            //
            // They have independent positions and never share a parent
            // ImGui window/container.
            // ============================================================
            static int tab = 1;
            static ImVec2 tabPos(110.0f, 150.0f);
            static ImVec2 mainPos(520.0f, 135.0f);
            static bool tabPosInitialized = false;
            static bool mainPosInitialized = false;
            static bool tabDragging = false;
            static ImVec2 tabDragOffset(0.0f, 0.0f);
            static bool mainDragging = false;
            static ImVec2 mainDragOffset(0.0f, 0.0f);

            ImGuiIO& uiIO = ImGui::GetIO();
            const ImVec2 display = uiIO.DisplaySize;

            if (!tabPosInitialized) {
                tabPos = ImVec2(
                    std::max(20.0f, display.x * 0.5f - 400.0f),
                    std::max(20.0f, display.y * 0.5f - 150.0f)
                );
                tabPosInitialized = true;
            }

            if (!mainPosInitialized) {
                mainPos = ImVec2(
                    std::max(20.0f, display.x * 0.5f + 20.0f),
                    std::max(20.0f, display.y * 0.5f - 205.0f)
                );
                mainPosInitialized = true;
            }

            // ------------------------------------------------------------
            // FUTURISTIC VERTICAL SIDEBAR
            // Preserves the original tab IDs and feature callbacks while
            // replacing the radial selector with a fixed, readable sidebar.
            // ------------------------------------------------------------
            {
                const float sideW = 158.0f;
                const float sideH = 480.0f;
                const float gap = 12.0f;
                const float mainW = 780.0f;
                const float totalW = sideW + gap + mainW;
                const float baseX = std::max(8.0f, (display.x - totalW) * 0.5f);
                const float baseY = std::max(8.0f, (display.y - sideH) * 0.5f);
                tabPos = ImVec2(baseX, baseY);
                mainPos = ImVec2(baseX + sideW + gap, baseY);

                ImGui::SetNextWindowPos(tabPos, ImGuiCond_Always);
                ImGui::SetNextWindowSize(ImVec2(sideW, sideH), ImGuiCond_Always);
                ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.018f, 0.025f, 0.022f, 0.98f));
                ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.10f, 0.95f, 0.38f, 0.78f));
                ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.025f, 0.04f, 0.03f, 0.95f));
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.035f, 0.075f, 0.05f, 0.96f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.06f, 0.28f, 0.13f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.08f, 0.62f, 0.22f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 1.0f, 0.94f, 1.0f));
                ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 12.0f));
                ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 7.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
                ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(4.0f, 8.0f));

                if (ImGui::Begin("##CLOWN_NeonSidebar", nullptr,
                    ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                    ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                    ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings)) {
                    ImDrawList* sideDL = ImGui::GetWindowDrawList();
                    const ImVec2 sideWP = ImGui::GetWindowPos();
                    const float pulse = 0.5f + 0.5f * sinf((float)ImGui::GetTime() * 3.0f);
                    sideDL->AddRect(ImVec2(sideWP.x + 1, sideWP.y + 1),
                        ImVec2(sideWP.x + sideW - 1, sideWP.y + sideH - 1),
                        IM_COL32(35, 255, 105, (int)(145 + pulse * 70)), 12.0f, 0, 1.5f);
                    ImGui::TextColored(ImVec4(0.20f, 1.0f, 0.43f, 1.0f), "CLOWN");
                    ImGui::SameLine();
                    ImGui::TextColored(ImVec4(0.92f, 1.0f, 0.94f, 1.0f), "// OS");
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    ImGui::TextDisabled("NAVIGATION");
                    ImGui::Spacing();

                    const char* navLabels[] = {
                        "[01]  OVERVIEW", "[02]  VISUALS", "[03]  MEMORY",
                        "[04]  EXTRAS", "[05]  SKINS", "[06]  SETTINGS"
                    };
                    const int navIds[] = { 1, 2, 3, 4, 5, 6 };
                    for (int i = 0; i < 6; ++i) {
                        const bool active = (tab == navIds[i]);
                        if (active) {
                            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.07f, 0.42f, 0.16f, 1.0f));
                            ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.22f, 1.0f, 0.40f, 1.0f));
                        } else {
                            ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.10f, 0.28f, 0.16f, 0.9f));
                        }
                        if (ImGui::Button(navLabels[i], ImVec2(-1.0f, 43.0f))) tab = navIds[i];
                        if (active) ImGui::PopStyleColor(2); else ImGui::PopStyleColor(1);
                    }

                    ImGui::SetCursorPosY(sideH - 68.0f);
                    ImGui::Separator();
                    ImGui::TextColored(ImVec4(0.20f, 1.0f, 0.43f, 1.0f), "● SYSTEM ONLINE");
                    ImGui::TextDisabled("NEON INTERFACE / V2");
                }
                ImGui::End();
                ImGui::PopStyleVar(5);
                ImGui::PopStyleColor(7);
            }

            // ------------------------------------------------------------
            // MAIN FEATURE UI
            // ------------------------------------------------------------
            {
                const float mainW = 780.0f;
                const float mainH = 480.0f;
                const float headerHeight = 48.0f;

                ImGui::SetNextWindowPos(mainPos, ImGuiCond_Always);
                ImGui::SetNextWindowSize(ImVec2(mainW, mainH), ImGuiCond_Always);

                ImGui::PushStyleColor(
                    ImGuiCol_WindowBg,
                    ImVec4(0, 0, 0, 0)
                );
                ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
                ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

                if (ImGui::Begin(
                    "CLOWN ECLIPSE##MainMenu",
                    nullptr,
                    ImGuiWindowFlags_NoTitleBar |
                    ImGuiWindowFlags_NoResize |
                    ImGuiWindowFlags_NoMove |
                    ImGuiWindowFlags_NoCollapse |
                    ImGuiWindowFlags_NoScrollbar |
                    ImGuiWindowFlags_NoSavedSettings |
                    ImGuiWindowFlags_NoBackground
                )) {
                    ImDrawList* mainDL = ImGui::GetWindowDrawList();
                    const ImVec2 mainWP = ImGui::GetWindowPos();
                    const ImVec2 mainWS = ImGui::GetWindowSize();

                    const float now = (float)ImGui::GetTime();
                    const float pulse =
                        0.5f + 0.5f * sinf(now * 3.0f);
                    const float sweep =
                        fmodf(now * 110.0f, mainWS.x + 80.0f);

                    // No solid black card: the animated backdrop remains visible
                    // across the whole menu. Only the outline/glass accents remain.
                    mainDL->AddRectFilled(
                        mainWP,
                        ImVec2(
                            mainWP.x + mainWS.x,
                            mainWP.y + mainWS.y
                        ),
                        IM_COL32(5, 10, 7, 245),
                        12.0f
                    );

                    // Full-menu animated background. It sits behind the
                    // header and feature cards and stays lightweight.
                    DrawAnimatedMenuBackdrop(
                        mainDL,
                        ImVec2(mainWP.x + 7.0f, mainWP.y + 7.0f),
                        ImVec2(
                            mainWP.x + mainWS.x - 7.0f,
                            mainWP.y + mainWS.y - 7.0f
                        ),
                        now
                    );

                    mainDL->AddRect(
                        ImVec2(mainWP.x + 2.0f, mainWP.y + 2.0f),
                        ImVec2(
                            mainWP.x + mainWS.x - 2.0f,
                            mainWP.y + mainWS.y - 2.0f
                        ),
                        IM_COL32(35, 210, 90, 180),
                        10.0f, 0, 3.0f
                    );

                    mainDL->AddRect(
                        ImVec2(mainWP.x + 5.0f, mainWP.y + 5.0f),
                        ImVec2(
                            mainWP.x + mainWS.x - 5.0f,
                            mainWP.y + mainWS.y - 5.0f
                        ),
                        IM_COL32(
                            65, 225, 255,
                            (int)(165 + pulse * 70)
                        ),
                        8.0f, 0, 1.6f
                    );

                    const float sx = mainWP.x + sweep - 40.0f;
                    mainDL->AddLine(
                        ImVec2(sx, mainWP.y + 7.0f),
                        ImVec2(sx + 70.0f, mainWP.y + 7.0f),
                        IM_COL32(70, 255, 125, 235),
                        2.0f
                    );

                    // Header.
                    const ImVec2 hMin(
                        mainWP.x + 14.0f,
                        mainWP.y + 10.0f
                    );
                    const ImVec2 hMax(
                        mainWP.x + mainWS.x - 12.0f,
                        mainWP.y + 11.0f + headerHeight
                    );

                    mainDL->AddRectFilled(
                        hMin, hMax,
                        IM_COL32(12, 24, 16, 248),
                        5.0f
                    );

                    mainDL->AddRect(
                        hMin, hMax,
                        IM_COL32(38, 210, 92, 220),
                        5.0f, 0, 1.0f
                    );

                    const char* brand = "CLOWN ECLIPSE | GARENA | 1.6.57";
                    const ImVec2 brandSize = ImGui::CalcTextSize(brand);
                    const float titleX =
                        mainWP.x + (mainWS.x - brandSize.x) * 0.5f;
                    const float titleY =
                        hMin.y + (headerHeight - brandSize.y) * 0.5f;

                    mainDL->AddText(
                        ImVec2(titleX + 1.5f, titleY + 1.5f),
                        IM_COL32(0, 0, 0, 240), brand);
                    mainDL->AddText(
                        ImVec2(titleX, titleY),
                        IM_COL32(235, 230, 250, 255), brand);

                    // Animated cyan "snake" traveling through the header.
                    // The old /// \\ decorative marks are intentionally removed.
                    {
                        const float snakeLeft  = hMin.x + 18.0f;
                        const float snakeRight = hMax.x - 18.0f;
                        const float snakeY     = hMin.y + headerHeight * 0.50f;
                        const float snakeW     = 92.0f;
                        const float travelW    = (hMax.x - hMin.x) + snakeW;
                        const float headX      = hMin.x - snakeW + fmodf(now * 135.0f, travelW);

                        ImVec2 pts[9];
                        for (int j = 0; j < 9; ++j) {
                            const float px = headX - j * (snakeW / 8.0f);
                            const float wave = sinf(now * 7.0f - j * 0.72f) * 4.2f;
                            pts[j] = ImVec2(px, snakeY + wave);
                        }

                        for (int j = 0; j < 8; ++j) {
                            const int alpha = 35 + (8 - j) * 22;
                            mainDL->AddLine(
                                pts[j], pts[j + 1],
                                IM_COL32(55, 255, 115, alpha),
                                1.8f + (8 - j) * 0.12f
                            );
                        }

                        const ImVec2 head = pts[0];
                        mainDL->AddCircleFilled(
                            head, 3.2f,
                            IM_COL32(225, 255, 232, 245), 20
                        );
                        mainDL->AddCircle(
                            head, 6.5f + pulse * 2.0f,
                            IM_COL32(40, 255, 105, 95), 24, 1.2f
                        );

                        // Keep the snake inside the long header box.
                        mainDL->AddRectFilled(
                            ImVec2(hMin.x + 1.0f, hMin.y + 1.0f),
                            ImVec2(hMax.x - 1.0f, hMax.y - 1.0f),
                            IM_COL32(0, 0, 0, 0),
                            5.0f
                        );
                    }

                    // Independent Main UI drag handle.
                    ImGui::SetCursorScreenPos(
                        ImVec2(
                            hMin.x + 70.0f,
                            hMin.y + 3.0f
                        )
                    );

                    ImGui::InvisibleButton(
                        "##F4D3C_MainDrag",
                        ImVec2(
                            (hMax.x - hMin.x) - 140.0f,
                            headerHeight - 6.0f
                        )
                    );

                    if (ImGui::IsItemActive() &&
                        ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
                        if (!mainDragging) {
                            const ImVec2 mp = ImGui::GetMousePos();
                            mainDragging = true;
                            mainDragOffset = ImVec2(
                                mp.x - mainPos.x,
                                mp.y - mainPos.y
                            );
                        }

                        const ImVec2 mp = ImGui::GetMousePos();
                        mainPos = ImVec2(
                            mp.x - mainDragOffset.x,
                            mp.y - mainDragOffset.y
                        );
                    }

                    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
                        mainDragging = false;

                    ImGui::SetCursorPos(ImVec2(17.0f, 70.0f));

                    // New animated workspace divider: gives the redesigned
                    // layout a distinct visual hierarchy without changing features.
                    {
                        const float lineY = hMax.y + 8.0f;
                        const float travel = fmodf(now * 95.0f, mainWS.x + 180.0f) - 90.0f;
                        mainDL->AddLine(
                            ImVec2(mainWP.x + 18.0f, lineY),
                            ImVec2(mainWP.x + mainWS.x - 18.0f, lineY),
                            IM_COL32(25, 100, 45, 110),
                            1.0f
                        );
                        mainDL->AddLine(
                            ImVec2(mainWP.x + travel, lineY),
                            ImVec2(mainWP.x + travel + 90.0f, lineY),
                            IM_COL32(50, 255, 105, 190),
                            2.0f
                        );
                    }

                    // Feature container only. The radial TAB is NOT a
                    // child of this window anymore.
                    ImGui::PushStyleColor(
                        ImGuiCol_ChildBg,
                        ImVec4(0.01f, 0.025f, 0.015f, 0.08f)
                    );
                    ImGui::PushStyleColor(
                        ImGuiCol_Border,
                        ImVec4(0.10f, 0.75f, 0.28f, 0.55f)
                    );
                    ImGui::PushStyleVar(
                        ImGuiStyleVar_ChildRounding,
                        15.0f
                    );
                    ImGui::PushStyleVar(
                        ImGuiStyleVar_WindowPadding,
                        ImVec2(12.0f, 12.0f)
                    );
                    ImGui::PushStyleVar(
                        ImGuiStyleVar_ItemSpacing,
                        ImVec2(11.0f, 9.0f)
                    );

                    ImGui::BeginChild(
                        "MainContent",
                        ImVec2(
                            mainWS.x - 24.0f,
                            mainWS.y - 78.0f
                        ),
                        true,
                        ImGuiWindowFlags_AlwaysVerticalScrollbar
                    );

                    // Subtle animated accent inside the workspace.
                    {
                        ImDrawList* contentDL = ImGui::GetWindowDrawList();
                        const ImVec2 cMin = ImGui::GetWindowPos();
                        const float cW = ImGui::GetWindowWidth();
                        const float accentX =
                            cMin.x + fmodf(now * 55.0f, cW + 70.0f) - 35.0f;

                        contentDL->AddLine(
                            ImVec2(cMin.x + 10.0f, cMin.y + 3.0f),
                            ImVec2(cMin.x + cW - 10.0f, cMin.y + 3.0f),
                            IM_COL32(35, 180, 75, 45),
                            1.0f
                        );
                        contentDL->AddLine(
                            ImVec2(accentX, cMin.y + 3.0f),
                            ImVec2(accentX + 55.0f, cMin.y + 3.0f),
                            IM_COL32(50, 255, 105, 150),
                            2.0f
                        );
                    }

                    if (tab == 1) {
    const float totalWidth = ImGui::GetContentRegionAvail().x;
    const float totalHeight = ImGui::GetContentRegionAvail().y;
    const float spacing = 10.0f;
    const float panelWidth = (totalWidth - spacing) * 0.5f;
    const float panelHeight = (totalHeight - spacing) * 0.5f;

    const float rightColumnHeight = (totalHeight - spacing);
    const float changelogHeight = rightColumnHeight * 0.80f;
    const float creditsHeight = rightColumnHeight * 0.20f;

    static float infoTimer = 0.0f;
    infoTimer += ImGui::GetIO().DeltaTime;
    ImVec4 rgbColor = ImVec4((sin(infoTimer) * 0.5f + 0.5f), (sin(infoTimer + 2.0f) * 0.5f + 0.5f), (sin(infoTimer + 4.0f) * 0.5f + 0.5f), 1.0f);

    static char model[64] = "Unknown";
    static char osVer[16] = "Unknown";
    static char ramStr[32] = "0.0GB / 0.0GB";
    static float batteryTemp = 0.0f;
    GetDeviceData(model, osVer, ramStr, &batteryTemp);

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("InfoPanel", ImVec2(panelWidth, panelHeight), true, ImGuiWindowFlags_NoScrollbar);
        {
            ImGui::TextColored(rgbColor, "Information");
            ImGui::Separator();
            ImGui::Spacing();
            ImGui::TextDisabled("Mod Type :"); ImGui::SameLine(); 
            ImGui::TextColored(ImVec4(0.88f, 0.08f, 1.0f, 1.0f), "CLOWN Container");
            ImGui::TextDisabled("Key Type :"); ImGui::SameLine(); 
            ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.4f, 1.0f), "Paid");
            ImGui::TextDisabled("Game Count :"); ImGui::SameLine();
            ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "%d", g_TotalMatches);
            if (isLogin) {
                static std::string displayKey = loadKeyFromFile();
                ImGui::TextDisabled("Key :"); ImGui::SameLine(); 
                ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "%s", displayKey.empty() ? "N/A" : displayKey.c_str());
                static std::string formattedDate = "Loading...";
                static bool dateFormatted = false;
                if (!dateFormatted) {
                    struct tm tm = {};
                    if (strptime(EXP.c_str(), "%Y-%m-%d", &tm)) {
                        char buffer[64];
                        strftime(buffer, sizeof(buffer), "%b %d, %Y", &tm);
                        formattedDate = buffer;
                    }
                    dateFormatted = true;
                }
                ImGui::TextDisabled("Expiry :"); ImGui::SameLine(); 
                ImGui::TextColored(ImVec4(1.0f, 0.8f, 0.0f, 1.0f), "%s", formattedDate.c_str());
            }
        }
        ImGui::EndChild();

        ImGui::BeginChild("DevicePanel", ImVec2(panelWidth, panelHeight), true, ImGuiWindowFlags_NoScrollbar);
        {
            ImGui::TextColored(rgbColor, "Device Information");
            ImGui::Separator();
            ImGui::Spacing();

            char osDisplay[32];
            snprintf(osDisplay, sizeof(osDisplay), "Android %s", osVer);

            float currentRamVal = 0.0f;
            float totalRamVal = 0.0f;
            sscanf(ramStr, "%fGB / %fGB", &currentRamVal, &totalRamVal);

            float ramUsagePercent = (totalRamVal > 0) ? (currentRamVal / totalRamVal) * 100.0f : 0.0f;
            ImVec4 ramColor = (ramUsagePercent > 90.0f) ? ImVec4(1.0f, 0.4f, 0.4f, 1.0f) : (ramUsagePercent > 70.0f ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(0.4f, 1.0f, 0.4f, 1.0f));
            ImVec4 tempColor = (batteryTemp > 45.0f) ? ImVec4(1.0f, 0.4f, 0.4f, 1.0f) : (batteryTemp > 40.0f ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(0.4f, 1.0f, 0.4f, 1.0f));

            auto DrawRow = [&](const char* label, const char* value) {
                ImGui::TextDisabled("%s", label); 
                ImGui::SameLine(); 
                ImGui::Text("%s", value);
            };

            DrawRow("Model :", model);
            DrawRow("OS Version :", osDisplay);
            
            ImGui::TextDisabled("Memory Usage :"); ImGui::SameLine();
            ImGui::TextColored(ramColor, "%s", ramStr);

            ImGui::TextDisabled("Temperature :"); ImGui::SameLine();
            ImGui::TextColored(tempColor, "%.1f °C", batteryTemp);

            DrawRow("Platform :", "arm64-v8a");
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();

    ImGui::SameLine();

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("ChangelogPanel", ImVec2(panelWidth, changelogHeight), true, ImGuiWindowFlags_NoScrollbar);
        {
            ImGui::TextColored(rgbColor, "Changelogs");
            ImGui::Separator();
            ImGui::Spacing();

            auto BulletText = [](const char* text) {
                ImGui::TextDisabled("- %s", text);
            };

            ImGui::TextColored(ImVec4(0.4f, 0.7f, 1.0f, 1.0f), "Changes");
            BulletText("Fixed Esp Count");
            BulletText("Fixed Aimbot Slider");
            BulletText("Fixed No Menu [A16]");
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.4f, 1.0f), "What's New?");
            BulletText("New UI");
            BulletText("Added Camo's");
            BulletText("Added More Info");
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Optimization");
            BulletText("Less Lag");
            BulletText("Remove Redundant Codes");
            BulletText("Remove Heavy Sort [ESP]");
        }
        ImGui::EndChild();

        ImGui::BeginChild("CreditsPanel", ImVec2(panelWidth, creditsHeight), true, ImGuiWindowFlags_NoScrollbar);
        {
            if (LogoGarena.textureId != 0) {
                float availableHeight = ImGui::GetContentRegionAvail().y;
                float imageSize = 55.0f;
                ImGui::SetCursorPosY((availableHeight - imageSize) * 0.5f + 8.0f);

                ImGui::BeginGroup();
                {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5.0f);
                    ImGui::Image(LogoGarena.textureId, ImVec2(imageSize, imageSize)); 
                    ImGui::SameLine(0, 20.0f);
                    
                    ImGui::BeginGroup();
                    {
                        ImGui::AlignTextToFramePadding(); 
                        ImGui::TextDisabled("Version : ");
                        ImGui::SameLine();
                        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 1.0f);
                        ImGui::TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), "1.6.56");
                        
                        ImGui::AlignTextToFramePadding();
                        ImGui::TextDisabled("Developer : "); 
                        ImGui::SameLine();
                        ImGui::TextColored(ImVec4(1.0f, 0.2f, 0.2f, 1.0f), "@GOD CLOWN");
                    }
                    ImGui::EndGroup();
                }
                ImGui::EndGroup();
            }
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();
}

if (tab == 2) {
    const float totalWidth = ImGui::GetContentRegionAvail().x;
    const float spacing = 10.0f;
    const float panelWidth = (totalWidth - spacing) * 0.5f; 
    const float childHeight = ImGui::GetContentRegionAvail().y;

    static float rgb_timer = 0.0f;
    rgb_timer += ImGui::GetIO().DeltaTime * 0.5f;
    ImVec4 rgb_color = ImVec4((sin(rgb_timer) * 0.5f + 0.5f), (sin(rgb_timer + 2.0f) * 0.5f + 0.5f), (sin(rgb_timer + 4.0f) * 0.5f + 0.5f), 1.0f);
    
    ImGui::BeginGroup();
    ImGui::BeginChild("ESP Nav##1", ImVec2(panelWidth, (childHeight * 0.64f) - (spacing / 2)), true);
    
    ImGui::TextColored(rgb_color, "Visual Features");
    ImGui::Separator();
    ImGui::Spacing();
    
    RenderStyledToggle("Show Line", &Config.ESPMenu.isPlayerLine);
    RenderStyledToggle("Show Box", &Config.ESPMenu.Box);
    RenderStyledToggle("Show Health", &Config.ESPMenu.Health);
    RenderStyledToggle("Show Name", &Config.ESPMenu.Name);
    RenderStyledToggle("Show Distance", &Config.ESPMenu.Distance);
    RenderStyledToggle("Show Counter", &Config.ESPMenu.Count);
    RenderStyledToggle("Show Alert", &Config.ESPMenu.Alert);
    RenderStyledToggle("Show Skeleton", &Config.ESPMenu.Skeleton);
    
    ImGui::EndChild();
    ImGui::EndGroup();

    ImGui::SameLine(0, spacing);

    ImGui::BeginGroup();
    ImGui::BeginChild("ESP Preview Child", ImVec2(panelWidth, (childHeight * 0.64f) - (spacing / 2)), true, ImGuiWindowFlags_NoScrollbar);
    
    ImGui::TextColored(rgb_color, "Visual Preview");
    ImGui::Separator();
    ImGui::Spacing();
    
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImVec2 pMin = ImGui::GetCursorScreenPos();
    ImVec2 pMax = ImVec2(ImGui::GetWindowPos().x + ImGui::GetWindowWidth() - 10.0f, ImGui::GetWindowPos().y + ImGui::GetWindowHeight() - 10.0f);
    
    ImGui::Dummy(ImVec2(pMax.x - pMin.x, pMax.y - pMin.y));

    if (pMax.x > pMin.x && pMax.y > pMin.y) {
        draw->PushClipRect(pMin, pMax, true);
        
        static float target_switch_timer = 0.0f;
        static bool preview_is_bot = false;
        target_switch_timer += ImGui::GetIO().DeltaTime;
        if (target_switch_timer >= 3.0f) {
            preview_is_bot = !preview_is_bot;
            target_switch_timer = 0.0f;
        }

        ImU32 color = preview_is_bot ? 
            ImGui::ColorConvertFloat4ToU32(ImVec4(Config.sColorsESPBOT.LineBOT[0], Config.sColorsESPBOT.LineBOT[1], Config.sColorsESPBOT.LineBOT[2], 1.0f)) :
            ImGui::ColorConvertFloat4ToU32(ImVec4(Config.sColorsESPPLAYER.LinePLAYER[0], Config.sColorsESPPLAYER.LinePLAYER[1], Config.sColorsESPPLAYER.LinePLAYER[2], 1.0f));
        
        ImU32 boxColor = preview_is_bot ? 
            ImGui::ColorConvertFloat4ToU32(ImVec4(Config.sColorsESPBOT.BoxBOT[0], Config.sColorsESPBOT.BoxBOT[1], Config.sColorsESPBOT.BoxBOT[2], 1.0f)) :
            ImGui::ColorConvertFloat4ToU32(ImVec4(Config.sColorsESPPLAYER.BoxPLAYER[0], Config.sColorsESPPLAYER.BoxPLAYER[1], Config.sColorsESPPLAYER.BoxPLAYER[2], 1.0f));
        
        float bThick = preview_is_bot ? Config.Bbox : Config.Pbox;
        float sThick = 1.5f; 

        float previewWidth = pMax.x - pMin.x;
        float previewHeight = pMax.y - pMin.y;
        
        static float movement_timer = 0.0f;
        movement_timer += ImGui::GetIO().DeltaTime * 3.8f; 
        float xOffset = sin(movement_timer * 0.4f) * (previewWidth * 0.18f); 

        ImVec2 center = ImVec2((pMin.x + previewWidth * 0.5f) + xOffset, pMin.y + previewHeight * 0.5f + 20.0f);
        
        float bH = previewHeight * 0.65f; 
        float bW = bH * 0.45f;
        float x = center.x - (bW / 2);
        float y = center.y - (bH / 2);

        ImVec2 HeadSc = ImVec2(center.x, y);

        if (Config.ESPMenu.Skeleton) {
            ImVec2 head = ImVec2(center.x, y + (bH * 0.12f));
            ImVec2 neck = ImVec2(center.x, y + (bH * 0.22f));
            ImVec2 spine = ImVec2(center.x, y + (bH * 0.42f));
            ImVec2 hips = ImVec2(center.x, y + (bH * 0.62f));

            draw->AddCircle(head, bH * 0.055f, color, 12, sThick);
            draw->AddLine(head, neck, color, sThick);
            draw->AddLine(neck, spine, color, sThick);
            draw->AddLine(spine, hips, color, sThick);

            float legSwingLeft = sin(movement_timer);
            float legSwingRight = -sin(movement_timer);
            
            float leftKneeX = center.x - (bW * 0.14f) + (legSwingLeft * (bW * 0.12f));
            float leftKneeY = y + (bH * 0.76f) - (fabs(legSwingLeft) * (bH * 0.03f));
            ImVec2 leftKnee = ImVec2(leftKneeX, leftKneeY);
            ImVec2 leftFoot = ImVec2(center.x - (bW * 0.18f) + (legSwingLeft * (bW * 0.28f)), y + (bH * 0.95f));
            
            draw->AddLine(hips, leftKnee, color, sThick);
            draw->AddLine(leftKnee, leftFoot, color, sThick);

            float rightKneeX = center.x + (bW * 0.14f) + (legSwingRight * (bW * 0.12f));
            float rightKneeY = y + (bH * 0.76f) - (fabs(legSwingRight) * (bH * 0.03f));
            ImVec2 rightKnee = ImVec2(rightKneeX, rightKneeY);
            ImVec2 rightFoot = ImVec2(center.x + (bW * 0.18f) + (legSwingRight * (bW * 0.28f)), y + (bH * 0.95f));
            
            draw->AddLine(hips, rightKnee, color, sThick);
            draw->AddLine(rightKnee, rightFoot, color, sThick);

            float armSwingLeft = -sin(movement_timer);
            float armSwingRight = sin(movement_timer);

            ImVec2 leftElbow = ImVec2(center.x - (bW * 0.22f) + (armSwingLeft * (bW * 0.10f)), y + (bH * 0.38f));
            ImVec2 leftHand = ImVec2(center.x - (bW * 0.32f) + (armSwingLeft * (bW * 0.22f)), y + (bH * 0.52f));
            draw->AddLine(neck, leftElbow, color, sThick);
            draw->AddLine(leftElbow, leftHand, color, sThick);

            ImVec2 rightElbow = ImVec2(center.x + (bW * 0.22f) + (armSwingRight * (bW * 0.10f)), y + (bH * 0.38f));
            ImVec2 rightHand = ImVec2(center.x + (bW * 0.32f) + (armSwingRight * (bW * 0.22f)), y + (bH * 0.52f));
            draw->AddLine(neck, rightElbow, color, sThick);
            draw->AddLine(rightElbow, rightHand, color, sThick);
        }

        if (Config.ESPMenu.Box) {
            float lW = bW * 0.25f; float lH = bH * 0.2f;
            ImVec2 corners[8][2] = {
                {{x, y}, {x + lW, y}}, {{x, y}, {x, y + lH}},
                {{x + bW, y}, {x + bW - lW, y}}, {{x + bW, y}, {x + bW, y + lH}},
                {{x, y + bH}, {x + lW, y + bH}}, {{x, y + bH}, {x, y + bH - lH}},
                {{x + bW, y + bH}, {x + bW - lW, y + bH}}, {{x + bW, y + bH}, {x + bW, y + bH - lH}}
            };
            for (auto& edge : corners) {
                draw->AddLine(edge[0], edge[1], IM_COL32(0, 0, 0, 255), bThick + 1.5f);
                draw->AddLine(edge[0], edge[1], boxColor, bThick);
            }
        }

        if (Config.ESPMenu.Name || Config.ESPMenu.Distance || Config.ESPMenu.Health) {
            const char* dTxt = "35m";
            std::string nameTxt = preview_is_bot ? "Bot" : "Player";
            
            float padding = 8.0f;
            float iconSpace = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? 28.0f : 0.0f;
            ImVec2 nameSize = Config.ESPMenu.Name ? ImGui::CalcTextSize(nameTxt.c_str()) : ImVec2(0,0);
            ImVec2 distSize = Config.ESPMenu.Distance ? ImGui::CalcTextSize(dTxt) : ImVec2(0,0);
            
            float boxW = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? (iconSpace + nameSize.x + distSize.x + (padding * 4)) : 65.0f;
            float boxH = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? 42.0f : 15.0f;
            float boxX = HeadSc.x - (boxW / 2.0f); 
            float boxY = y - boxH - 16.0f; 

            draw->AddRectFilled(ImVec2(boxX, boxY), ImVec2(boxX + boxW, boxY + boxH), IM_COL32(15, 15, 15, 220), 6.0f);
            draw->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + boxW, boxY + boxH), IM_COL32(120, 120, 120, 255), 6.0f, 0, 1.5f);

            float currentX = boxX + padding;
            if (Config.ESPMenu.Name || Config.ESPMenu.Distance) {
                float iX = currentX + 10.0f; float iY = boxY + 16.0f;
                if (preview_is_bot) {
                    draw->AddLine(ImVec2(iX - 4, iY - 7), ImVec2(iX - 2, iY - 4), color, 1.2f);
                    draw->AddLine(ImVec2(iX + 4, iY - 7), ImVec2(iX + 2, iY - 4), color, 1.2f);
                    draw->AddRectFilled(ImVec2(iX - 6, iY - 4), ImVec2(iX + 6, iY + 4), color, 1.5f);
                    draw->AddCircleFilled(ImVec2(iX - 2.5f, iY - 1), 1.2f, IM_COL32(15, 15, 15, 255));
                    draw->AddCircleFilled(ImVec2(iX + 2.5f, iY - 1), 1.2f, IM_COL32(15, 15, 15, 255));
                } else {
                    draw->AddCircleFilled(ImVec2(iX, iY - 8), 1.5f, color);
                    draw->AddCircleFilled(ImVec2(iX, iY - 3), 4.5f, color);
                    draw->AddRectFilled(ImVec2(iX - 6, iY + 3), ImVec2(iX + 6, iY + 8), color, 10.0f, ImDrawFlags_RoundCornersTop);
                }
                currentX += iconSpace;
            }
            
            if (Config.ESPMenu.Name) { 
                draw->AddText(nullptr, 17.0f, ImVec2(currentX, boxY + 6), color, nameTxt.c_str()); 
                currentX += nameSize.x + padding; 
            }
            if (Config.ESPMenu.Distance) {
                draw->AddText(nullptr, 15.0f, ImVec2(currentX, boxY + 8), IM_COL32(220, 220, 220, 255), dTxt);
            }
            if (Config.ESPMenu.Health) {
                float barY = boxY + boxH - 10.0f; 
                float barW = boxW - (padding * 2); 
                float hpW = (barW * 85) / 100.0f; 
                long hCol = IM_COL32(76, 255, 0, 255); 
                draw->AddRectFilled(ImVec2(boxX + padding, barY), ImVec2(boxX + padding + barW, barY + 5), IM_COL32(40, 40, 40, 255), 2.0f);
                draw->AddRectFilled(ImVec2(boxX + padding, barY), ImVec2(boxX + padding + hpW, barY + 5), hCol, 2.0f);
            }
        }

        draw->PopClipRect();
    }
    
    ImGui::EndChild();
    ImGui::EndGroup();

    ImGui::Spacing();

    ImGui::BeginChild("ESP Config Panel", ImVec2(totalWidth, (childHeight * 0.36f) - (spacing / 2)), true, ImGuiWindowFlags_AlwaysVerticalScrollbar);
    
    ImGui::TextColored(rgb_color, "Visual Configuration");
    ImGui::Separator();
    ImGui::Spacing();

    const float sliderWidth = 160.0f; 
    const float alignX = ImGui::GetContentRegionAvail().x - sliderWidth - 5.0f;

    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(3, 2));

    ImGui::ColorEdit3("Bot Line", Config.sColorsESPBOT.LineBOT, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine(alignX);
    ImGui::PushItemWidth(sliderWidth);
    RenderStyledSlider("##BlineSlider", &Config.Bline, 0.5f, 10.0f);
    ImGui::PopItemWidth();

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 1.0f);

    ImGui::ColorEdit3("Bot Box", Config.sColorsESPBOT.BoxBOT, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine(alignX);
    ImGui::PushItemWidth(sliderWidth);
    RenderStyledSlider("##BboxSlider", &Config.Bbox, 0.5f, 10.0f);
    ImGui::PopItemWidth();

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 1.0f);

    ImGui::ColorEdit3("Player Line", Config.sColorsESPPLAYER.LinePLAYER, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine(alignX);
    ImGui::PushItemWidth(sliderWidth);
    RenderStyledSlider("##PlineSlider", &Config.Pline, 0.5f, 5.0f);
    ImGui::PopItemWidth();

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 1.0f);

    ImGui::ColorEdit3("Player Box", Config.sColorsESPPLAYER.BoxPLAYER, ImGuiColorEditFlags_NoInputs);
    ImGui::SameLine(alignX);
    ImGui::PushItemWidth(sliderWidth);
    RenderStyledSlider("##PboxSlider", &Config.Pbox, 0.5f, 5.0f);
    ImGui::PopItemWidth();

    ImGui::PopStyleVar();
    ImGui::EndChild();
}
        
if (tab == 3) {
    const float totalWidth = ImGui::GetContentRegionAvail().x;
    const float spacing = 10.0f;
    const float panelWidth = (totalWidth - spacing) * 0.5f; 
    const float childHeight = ImGui::GetContentRegionAvail().y;
    
    static float rgb_timer = 0.0f;
    rgb_timer += ImGui::GetIO().DeltaTime * 0.5f;
    ImVec4 rgb_color = ImVec4(
        (sin(rgb_timer) * 0.5f + 0.5f),
        (sin(rgb_timer + 2.0f) * 0.5f + 0.5f),
        (sin(rgb_timer + 4.0f) * 0.5f + 0.5f),
        1.0f
    );

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Memory Nav##2", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Aim Navigation");
            ImGui::Separator();
            ImGui::Spacing();
            
            RenderStyledToggle("Aimlock", &Config.Aim.AimAssist);
            RenderStyledToggle("Aimbot 360", &Config.Aim.Aimbot360);
            RenderStyledToggle("Render FOV", &Config.ESPMenu.Crosshair);
            RenderStyledToggle("Render AimLine", &Config.ESPMenu.Aimline);
        }
        ImGui::EndChild();

        ImGui::BeginChild("Weapon Memory Child", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true, ImGuiWindowFlags_NoScrollbar);
        {
            ImGui::TextColored(rgb_color, "Weapon Memory");
            ImGui::Separator();
            ImGui::Spacing();
            
            RenderStyledToggle("Hide Record / ScreenShot", &g_HideFromRecord);
            RenderStyledToggle("Bullet Track", &Config.Aim.BulletTrack);
            RenderStyledToggle("Hitbox", &Config.ExtraMenu.Hit);
            RenderStyledToggle("No Overheat", &Config.ExtraMenu.Rpd);
            RenderStyledToggle("Long Range", &Config.ExtraMenu.Range);
            RenderStyledToggle("Instant Shot", &Config.ExtraMenu.AutoSnipe);
            RenderStyledToggle("Quick Firing", &Config.ExtraMenu.Auto);
            RenderStyledToggle("Weapon Kinetic", &Config.ExtraMenu.Kinetic);
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();

    ImGui::SameLine(0, spacing);

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Aim Settings Child##3", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Aim Settings");
            ImGui::Separator();
            ImGui::Spacing();
            
            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Aim Assist");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", Config.Aim.AimAssistSize);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##AimlockAdj", &Config.Aim.AimAssistSize, 0.0f, 100.0f);
            ImGui::Spacing();
            

            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("FOV Size");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", (Config.Aim.size / 500.0f) * 100.0f);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##FOVScaleSlider", &Config.Aim.size, 0.0f, 500.0f);
            ImGui::Spacing();
            
        }
        ImGui::EndChild();

        ImGui::BeginChild("Memory Content##2", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true, ImGuiWindowFlags_NoScrollbar);
        {
            ImGui::TextColored(rgb_color, "Weapon Enhancer");
            ImGui::Separator();
            ImGui::Spacing();
            
            RenderStyledToggle("No Recoil", &Config.ExtraMenu.Recoil);
            RenderStyledToggle("No Spread", &Config.ExtraMenu.Spread);
            RenderStyledToggle("No Reload", &Config.ExtraMenu.Reload);
            RenderStyledToggle("No Scope", &Config.ExtraMenu.Scope);
            RenderStyledToggle("No Switch", &Config.ExtraMenu.Switch);
            RenderStyledToggle("No Shake", &Config.ExtraMenu.Shake);
            RenderStyledToggle("No Flashbang", &Config.ExtraMenu.Flash);
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();
}

if (tab == 4) {
    const float totalWidth = ImGui::GetContentRegionAvail().x;
    const float spacing = 10.0f;
    const float panelWidth = (totalWidth - spacing) * 0.5f; 
    const float childHeight = ImGui::GetContentRegionAvail().y;

    static float rgb_timer = 0.0f;
    rgb_timer += ImGui::GetIO().DeltaTime * 0.5f;
    ImVec4 rgb_color = ImVec4(
        (sin(rgb_timer) * 0.5f + 0.5f),
        (sin(rgb_timer + 2.0f) * 0.5f + 0.5f),
        (sin(rgb_timer + 4.0f) * 0.5f + 0.5f),
        1.0f
    );

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Ability Nav##3", ImVec2(panelWidth, (childHeight * 0.55f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Movement Abilities");
            ImGui::Separator();
            ImGui::Spacing();

            RenderStyledToggle("Snowboard Boost", &SnowB);
            RenderStyledToggle("Long Slide", &SlideTackle);
            RenderStyledToggle("Speed Hack", &isSpeedHackEnabled);
            RenderStyledToggle("High Jump", &isJumpAdjustmentEnabled);
            if (!isJumpAdjustmentEnabled) {
                jumpHeightMultiplier = 1.0f;
            }
        }
        ImGui::EndChild();

        ImGui::BeginChild("Visual Abilities Child", ImVec2(panelWidth, (childHeight * 0.45f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Visual Abilities");
            ImGui::Separator();
            ImGui::Spacing();

            RenderStyledToggle("Wallhack Y/B", &Config.ExtraMenu.WallHack);
            RenderStyledToggle("Red Wallhack", &Config.ExtraMenu.RedWallhack);
            RenderStyledToggle("Wallhack Outline", &Config.ExtraMenu.Outline);
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();

    ImGui::SameLine(0, spacing);

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Ability Content##3", ImVec2(panelWidth, (childHeight * 0.55f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Ability Settings");
            ImGui::Separator();
            ImGui::Spacing();

            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Snowboard Settings");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", SnowBsize);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##SnowBoost", &SnowBsize, 0.0f, 100.0f);
            ImGui::Spacing();
            

            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Slide Settings");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", (SlideRange / 30.0f) * 100.0f);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##SlideRange", &SlideRange, 0.0f, 30.0f);
            ImGui::Spacing();
            

            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Speed Settings");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", ((speedHackMultiplier - 0.5f) / 9.5f) * 100.0f);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##SpeedHack", &speedHackMultiplier, 0.5f, 10.0f);
            ImGui::Spacing();
            

            
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Jump Settings");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 30.0f);
            ImGui::SetWindowFontScale(0.85f);
            ImGui::TextDisabled("%.0f%%", ((jumpHeightMultiplier - 0.5f) / 4.5f) * 100.0f);
            ImGui::SetWindowFontScale(1.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##JumpHeight", &jumpHeightMultiplier, 0.5f, 5.0f);
            ImGui::Spacing();
            
        }
        ImGui::EndChild();

        ImGui::BeginChild("Additional Features Child", ImVec2(panelWidth, (childHeight * 0.45f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Additional Features");
            ImGui::Separator();
            ImGui::Spacing();

            RenderStyledToggle("No Parachute", &Config.ExtraMenu.Parachute);
            RenderStyledToggle("Sky Diving Speed", &Config.ExtraMenu.Diving);
        /*   RenderStyledToggle("Jet Boost + Jump", &Config.ExtraMenu.JetJ);
           RenderStyledToggle("Jet Boost + Slide", &Config.ExtraMenu.JetS);
           RenderStyledToggle("Long Execute", &isExecute);
           RenderStyledToggle("Radar MP", &Config.ExtraMenu.Radar1);
           RenderStyledToggle("Spectate No Delay", &Config.ExtraMenu.Spectate);
           RenderStyledToggle("Fast Revival Time", &Config.ExtraMenu.Revive);*/
           RenderStyledToggle("Fast Medicine Time", &Config.ExtraMenu.Medicine);
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();
}

static float scrollVelocity = 0.0f;
static float friction = 0.95f;
static char charSearchQuery[256] = "";

static std::unordered_map<int, uintptr_t> cachedCharacterModels;
static std::unordered_map<int, uintptr_t> cachedItemResources;
static std::unordered_map<int, uintptr_t> cachedRoleConfs;
static std::unordered_map<int, uintptr_t> cachedWeaponConfs;
static std::unordered_map<int, uintptr_t> cachedWeaponExtras;
static uintptr_t cachedDeadboxSkin = 0;
static uintptr_t cachedPlaneSkin = 0;

if (tab == 5) {    
    ImGui::SetWindowFontScale(1.0f);
    
    float fullWidth = ImGui::GetContentRegionAvail().x;
    float childHeight = ImGui::GetContentRegionAvail().y;

    ImGui::BeginChild("##SkinPanelFull", ImVec2(fullWidth, childHeight), true, ImGuiWindowFlags_NoScrollbar);
    
    float time = (float)ImGui::GetTime();
    float pulse = (sinf(time * 3.0f) * 0.5f) + 0.5f; 
    ImVec4 activeColor = ImVec4(0.12f, 0.86f, 1.0f, 1.0f);

    ImGui::Spacing();
    static int skin_tab = 0;
    const char* tab_names[] = { "Target", "Chars", "Guns", "Watch", "Box", "Plane", "Vehicle" };
    static std::map<std::string, bool> ui_ToggleStates;

    float availableW = ImGui::GetContentRegionAvail().x;
    float spacingX = ImGui::GetStyle().ItemSpacing.x;
    float tabBtnW = (availableW - (spacingX * 6)) / 7.0f;

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
    for (int i = 0; i < 7; i++) {
        if (i > 0) ImGui::SameLine();
        bool selected = (skin_tab == i);
        
        if (selected) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.05f, 0.05f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.05f, 0.05f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.05f, 0.05f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, activeColor);
            ImGui::PushStyleColor(ImGuiCol_Border, activeColor);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.2f);
        } else {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.5f, 0.5f, 0.5f, 1.0f));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
        }

        if (ImGui::Button(tab_names[i], ImVec2(tabBtnW, 40))) {
            skin_tab = i;
            scrollVelocity = 0.0f;
        }

        if (selected) {
            ImVec2 p_min = ImGui::GetItemRectMin();
            ImVec2 p_max = ImGui::GetItemRectMax();
            ImGui::GetWindowDrawList()->AddRectFilled(
                ImVec2(p_min.x + 8, p_max.y - 3), 
                ImVec2(p_max.x - 8, p_max.y - 1), 
                ImGui::GetColorU32(activeColor), 2.0f
            );
            ImGui::PopStyleVar();
            ImGui::PopStyleColor(5);
        } else {
            ImGui::PopStyleVar();
            ImGui::PopStyleColor(2);
        }
    }
    ImGui::PopStyleVar();

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::TextColored(activeColor, ICON_FA_SEARCH " Search Filters");
    
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.10f, 0.10f, 0.10f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border, activeColor); 
    
    ImGui::PushItemWidth(-1.0f);
    g_SkinSearch.RenderSearchBar();
    
    static bool showKeyboardWindow = false;
    if (ImGui::IsItemActive()) { 
        showKeyboardWindow = true; 
    }
    ImGui::PopItemWidth();
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar(2);

    ImGui::Spacing();
    ImGui::Separator();

    int itemCount = 0;
    const char* itemType = "";
    std::string searchLower = ToLower(g_SkinSearch.GetSearchQuery());
    switch (skin_tab) {
        case 0: itemCount = g_targetCharacters.size(); itemType = "Target"; break;
        case 1: itemCount = charData.size(); itemType = "Characters"; break;
        case 2: itemCount = itemData.size(); itemType = "Weapons"; break;
        case 3: itemCount = watch.size(); itemType = "Watches"; break;
        case 4: itemCount = deadboxF.size(); itemType = "Deadboxes"; break;
        case 5: itemCount = dropplane.size(); itemType = "Planes"; break;
        case 6: itemCount = snowboardData.size(); itemType = "Vehicles"; break;
    }
    
    ImGui::Spacing();
    ImGui::AlignTextToFramePadding(); 
    ImGui::TextColored(ImVec4(0.95f, 0.05f, 0.95f, 1.0f), "[%s]: %d", itemType, itemCount);
    ImGui::SameLine();
    ImGui::TextDisabled("| Swipe to scroll");
    
    ImGui::SameLine();
    float buttonWidth = 35.0f; 
    ImGui::SetCursorPosX(ImGui::GetWindowWidth() - buttonWidth - ImGui::GetStyle().WindowPadding.x - 5.0f);
    
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 5.0f);
    if (ImGui::Button(ICON_FA_SAVE, ImVec2(buttonWidth, 25))) {
    TriggerSave(); 
    }
    ImGui::PopStyleVar();


    ImGui::Spacing();

    int executeCharIdx = -1;
    int executeWeaponIdx = -1;
    int executeWatchIdx = -1;
    int executeDeadboxIdx = -1;
    int executePlaneIdx = -1;

    int baseID = 0, extraID = 0, skinID = 0, itemID = 0, lootID = 0;

    ImGui::BeginChild("##SkinListScroll", ImVec2(0, childHeight - ImGui::GetCursorPosY() - (showKeyboardWindow ? 40 : 10)), true, ImGuiWindowFlags_NoScrollbar);
        
        if (ImGui::IsWindowHovered()) {
            if (ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
                scrollVelocity = ImGui::GetIO().MouseDelta.y;
                ImGui::SetScrollY(ImGui::GetScrollY() - scrollVelocity);
            } else {
                if (fabsf(scrollVelocity) > 0.1f) {
                    ImGui::SetScrollY(ImGui::GetScrollY() - scrollVelocity);
                    scrollVelocity *= friction;
                } else {
                    scrollVelocity = 0.0f;
                }
            }
        }
        
        ImGuiListClipper clipper;
        std::vector<int> filteredIndices;

        switch (skin_tab) {
        case 0:
            if (!g_targetCharacters.empty()) {
                filteredIndices.clear();
                for (int i = 0; i < (int)g_targetCharacters.size(); i++) {
                    if (!searchLower.empty() && ToLower(g_targetCharacters[i].name).find(searchLower) == std::string::npos) continue;
                    filteredIndices.push_back(i);
                }

                clipper.Begin((int)filteredIndices.size());
                while (clipper.Step()) {
                    for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                        int idx = filteredIndices[i];
                        const auto& target = g_targetCharacters[idx];
                        ImGui::PushID(idx);
                        
                        RenderRarityBadge(target.name.c_str());
                        std::string cleanName = GetCleanName(target.name);

                        bool isSelected = (g_selectedTargetCharIndex == idx);
                        ImVec4 textColor = isSelected ? ImVec4(0.95f, 0.05f, 0.95f, 1.0f) 
                                         : (favorites.count(target.name) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f));

                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));

                        bool oldState = isSelected;
                        RenderStyledToggle(cleanName.c_str(), &isSelected);

                        if (isSelected != oldState) {
                            float timeNow = (float)ImGui::GetTime();
                            if (timeNow - lastToggleTime[target.name] > 0.5f) toggleCounter[target.name] = 0;
                            toggleCounter[target.name]++;
                            lastToggleTime[target.name] = timeNow;

                            if (toggleCounter[target.name] >= 3) {
                                if (favorites.count(target.name)) favorites.erase(target.name);
                                else favorites.insert(target.name);
                                toggleCounter[target.name] = 0;
                            }

                            if (isSelected) {
                                g_selectedTargetCharIndex = idx;
                            } else if (g_selectedTargetCharIndex == idx) {
                                g_selectedTargetCharIndex = -1;
                            }
                        }

                        ImGui::PopStyleVar();
                        ImGui::PopStyleColor();
                        ImGui::PopID();
                        
                    }
                }
            }
            break;

        case 1:
            if (!charData.empty()) {
                std::vector<int> allIndices(charData.size());
                std::iota(allIndices.begin(), allIndices.end(), 0);
                
                std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
                    bool aFav = favorites.count(charData[a].charName);
                    bool bFav = favorites.count(charData[b].charName);
                    if (aFav != bFav) return aFav > bFav;
                    return a < b;
                });

                filteredIndices.clear();
                for (int idx : allIndices) {
                    if (!searchLower.empty() && ToLower(charData[idx].charName).find(searchLower) == std::string::npos) continue;
                    filteredIndices.push_back(idx);
                }
                
                clipper.Begin((int)filteredIndices.size());
                while (clipper.Step()) {
                    for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                        int idx = filteredIndices[i];
                        const auto& getchar = charData[idx];
                        ImGui::PushID(idx);

                        RenderRarityBadge(getchar.charName.c_str());
                        std::string cleanName = GetCleanName(getchar.charName);

                        ImVec4 textColor = favorites.count(getchar.charName) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                        ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));
                        
                        bool isVisualOn = ui_ToggleStates[getchar.charName];
                        bool oldState = isVisualOn;
                        RenderStyledToggle(cleanName.c_str(), &isVisualOn);
                        
                        if (isVisualOn != oldState) {
                            float timeNow = (float)ImGui::GetTime();
                            if (timeNow - lastToggleTime[getchar.charName] > 0.5f) toggleCounter[getchar.charName] = 0;
                            toggleCounter[getchar.charName]++;
                            lastToggleTime[getchar.charName] = timeNow;

                            if (toggleCounter[getchar.charName] >= 3) {
                                if (favorites.count(getchar.charName)) favorites.erase(getchar.charName);
                                else favorites.insert(getchar.charName);
                                toggleCounter[getchar.charName] = 0;
                            }

                            ui_ToggleStates[getchar.charName] = isVisualOn;
                            if (isVisualOn) {
                                for (const auto& other : charData) {
                                    if (other.charName != getchar.charName) ui_ToggleStates[other.charName] = false;
                                }
                                executeCharIdx = idx;
                            }
                        }
                        ImGui::PopStyleVar();
                        ImGui::PopStyleColor();
                        ImGui::PopID();
                    }
                }
            }
            break;

    case 2:
        if (!itemData.empty()) {
            std::vector<int> allIndices(itemData.size());
            std::iota(allIndices.begin(), allIndices.end(), 0);
            
            std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
                bool aFav = favorites.count(itemData[a].itemName);
                bool bFav = favorites.count(itemData[b].itemName);
                if (aFav != bFav) return aFav > bFav;
                return a < b;
            });

            filteredIndices.clear();
            for (int idx : allIndices) {
                if (!searchLower.empty() && ToLower(itemData[idx].itemName).find(searchLower) == std::string::npos) continue;
                filteredIndices.push_back(idx);
            }

            clipper.Begin((int)filteredIndices.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                    int idx = filteredIndices[i];
                    const auto& currentItem = itemData[idx];
                    ImGui::PushID(idx);

                    RenderRarityBadge(currentItem.itemName.c_str());
                    std::string cleanName = GetCleanName(currentItem.itemName);

                    ImVec4 textColor = favorites.count(currentItem.itemName) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));

                    bool isVisualOn = ui_ToggleStates[currentItem.itemName];
                    bool oldState = isVisualOn;
                    
                    RenderStyledToggle(cleanName.c_str(), &isVisualOn);
                    
                    if (isVisualOn != oldState) {
                        float timeNow = (float)ImGui::GetTime();
                        if (timeNow - lastToggleTime[currentItem.itemName] > 0.5f) toggleCounter[currentItem.itemName] = 0;
                        toggleCounter[currentItem.itemName]++;
                        lastToggleTime[currentItem.itemName] = timeNow;

                        if (toggleCounter[currentItem.itemName] >= 3) {
                            if (favorites.count(currentItem.itemName)) favorites.erase(currentItem.itemName);
                            else favorites.insert(currentItem.itemName);
                            toggleCounter[currentItem.itemName] = 0;
                        }

                        ui_ToggleStates[currentItem.itemName] = isVisualOn;
                        if (isVisualOn) {
                            std::string currentBase = GetBaseWeaponName(currentItem.itemName);
                            for (const auto& other : itemData) {
                                if (other.itemName != currentItem.itemName && GetBaseWeaponName(other.itemName) == currentBase) {
                                    ui_ToggleStates[other.itemName] = false;
                                }
                            }
                            executeWeaponIdx = idx;
                        }
                    }
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor();
                    ImGui::PopID();

                }
            }
        } else {
            ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "No weapon skins loaded");
        }
        break;

    case 3:
        if (!watch.empty()) {
            std::vector<int> allIndices(watch.size());
            std::iota(allIndices.begin(), allIndices.end(), 0);
            
            std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
                bool aFav = favorites.count(watch[a].watchname);
                bool bFav = favorites.count(watch[b].watchname);
                if (aFav != bFav) return aFav > bFav;
                return a < b;
            });

            filteredIndices.clear();
            for (int idx : allIndices) {
                if (!searchLower.empty() && ToLower(watch[idx].watchname).find(searchLower) == std::string::npos) continue;
                if (watch[idx].watchname.find("Watch") == std::string::npos || watch[idx].watchname.find("Face") != std::string::npos) continue;
                filteredIndices.push_back(idx);
            }
            
            clipper.Begin((int)filteredIndices.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                    int idx = filteredIndices[i];
                    const auto& forwatch = watch[idx];
                    ImGui::PushID(idx);

                    RenderRarityBadge(forwatch.watchname.c_str());
                    std::string cleanName = GetCleanName(forwatch.watchname);

                    ImVec4 textColor = favorites.count(forwatch.watchname) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));
                    
                    bool isVisualOn = ui_ToggleStates[forwatch.watchname];
                    bool oldState = isVisualOn;
                    RenderStyledToggle(cleanName.c_str(), &isVisualOn);
                    
                    if (isVisualOn != oldState) {
                        float timeNow = (float)ImGui::GetTime();
                        if (timeNow - lastToggleTime[forwatch.watchname] > 0.5f) toggleCounter[forwatch.watchname] = 0;
                        toggleCounter[forwatch.watchname]++;
                        lastToggleTime[forwatch.watchname] = timeNow;

                        if (toggleCounter[forwatch.watchname] >= 3) {
                            if (favorites.count(forwatch.watchname)) favorites.erase(forwatch.watchname);
                            else favorites.insert(forwatch.watchname);
                            toggleCounter[forwatch.watchname] = 0;
                        }

                        ui_ToggleStates[forwatch.watchname] = isVisualOn;
                        if (isVisualOn) {
                            for (const auto& other : watch) {
                                if (other.watchname != forwatch.watchname) ui_ToggleStates[other.watchname] = false;
                            }
                            executeWatchIdx = idx;
                        }
                    }
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
        }
        break;

    case 4:
        if (!deadboxF.empty()) {
            std::vector<int> allIndices(deadboxF.size());
            std::iota(allIndices.begin(), allIndices.end(), 0);
            
            std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
                bool aFav = favorites.count(deadboxF[a].deadname);
                bool bFav = favorites.count(deadboxF[b].deadname);
                if (aFav != bFav) return aFav > bFav;
                return a < b;
            });

            filteredIndices.clear();
            for (int idx : allIndices) {
                if (!searchLower.empty() && ToLower(deadboxF[idx].deadname).find(searchLower) == std::string::npos) continue;
                filteredIndices.push_back(idx);
            }

            clipper.Begin((int)filteredIndices.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                    int idx = filteredIndices[i];
                    const auto& deadx = deadboxF[idx];
                    ImGui::PushID(idx);

                    RenderRarityBadge(deadx.deadname.c_str());
                    std::string cleanName = GetCleanName(deadx.deadname);

                    ImVec4 textColor = favorites.count(deadx.deadname) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));
                    
                    bool isVisualOn = ui_ToggleStates[deadx.deadname];
                    bool oldState = isVisualOn;
                    RenderStyledToggle(cleanName.c_str(), &isVisualOn);
                    
                    if (isVisualOn != oldState) {
                        float timeNow = (float)ImGui::GetTime();
                        if (timeNow - lastToggleTime[deadx.deadname] > 0.5f) toggleCounter[deadx.deadname] = 0;
                        toggleCounter[deadx.deadname]++;
                        lastToggleTime[deadx.deadname] = timeNow;

                        if (toggleCounter[deadx.deadname] >= 3) {
                            if (favorites.count(deadx.deadname)) favorites.erase(deadx.deadname);
                            else favorites.insert(deadx.deadname);
                            toggleCounter[deadx.deadname] = 0;
                        }

                        ui_ToggleStates[deadx.deadname] = isVisualOn;
                        if (isVisualOn) {
                            for (const auto& other : deadboxF) {
                                if (other.deadname != deadx.deadname) ui_ToggleStates[other.deadname] = false;
                            }
                            executeDeadboxIdx = idx;
                        }
                    }
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
        }
        break;

    case 5:
        if (!dropplane.empty()) {
            std::vector<int> allIndices(dropplane.size());
            std::iota(allIndices.begin(), allIndices.end(), 0);
            
            std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
                bool aFav = favorites.count(dropplane[a].planename);
                bool bFav = favorites.count(dropplane[b].planename);
                if (aFav != bFav) return aFav > bFav;
                return a < b;
            });

            filteredIndices.clear();
            for (int idx : allIndices) {
                if (!searchLower.empty() && ToLower(dropplane[idx].planename).find(searchLower) == std::string::npos) continue;
                filteredIndices.push_back(idx);
            }

            clipper.Begin((int)filteredIndices.size());
            while (clipper.Step()) {
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                    int idx = filteredIndices[i];
                    const auto& planex = dropplane[idx];
                    ImGui::PushID(idx);

                    RenderRarityBadge(planex.planename.c_str());
                    std::string cleanName = GetCleanName(planex.planename);

                    ImVec4 textColor = favorites.count(planex.planename) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                    ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));
                    
                    bool isVisualOn = ui_ToggleStates[planex.planename];
                    bool oldState = isVisualOn;
                    RenderStyledToggle(cleanName.c_str(), &isVisualOn);
                    
                    if (isVisualOn != oldState) {
                        float timeNow = (float)ImGui::GetTime();
                        if (timeNow - lastToggleTime[planex.planename] > 0.5f) toggleCounter[planex.planename] = 0;
                        toggleCounter[planex.planename]++;
                        lastToggleTime[planex.planename] = timeNow;

                        if (toggleCounter[planex.planename] >= 3) {
                            if (favorites.count(planex.planename)) favorites.erase(planex.planename);
                            else favorites.insert(planex.planename);
                            toggleCounter[planex.planename] = 0;
                        }

                        ui_ToggleStates[planex.planename] = isVisualOn;
                        if (isVisualOn) {
                            for (const auto& other : dropplane) {
                                if (other.planename != planex.planename) ui_ToggleStates[other.planename] = false;
                            }
                            executePlaneIdx = idx;
                        }
                    }
                    ImGui::PopStyleVar();
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
        }
        break;

case 6:
    if (!snowboardData.empty()) {
        std::vector<int> allIndices(snowboardData.size());
        std::iota(allIndices.begin(), allIndices.end(), 0);
        
        std::sort(allIndices.begin(), allIndices.end(), [&](int a, int b) {
            bool aFav = favorites.count(snowboardData[a].skinName);
            bool bFav = favorites.count(snowboardData[b].skinName);
            if (aFav != bFav) return aFav > bFav;
            return a < b;
        });

        filteredIndices.clear();
        for (int idx : allIndices) {
            if (!searchLower.empty() && ToLower(snowboardData[idx].skinName).find(searchLower) == std::string::npos) continue;
            filteredIndices.push_back(idx);
        }

        clipper.Begin((int)filteredIndices.size());
        while (clipper.Step()) {
            for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; i++) {
                int idx = filteredIndices[i];
                const auto& sb = snowboardData[idx];
                ImGui::PushID(idx);

                RenderRarityBadge(sb.skinName.c_str());
                std::string cleanName = GetCleanName(sb.skinName);

                ImVec4 textColor = favorites.count(sb.skinName) ? ImVec4(1.0f, 0.8f, 0.0f, 1.0f) : ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                ImGui::PushStyleColor(ImGuiCol_Text, textColor);
                ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(8, 8));

                bool isVisualOn = ui_ToggleStates[sb.skinName];
                bool oldState = isVisualOn;
                RenderStyledToggle(cleanName.c_str(), &isVisualOn);

                if (isVisualOn != oldState) {
                    float timeNow = (float)ImGui::GetTime();
                    if (timeNow - lastToggleTime[sb.skinName] > 0.5f) toggleCounter[sb.skinName] = 0;
                    toggleCounter[sb.skinName]++;
                    lastToggleTime[sb.skinName] = timeNow;

                    if (toggleCounter[sb.skinName] >= 3) {
                        if (favorites.count(sb.skinName)) favorites.erase(sb.skinName);
                        else favorites.insert(sb.skinName);
                        toggleCounter[sb.skinName] = 0;
                    }

                    ui_ToggleStates[sb.skinName] = isVisualOn;
                    if (isVisualOn) {
                        for (const auto& other : snowboardData) {
                            if (other.skinName != sb.skinName) ui_ToggleStates[other.skinName] = false;
                        }
                        SelectSnowboardSkin(sb.skinId);
                    }
                }

                ImGui::PopStyleVar();
                ImGui::PopStyleColor();
                ImGui::PopID();
            }
        }
    } else {
        ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "No snowboard skins loaded");
    }
    break;

    }
    ImGui::EndChild();

    if (executeCharIdx != -1) {
        const auto& getchar = charData[executeCharIdx];
        if (CharacterModelConfigInstance.size() > 0 && itemResourceConfigInstance.size() > 0 && RoleConfConfigInstance.size() > 0 && RolePackConfConfigInstance.size() > 0 && BRDeadboxSkinConfigInstance.size() > 0) {
            
            int selectedTraitor1P = g_targetCharacters[g_selectedTargetCharIndex].name == "Charly" ? 710001101 : g_targetCharacters[g_selectedTargetCharIndex].traitor1p;
            CharacterModelFields* targetCharacter1P = nullptr;
            
            if (cachedCharacterModels.find(selectedTraitor1P) != cachedCharacterModels.end()) {
                targetCharacter1P = (CharacterModelFields*)cachedCharacterModels[selectedTraitor1P];
            } else {
                for (auto charModel : CharacterModelConfigInstance) {
                    if (!charModel) continue;
                    CharacterModelFields* characterfields = (CharacterModelFields*)((uintptr_t)charModel + 0x10);
                    if (characterfields->Traitor1P == selectedTraitor1P) {
                        targetCharacter1P = characterfields;
                        cachedCharacterModels[selectedTraitor1P] = (uintptr_t)characterfields;
                        break;
                    }
                }
            }
            if (targetCharacter1P) {
                targetCharacter1P->BRBagModel         = getchar.charModel[0];
                targetCharacter1P->BRHeadModel        = getchar.charModel[1];
                targetCharacter1P->BRLobby            = getchar.charModel[2];
                targetCharacter1P->BRModel            = getchar.charModel[3];
                targetCharacter1P->BindEffect1P       = getchar.charModel[4];
                targetCharacter1P->ChangeClipEffect1P = getchar.charModel[5];
                targetCharacter1P->DefaultModelID     = getchar.charModel[6];
                targetCharacter1P->Guarder1P          = getchar.charModel[7];
                targetCharacter1P->Guarder3P          = getchar.charModel[8];
                targetCharacter1P->GuarderBagModel    = getchar.charModel[9];
                targetCharacter1P->GuarderHeadModel   = getchar.charModel[10];
                targetCharacter1P->GuarderLobby       = getchar.charModel[11];
            }

            int selectedTraitor3P = g_targetCharacters[g_selectedTargetCharIndex].name == "Charly" ? 710001102 : g_targetCharacters[g_selectedTargetCharIndex].traitor3p;
            CharacterModelFields* targetCharacter3P = nullptr;
            
            if (cachedCharacterModels.find(selectedTraitor3P) != cachedCharacterModels.end()) {
                targetCharacter3P = (CharacterModelFields*)cachedCharacterModels[selectedTraitor3P];
            } else {
                for (auto charModel : CharacterModelConfigInstance) {
                    if (!charModel) continue;
                    CharacterModelFields* characterfields = (CharacterModelFields*)((uintptr_t)charModel + 0x10);
                    if (characterfields->Traitor3P == selectedTraitor3P) {
                        targetCharacter3P = characterfields;
                        cachedCharacterModels[selectedTraitor3P] = (uintptr_t)characterfields;
                        break;
                    }
                }
            }
            if (targetCharacter3P) {
                targetCharacter3P->BRBagModel         = getchar.charModel[0];
                targetCharacter3P->BRHeadModel        = getchar.charModel[1];
                targetCharacter3P->BRLobby            = getchar.charModel[2];
                targetCharacter3P->BRModel            = getchar.charModel[3];
                targetCharacter3P->BindEffect1P       = getchar.charModel[4];
                targetCharacter3P->ChangeClipEffect1P = getchar.charModel[5];
                targetCharacter3P->DefaultModelID     = getchar.charModel[6];
                targetCharacter3P->Guarder1P          = getchar.charModel[7];
                targetCharacter3P->Guarder3P          = getchar.charModel[8];
                targetCharacter3P->GuarderBagModel    = getchar.charModel[9];
                targetCharacter3P->GuarderHeadModel   = getchar.charModel[10];
                targetCharacter3P->GuarderLobby       = getchar.charModel[11];
            }

            int selectedItemFieldsID = g_targetCharacters[g_selectedTargetCharIndex].name == "Charly" ? 100301208 : g_targetCharacters[g_selectedTargetCharIndex].itemID;
            ItemResourceFields* targetItem = nullptr;
            
            if (cachedItemResources.find(selectedItemFieldsID) != cachedItemResources.end()) {
                targetItem = (ItemResourceFields*)cachedItemResources[selectedItemFieldsID];
            } else {
                for (auto itemRes : itemResourceConfigInstance) {
                    if (!itemRes) continue;
                    ItemResourceFields* itemFields = (ItemResourceFields*)((uintptr_t)itemRes + 0x10);
                    if (itemFields->ID == selectedItemFieldsID) {
                        targetItem = itemFields;
                        cachedItemResources[selectedItemFieldsID] = (uintptr_t)itemFields;
                        break;
                    }
                }
            }
            if (targetItem) {
                targetItem->FxAssetID         = getchar.charRes[0];
                targetItem->InventoryModelID  = getchar.charRes[1];
                targetItem->ModelAssetIDRaw   = getchar.charRes[2];
                targetItem->UISmallSpriteName = getchar.charRes2[0];
                targetItem->UIMiniSpriteName  = getchar.charRes2[1];
                targetItem->UISpriteName      = getchar.charRes2[2];
                targetItem->UISquareSpriteName= getchar.charRes2[3];
            }

            int selectedRoleFID = g_targetCharacters[g_selectedTargetCharIndex].name == "Charly" ? 100301208 : g_targetCharacters[g_selectedTargetCharIndex].roleID;
            RoleConfFields* targetRole = nullptr;
            
            if (cachedRoleConfs.find(selectedRoleFID) != cachedRoleConfs.end()) {
                targetRole = (RoleConfFields*)cachedRoleConfs[selectedRoleFID];
            } else {
                for (auto roles : RoleConfConfigInstance) {
                    if (!roles) continue;
                    RoleConfFields* roleF = (RoleConfFields*)((uintptr_t)roles + 0x10);
                    if (roleF->ID == selectedRoleFID) {
                        targetRole = roleF;
                        cachedRoleConfs[selectedRoleFID] = (uintptr_t)roleF;
                        break;
                    }
                }
            }
            if (targetRole) {
                targetRole->roleLeftArmID        = getchar.charRole[0];
                targetRole->roleFinalSuitID      = getchar.charRole[1];
                targetRole->roleBasicHologramID  = getchar.charRole[2];
                targetRole->ColorID              = getchar.charRole[3];
                targetRole->ColorSubID           = getchar.charRole[4];
                targetRole->ShowRare             = getchar.charRole[5];
                targetRole->RoleLvGroupID        = getchar.charRole[6];
                targetRole->RolePackID           = getchar.charRole[7];
                targetRole->LOCID_Name           = getchar.charRole2[0];
            }

            int selectedRolePackID = g_targetCharacters[g_selectedTargetCharIndex].rolepackID;
            for (auto pack : RolePackConfConfigInstance) {
                if (!pack) continue;
                RolePackFields* packfields = (RolePackFields*)((uintptr_t)pack + 0x10);
                if (packfields->RolePackID == selectedRolePackID) {
                    packfields->EntryAnimID = getchar.charPack[1];
                    packfields->GestureId = getchar.charPack[2];
                    packfields->HandEffectUI = getchar.charPack[3];
                    packfields->LoadingFrame = getchar.charPack[4];
                    packfields->KillStreakSkinID = getchar.charPack[5];
                }
            }

            if (getchar.charExec[0] != 0) {
                bool patched = false;

                for (auto exec : ExecutionConfConfigInstance) {
                    if (!exec || !Tools::IsPtrValid(exec)) continue;
                    auto* ef = (ExecutionConfFields*)((uintptr_t)exec + 0x10);
                    if (!Tools::IsPtrValid(ef)) continue;

                    if (!ef->IsGeneric && ef->BelongRoleID == selectedRoleFID) {
                        ef->ExecutionID = getchar.charExec[0];
                        ef->ExecutionID_3p = getchar.charExec[1];
                        patched = true;
                        break;
                    }
                }

                if (!patched) {
                    for (auto exec : ExecutionConfConfigInstance) {
                        if (!exec || !Tools::IsPtrValid(exec)) continue;
                        auto* ef = (ExecutionConfFields*)((uintptr_t)exec + 0x10);
                        if (!Tools::IsPtrValid(ef)) continue;

                        if (ef->IsGeneric) {
                            ef->ExecutionID = getchar.charExec[0];
                            ef->ExecutionID_3p = getchar.charExec[1];
                        }
                    }
                }
            }
        }
    }

    if (executeWeaponIdx != -1 && !itemData.empty()) {
        auto getitem = itemData[executeWeaponIdx];
        
        baseID  = getitem.WeaponConf[0];
        extraID = getitem.WeaponExtra[0];
        skinID  = getitem.WeaponConf[2];
        itemID  = getitem.Item2Inventory[0];
        lootID  = getitem.Item2Inventory[3];

        for (auto item : itemInventoryInstance) {
            if (!item) continue;
            Item2InventoryFields* item2Fields = (Item2InventoryFields*)((uintptr_t)item + 0x20);
            if (item2Fields->ItemID == itemID || item2Fields->ItemID == lootID) {
                item2Fields->WeaponAssetGroupID = getitem.Item2Inventory[1];
                item2Fields->WeaponIconID = getitem.Item2Inventory[2];
            }
        }

        for (auto conf : weaponConfInstance) {
            if (!conf) continue;
            WeaponConfFields* weaponconfFields = (WeaponConfFields*)((uintptr_t)conf + 0x20);
            if (baseID == weaponconfFields->ID || extraID == weaponconfFields->ID || 
                skinID == weaponconfFields->ID || itemID == weaponconfFields->ID || 
                lootID == weaponconfFields->ID) {
                
                weaponconfFields->DefWeaponSkinID = skinID;
                weaponconfFields->DefaultKillBrocast = getitem.WeaponConf[3];
                weaponconfFields->ExternalUnVisible = true;

                for (auto skinConf : weaponConfInstance) {
                    if (!skinConf) continue;
                    WeaponConfFields* skinFields = (WeaponConfFields*)((uintptr_t)skinConf + 0x20);
                    if (skinFields->ID == skinID) {
                        weaponconfFields->LOCID_Name = skinFields->LOCID_Name;
                        break;
                    }
                }
                if (baseID == weaponconfFields->ID) {
                    weaponconfFields->ColorID = getitem.WeaponConf[1];
                }
            }
        }

        if (getitem.WeaponExtra[4] > 0) {
            activeKillEffects[baseID] = getitem.WeaponExtra[4];
            activeKillEffects[extraID] = getitem.WeaponExtra[4];
            activeKillEffects[skinID] = getitem.WeaponExtra[4];
            activeKillEffects[itemID] = getitem.WeaponExtra[4];
            activeKillEffects[lootID] = getitem.WeaponExtra[4];
        }

        auto patchWeaponExtra = [&](int targetID) {
            if (targetID <= 0) return;
            WeaponConfExtraFields* wef = nullptr;
            if (cachedWeaponExtras.find(targetID) != cachedWeaponExtras.end()) {
                wef = (WeaponConfExtraFields*)cachedWeaponExtras[targetID];
            } else {
                for (auto extra : weaponExtraInstance) {
                    if (!extra) continue;
                    WeaponConfExtraFields* fields = (WeaponConfExtraFields*)((uintptr_t)extra + 0x10);
                    if (fields->ID == targetID) {
                        wef = fields;
                        cachedWeaponExtras[targetID] = (uintptr_t)fields;
                        break;
                    }
                }
            }
            if (wef) {
                std::string nameLower = ToLower(getitem.itemName);
                if (nameLower.find("[mythic]") != std::string::npos || nameLower.find("[m]") != std::string::npos) {
                    wef->DefaultMythicArmor = getitem.WeaponExtra[1];
                    if (nameLower.find("eclipse phaser") == std::string::npos && 
                        nameLower.find("ice drake") == std::string::npos && 
                        nameLower.find("neon legend") == std::string::npos && 
                        nameLower.find("divine smite") == std::string::npos && 
                        nameLower.find("radiance") == std::string::npos && 
                        nameLower.find("demonsong") == std::string::npos && 
                        nameLower.find("amoeba") == std::string::npos && 
                        nameLower.find("morningstar") == std::string::npos && 
                        nameLower.find("nautilus") == std::string::npos && 
                        nameLower.find("dark frontier") == std::string::npos && 
                        nameLower.find("double edge") == std::string::npos && 
                        nameLower.find("artifact") == std::string::npos && 
						nameLower.find("Core of Reason") == std::string::npos && 
						nameLower.find("Core of Fire") == std::string::npos && 
						nameLower.find("Core of Thunder") == std::string::npos && 
                        nameLower.find("ascended") == std::string::npos) {
                        
                        wef->DefaultMythicSig = getitem.WeaponExtra[2];
                    }
                }
                wef->DefaultDeadReplayEffectId = getitem.WeaponExtra[3];
                wef->DefaultKillEffectId = getitem.WeaponExtra[4];
            }
        };

        patchWeaponExtra(baseID);
        patchWeaponExtra(extraID);
        patchWeaponExtra(skinID);
        patchWeaponExtra(itemID);
        patchWeaponExtra(lootID);

        for (auto asset : weaponAssetGroupInstance) {
            if (!asset) continue;
            WeaponAssetGroupFields* weaponAssetFields = (WeaponAssetGroupFields*)((uintptr_t)asset + 0x40);
            if (weaponAssetFields->Id == getitem.WeaponAsset[0]) {
                if (getitem.WeaponAsset[1] / 10 == getitem.WeaponAsset[2] / 10 && getitem.WeaponAsset[1] > 0) {
                    weaponAssetFields->FireEffectGroupID = getitem.WeaponAsset[1];
                }
            }
        }

        auto patchItemResource = [&](int targetID) {
            if (targetID <= 0) return;
            ItemResourceFields* irf = nullptr;
            if (cachedItemResources.find(targetID) != cachedItemResources.end()) {
                irf = (ItemResourceFields*)cachedItemResources[targetID];
            } else {
                for (auto itemResource : itemResourceConfigInstance) {
                    if (!itemResource) continue;
                    ItemResourceFields* fields = (ItemResourceFields*)((uintptr_t)itemResource + 0x10);
                    if (fields->ID == targetID) {
                        irf = fields;
                        cachedItemResources[targetID] = (uintptr_t)fields;
                        break;
                    }
                }
            }
            if (irf) {
                irf->FxAssetID = getitem.ItemResInt[0];
                irf->InventoryModelID = getitem.ItemResInt[1];
                irf->ModelAssetIDRaw = getitem.ItemResInt[2];
                irf->UIMiniSpriteName = getitem.ItemRes[0];
                irf->UISmallSpriteName = getitem.ItemRes[1];
                irf->UISpriteName = getitem.ItemRes[2];
                irf->UISquareSpriteName = getitem.ItemRes[3];
            }
        };

        patchItemResource(skinID);
        patchItemResource(itemID);
        patchItemResource(lootID);
        patchItemResource(extraID);
        patchItemResource(baseID);

        int fireEffectID = 0;
        for (auto asset : weaponAssetGroupInstance) {
            if (!asset) continue;
            WeaponAssetGroupFields* weaponAssetFields = (WeaponAssetGroupFields*)((uintptr_t)asset + 0x40);
            if (weaponAssetFields->Id == getitem.WeaponAsset[0]) {
                fireEffectID = weaponAssetFields->FireEffectGroupID;
                break;
            }
        }

        if (fireEffectID > 0) {
            for (auto fireConf : weaponFireEffectInstance) {
                if (!fireConf) continue;
                WeaponFireEffectFields* wfFields = (WeaponFireEffectFields*)((uintptr_t)fireConf + 0x10);
                if (wfFields->Id == fireEffectID) {
                    wfFields->LevelEffectDelayTimeUI = 0.1f;
                    wfFields->LevelEffectDelayTimeUI_King = 0.1f;
                    auto* killCountArray = *(Array<int>**)((uintptr_t)fireConf + 0x118);
                    if (killCountArray && Tools::IsPtrValid(killCountArray)) {
                        for (int k = 0; k < killCountArray->getLength(); ++k) killCountArray->m_Items[k] = 0;
                    }
                    auto* killCountArrayKing = *(Array<int>**)((uintptr_t)fireConf + 0x120);
                    if (killCountArrayKing && Tools::IsPtrValid(killCountArrayKing)) {
                        for (int k = 0; k < killCountArrayKing->getLength(); ++k) killCountArrayKing->m_Items[k] = 0;
                    }
                    break;
                }
            }
        }
    }

    if (executeWatchIdx != -1) {
        const auto& forwatch = watch[executeWatchIdx];
        int selectedTraitor1P = g_targetCharacters[g_selectedTargetCharIndex].name == "Charly" ? 710001101 : g_targetCharacters[g_selectedTargetCharIndex].traitor1p;
        
        if (cachedCharacterModels.find(selectedTraitor1P) != cachedCharacterModels.end()) {
            ((CharacterModelFields*)cachedCharacterModels[selectedTraitor1P])->BindEffect1P = forwatch.watchvalue;
        } else {
            for (auto charModel : CharacterModelConfigInstance) {
                if (!charModel) continue;
                CharacterModelFields* characterfields = (CharacterModelFields*)((uintptr_t)charModel + 0x10);
                if (characterfields->Traitor1P == selectedTraitor1P) {
                    characterfields->BindEffect1P = forwatch.watchvalue;
                    cachedCharacterModels[selectedTraitor1P] = (uintptr_t)characterfields;
                    break;
                }
            }
        }
    }

    if (executeDeadboxIdx != -1) {
        const auto& deadx = deadboxF[executeDeadboxIdx];
        BRDeadboxSkinFields* deadboxFields = nullptr;
        if (cachedDeadboxSkin != 0) {
            deadboxFields = (BRDeadboxSkinFields*)cachedDeadboxSkin;
            deadboxFields->ColorID = deadx.dead[0];
            deadboxFields->DeadBoxEffectAsset = deadx.dead[1];
            deadboxFields->Flag = deadx.dead[2];
            deadboxFields->FlagAsset = deadx.dead[3];
            deadboxFields->ModelAsset3P = deadx.dead[4];
            deadboxFields->ModelAssetUI = deadx.dead[5];
        } else {
            for (auto deadID : BRDeadboxSkinConfigInstance) {
                if (!deadID) continue;
                deadboxFields = (BRDeadboxSkinFields*)((uintptr_t)deadID + 0x10);
                if (deadboxFields->ID == 180300004) {
                    deadboxFields->ColorID = deadx.dead[0];
                    deadboxFields->DeadBoxEffectAsset = deadx.dead[1];
                    deadboxFields->Flag = deadx.dead[2];
                    deadboxFields->FlagAsset = deadx.dead[3];
                    deadboxFields->ModelAsset3P = deadx.dead[4];
                    deadboxFields->ModelAssetUI = deadx.dead[5];
                    cachedDeadboxSkin = (uintptr_t)deadboxFields;
                    break;
                }
            }
        }
    }

    if (executePlaneIdx != -1) {
        const auto& planex = dropplane[executePlaneIdx];
        BRDropPlaneSkinFields* dropplaneFields = nullptr;
        if (cachedPlaneSkin != 0) {
            dropplaneFields = (BRDropPlaneSkinFields*)cachedPlaneSkin;
            dropplaneFields->ColorID = planex.plane[0];
            dropplaneFields->ModelAsset1P = planex.plane[1];
            dropplaneFields->ModelAsset3P = planex.plane[2];
            dropplaneFields->ModelAssetCutScene = planex.plane[3];
            dropplaneFields->ModelAssetUI = planex.plane[4];
            dropplaneFields->Priority = planex.plane[5];
        } else {
            for (auto planeID : BRDropPlaneSkinConfigInstance) {
                if (!planeID) continue;
                dropplaneFields = (BRDropPlaneSkinFields*)((uintptr_t)planeID + 0x10);
                if (dropplaneFields->ID == 0) {
                    dropplaneFields->ColorID = planex.plane[0];
                    dropplaneFields->ModelAsset1P = planex.plane[1];
                    dropplaneFields->ModelAsset3P = planex.plane[2];
                    dropplaneFields->ModelAssetCutScene = planex.plane[3];
                    dropplaneFields->ModelAssetUI = planex.plane[4];
                    dropplaneFields->Priority = planex.plane[5];
                    cachedPlaneSkin = (uintptr_t)dropplaneFields;
                    break;
                }
            }
        }
    }

    if (showKeyboardWindow) {
        ImGuiIO& io = ImGui::GetIO();
        float kbHeight = io.DisplaySize.y * 0.47f; 
        
        ImGui::SetNextWindowPos(ImVec2(0, io.DisplaySize.y - kbHeight));
        ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x, kbHeight));
        
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.08f, 0.95f)); 
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 10));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);

        if (ImGui::Begin("Virtual Keyboard Full", &showKeyboardWindow, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar)) {
            g_VirtualKeyboard.SetTarget((char*)g_SkinSearch.GetSearchQuery(), 256);
            g_VirtualKeyboard.Render(&showKeyboardWindow); 
        }
        ImGui::End();

        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor();
    }

    ImGui::EndChild();
                    ImGui::PopStyleVar(3);
                    ImGui::PopStyleColor(2);
                }

static bool camoOff = true;
static bool camoDiamond = false;
static bool camoRedSprite = false;

if (tab == 6) {
    const float totalWidth = ImGui::GetContentRegionAvail().x;
    const float spacing = 10.0f;
    const float panelWidth = (totalWidth - spacing) * 0.5f; 
    const float childHeight = ImGui::GetContentRegionAvail().y;

    static float rgb_timer = 0.0f;
    rgb_timer += ImGui::GetIO().DeltaTime * 0.5f;
    ImVec4 rgb_color = ImVec4(
        (sinf(rgb_timer) * 0.5f + 0.5f),
        (sinf(rgb_timer + 2.0f) * 0.5f + 0.5f),
        (sinf(rgb_timer + 4.0f) * 0.5f + 0.5f),
        1.0f
    );

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Settings Nav##7", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Configuration");
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Logo Size");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 45.0f);
            ImGui::TextDisabled("%.0f%%", ((logoSize - 30.0f) / 120.0f) * 100.0f);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##Size", &logoSize, 30.0f, 150.0f);

            ImGui::Spacing();

            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.8f, 0.8f, 1.0f));
            ImGui::Text("Logo Opacity");
            ImGui::PopStyleColor();
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - 45.0f);
            ImGui::TextDisabled("%.0f%%", logoOpacitySlider);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 5.0f);
            RenderStyledSlider("##Opacity", &logoOpacitySlider, 0.0f, 100.0f);
        }
        ImGui::EndChild();

        ImGui::BeginChild("Menu Controls Child", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Menu Controls");
            ImGui::Separator();
            ImGui::Spacing();

            static bool saveTrigger = false;
            RenderStyledToggle("Save Features", &saveTrigger);
            if (saveTrigger) {
                saveAllConfig();
                saveTrigger = false; 
            }
            ImGui::Spacing();

            static bool loadTrigger = false;
            RenderStyledToggle("Load Features", &loadTrigger);
            if (loadTrigger) {
                if (loadAllConfig()) ImGui::OpenPopup("Config Loaded");
                else ImGui::OpenPopup("Config Error");
                loadTrigger = false;
            }
            ImGui::Spacing();

            static bool tempHideTrigger = false;
            RenderStyledToggle(tempHideTrigger ? "Show Menu" : "Hide Menu", &tempHideTrigger);
            if (tempHideTrigger) {
                forceHideLogo = true;
                isMenuVisible = false;
                tempHideTrigger = false; 
            }
            ImGui::Spacing();

            RenderStyledToggle(Config.ExtraMenu.ClearDisplay ? "Show Info" : "Hide Info", &Config.ExtraMenu.ClearDisplay);
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();

    ImGui::SameLine(0, spacing);

    ImGui::BeginGroup();
    {
        ImGui::BeginChild("Settings Content##7", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "CLOWN Price");
            ImGui::Separator();
            ImGui::Spacing();

            if (ImGui::BeginTable("Price List", 2, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg)) {
                ImGui::TableSetupColumn("Plan", ImGuiTableColumnFlags_WidthFixed, 80.0f);
                ImGui::TableSetupColumn("Price (PHP)", ImGuiTableColumnFlags_WidthStretch);
                ImGui::TableHeadersRow();

                const char* plans[] = { "3 Days", "7 Days", "15 Days", "Lifetime" };
                const char* prices[] = { "100", "150", "200", "400" };

                for (int i = 0; i < 4; i++) {
                    ImGui::TableNextRow();
                    ImGui::TableSetColumnIndex(0); ImGui::Text("%s", plans[i]);
                    ImGui::TableSetColumnIndex(1); ImGui::TextColored(ImVec4(0.12f, 1.0f, 0.32f, 1.0f), "%s PHP", prices[i]);
                }
                ImGui::EndTable();
            }
        }
        ImGui::EndChild();

        ImGui::BeginChild("Weapon Visuals Child", ImVec2(panelWidth, (childHeight * 0.50f) - (spacing / 2)), true);
        {
            ImGui::TextColored(rgb_color, "Weapon Visuals");
            ImGui::Separator();
            ImGui::Spacing();

            RenderStyledToggle(Config.ExtraMenu.Blueprints ? "Unlocked Blueprint" : "Unlock Blueprint", &Config.ExtraMenu.Blueprints);
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            static int selectedCamo = 0;
            
            if (ImGui::RadioButton("Off Camo", selectedCamo == 0)) {
                selectedCamo = 0;
                camoOff = true; camoDiamond = false; camoRedSprite = false;
            }
            ImGui::Spacing();
            
            if (ImGui::RadioButton("Diamond Camo", selectedCamo == 1)) {
                selectedCamo = 1;
                camoOff = false; camoDiamond = true; camoRedSprite = false;
                for (const auto& getitem : itemData) {
                    if (getitem.itemName.find("[M]") != std::string::npos || getitem.itemName.find("[L]") != std::string::npos) {
                        for (auto conf : weaponConfInstance) {
                            if (!conf) continue;
                            weaponconfFields = (WeaponConfFields*)((uintptr_t)conf + 0x20);
                            if (weaponconfFields->ID == getitem.WeaponConf[2]) weaponconfFields->DefWeaponSkinID = 0x1D37F758;
                        }
                    }
                }
            }
            ImGui::Spacing();
            
            if (ImGui::RadioButton("Red Sprite", selectedCamo == 2)) {
                selectedCamo = 2;
                camoOff = false; camoDiamond = false; camoRedSprite = true;
                for (const auto& getitem : itemData) {
                    if (getitem.itemName.find("[M]") != std::string::npos || getitem.itemName.find("[L]") != std::string::npos) {
                        for (auto conf : weaponConfInstance) {
                            if (!conf) continue;
                            weaponconfFields = (WeaponConfFields*)((uintptr_t)conf + 0x20);
                            if (weaponconfFields->ID == getitem.WeaponConf[2]) weaponconfFields->DefWeaponSkinID = 0x1D37F77E;
                        }
                    }
                }
            }
        }
        ImGui::EndChild();
    }
    ImGui::EndGroup();

    static bool enableAutoBestSkinAll = false;
    static bool autoDone = false;

    ImDrawList* dl4 = ImGui::GetWindowDrawList();
    float iW = ImGui::GetContentRegionAvail().x;
    ImVec2 cardMin = ImGui::GetCursorScreenPos();
    float cardH_est = 175.0f;

    dl4->AddRectFilled(cardMin,
                       { cardMin.x + iW, cardMin.y + cardH_est },
                       IM_COL32(20, 17, 8, 255), 8.0f);
    dl4->AddRect(cardMin,
                 { cardMin.x + iW, cardMin.y + cardH_est },
                 IM_COL32(200, 150, 10, 100), 8.0f, 0, 1.5f);
    dl4->AddRectFilled(cardMin,
                       { cardMin.x + iW, cardMin.y + 3.0f },
                       IM_COL32(200, 150, 10, 120), 8.0f);
    ImGui::Dummy({ iW, 0 });

    ImGui::SetCursorScreenPos({ cardMin.x + 1, cardMin.y + 1 });
    ImGui::TextColored(ImVec4(1.0f, 0.8f, 0.0f, 1.0f), "ONE CLICK BEST SKIN");

    ImGui::SetCursorPosX(8.0f);
    {
        float bW = iW - 16.0f, bH = 48.0f;
        ImVec2 bPos = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##bigapply", { bW, bH });
        bool bHov = ImGui::IsItemHovered();
        bool bAct = ImGui::IsItemActive();
        bool bClk = ImGui::IsItemClicked();

        ImU32 btnFill = bAct ? IM_COL32(130, 95, 5, 255)
                     : bHov ? IM_COL32(200, 145, 10, 255)
                            : IM_COL32(160, 110, 8, 220);
        dl4->AddRectFilled(bPos, { bPos.x + bW, bPos.y + bH }, IM_COL32(10, 8, 2, 255), 6.0f);
        dl4->AddRectFilled(bPos, { bPos.x + bW, bPos.y + bH }, btnFill, 6.0f);
        dl4->AddRect(bPos, { bPos.x + bW, bPos.y + bH },
                     bHov ? IM_COL32(255, 200, 50, 255) : IM_COL32(200, 150, 10, 100), 6.0f, 0, 1.8f);

        const char* btnTxt = "APPLY BEST SKIN + KILL EFFECTS  —  ALL GUNS";
        ImVec2 btSz = ImGui::CalcTextSize(btnTxt);
        dl4->AddText({ bPos.x + (bW - btSz.x) * 0.5f,
                       bPos.y + (bH - btSz.y) * 0.5f },
                     IM_COL32(255, 240, 180, 255), btnTxt);

        if (bClk) ApplyBestSkinToAllWeapons();
    }

        ImGui::Checkbox("VSync Mode", &Config.ExtraMenu.Grap);
        if (ImGui::Checkbox("Frame Smoothness", &Config.Aim.FpsLevel)) {
            Config.Aim.showFPSLevelSlider = Config.Aim.FpsLevel;
        }
        if (Config.Aim.showFPSLevelSlider) {
            ImGui::SliderFloat("Frame Level", &Config.Aim.FpsLevel1, 30, 120, "%.0f");
        }
        ImGui::Separator();
        if (ImGui::Checkbox("Ultra Frame Boost", &Config.Aim.FpsLevelUltra)) {
            Config.Aim.showFPSLevelUltraSlider = Config.Aim.FpsLevelUltra;
        }
        if (Config.Aim.showFPSLevelUltraSlider) {
            ImGui::SliderFloat("Ultra Frame Level", &Config.Aim.FpsLevelUltra1, 60, 144, "%.0f");
        }
    ImGui::Spacing();

    ImGui::SetCursorPosX(10.0f);
    RenderStyledToggle("Auto Apply Best Skin On Load", &enableAutoBestSkinAll);

    if (enableAutoBestSkinAll) {
        if (!bestSkinForWeapon.empty() && !autoDone) {
            ApplyBestSkinToAllWeapons();
            autoDone = true;
        }
    } else {
        autoDone = false;
    }

    ImGui::Spacing();

    ImGui::SetCursorPosX(8.0f);
    if (bestSkinForWeapon.empty()) {
        ImGui::TextColored(ImVec4(1.0f, 0.6f, 0.0f, 1.0f), "! Open SKINHACKS tab first to load skins");
    } else {
        char rdy[64];
        snprintf(rdy, sizeof(rdy), ">>  %d weapons ready  —  tap APPLY above", (int)bestSkinForWeapon.size());
        ImGui::TextColored(ImVec4(0.18f, 1.0f, 0.38f, 1.0f), "%s", rdy);
    }
    ImGui::Dummy({0, 6});

    if (ImGui::BeginPopupModal("Config Loaded", NULL, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Settings loaded successfully!");
        if (ImGui::Button("OK")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}




ImGui::End();
ImGui::PopStyleVar(2);
ImGui::PopStyleColor();
}
}
}

            if (Config.ExtraMenu.Range) {
                Patches.range.Modify();
            }
            else
            {
                Patches.range.Restore();
            }

            if (Config.ExtraMenu.Kinetic) {
                Patches.kinetic.Modify();
            }
            else
            {
                Patches.kinetic.Restore();
            }

            if (Config.ExtraMenu.Outline) {
                Patches.outline.Modify();
            }
            else
            {
                Patches.outline.Restore();
            }

            if (Config.ExtraMenu.Fps) {
                Patches.fpss.Modify();
            }
            else
            {
                Patches.fpss.Restore();
            }
			
			if (Config.ExtraMenu.Frame) {
                Patches.frame.Modify();
            }
            else
            {
                Patches.frame.Restore();
            }

            if (Config.ExtraMenu.Rpd) {
                Patches.rpd.Modify();
            }
            else
            {
                Patches.rpd.Restore();
            }

            if (Config.ExtraMenu.Grapss) {
                Patches.grap.Modify();
            }
            else
            {
                Patches.grap.Restore();
            }

            if (Config.ExtraMenu.WallHack) {
                Patches.A1.Modify();
            }
            else
            {
                Patches.A1.Restore();
            }

            if (Config.ExtraMenu.Parachute) {
                Patches.chute.Modify();
            }
            else
            {
                Patches.chute.Restore();
            }


            if (Config.ExtraMenu.AutoSnipe) {
                Patches.autosnipe.Modify();
            }
            else
            {
                Patches.autosnipe.Restore();
            }
			
			if (Config.ExtraMenu.Revive) {
                Patches.revive.Modify();
            }
            else
            {
                Patches.revive.Restore();
            }

            if (Config.ExtraMenu.Diving) {
                Patches.wing.Modify();
            }
            else
            {
                Patches.wing.Restore();
            }
            if (Config.ExtraMenu.Tutorial) {
                Patches.tutorial.Modify();
            }
            else
            {
                Patches.tutorial.Restore();
            }
            if (Config.ExtraMenu.Cost) {
                Patches.cost.Modify();
            }
            else
            {
                Patches.cost.Restore();
            }
            if (Config.ExtraMenu.Red) {
                Patches.red.Modify();
            }
            else
            {
                Patches.red.Restore();
            }
            if (Config.ExtraMenu.JetS) {
                Patches.jets.Modify();
            }
            else
            {
                Patches.jets.Restore();
            }
            if (Config.ExtraMenu.JetJ) {
                Patches.jetj.Modify();
            }
            else
            {
                Patches.jetj.Restore();
            }
        }
    }

    auto Input_get_touchCount = (int (*)())(Class_Input_get_touchCount);
if (Input_get_touchCount() > 0)
{
    auto Input_GetTouch = (Touch(*)(uintptr_t, int))(Class_Input_GetTouch);
    auto Input_get_mousePosition = (Vector3(*)(uintptr_t))(Class_Input_get_mousePosition);

    Touch t = Input_GetTouch(Config.ImGuiMenu.thiz, 0);
    Vector3 mp = Input_get_mousePosition(Config.ImGuiMenu.thiz);

    // 1.6.57 safe: cache once, use everywhere
    float mx = mp.x;
    float my = (float)get_height() - mp.y;

    switch (t.m_Phase)
    {
    case TouchPhase::Began:
    case TouchPhase::Stationary:
        io->MouseDown[0] = true;
        io->MousePos     = ImVec2(mx, my);
        break;

    case TouchPhase::Moved:
        io->MouseDown[0] = true;
        io->MousePos     = ImVec2(mx, my);
        break;

    case TouchPhase::Ended:
    case TouchPhase::Canceled:
        io->MouseDown[0]             = false;
        Config.ImGuiMenu.clearMousePos = true;
        break;

    default:
        break;
    }
}
else
{
    // No fingers down — guarantee clean state
    if (Config.ImGuiMenu.clearMousePos)
    {
        io->MousePos               = ImVec2(-FLT_MAX, -FLT_MAX);
        Config.ImGuiMenu.clearMousePos = false;
    }
    io->MouseDown[0] = false;
}

    ImGui::EndFrame();
    ImGui::Render();
    
     if (g_HideFromRecord) {
        EGLContext gameCtx = eglGetCurrentContext();
        bool ok = ZEL_Render(
            ImGui::GetDrawData(),
            dpy,
            surface,
            gameCtx,
            (android::HideRecAImGui::SwapBuffersFn)old_eglSwapBuffers);
        if (!ok) {
            // surface failed para bumalik ui
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        }
    } else {
        ZEL_Shutdown();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    }
    return old_eglSwapBuffers(dpy, surface);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    feedback::PumpAfterRender();

    return old_eglSwapBuffers(dpy, surface);
}

void Notario_Thread() {
    while (!m_Anogs) {
        m_Anogs = Tools::GetBaseAddress("libanogs.so");
        sleep(1);
    }
/* ===== DIRECT MEMORY PATCH ===== */
MemoryPatch::createWithHex("libanogs.so", 0x501210, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x37B5A8, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x204218, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x497244, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x455A80, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x48CF20, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x202680, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x438154, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x35140C, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x44A714, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x44BC90, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x39AE94, "00 00 80 D2 C0 03 5F D6").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3893D8, "00 00 80 D2 C0 03 5F D6").Modify();

    
    while (!m_unity) {
        m_unity = Tools::GetBaseAddress("libunity.so");
        sleep(1);
    }

    sleep(2);
    std::thread(BackgroundSaveThread).detach();
    std::thread(Skins_Thread).detach();
    sleep(15);
    NotaFeats();

    LoadFavoritesFromFile();

    auto swapBuffers = ((uintptr_t) DobbySymbolResolver(OBFUSCATE("libunity.so"), OBFUSCATE("eglSwapBuffers")));
    KittyMemory::ProtectAddr((void *)swapBuffers, sizeof(swapBuffers), PROT_READ | PROT_WRITE | PROT_EXEC);
    DobbyHook((void *) swapBuffers, (void *) hook_eglSwapBuffers, (void **) &old_eglSwapBuffers);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved)
{
    jvm = vm;
    VM = vm;
    ZEL_SetVM(vm);

    std::thread(Notario_Thread).detach();
    
    char cmd[256] = {};
    FILE* f = fopen("/proc/self/cmdline", "r");

    if (f)
    {
        fread(cmd, 1, sizeof(cmd) - 1, f);
        fclose(f);
    }

    return JNI_VERSION_1_6;
}
