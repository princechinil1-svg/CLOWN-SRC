#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCDFAInspection"
#pragma once

static ESP *m_Canvas = 0;
#include <malloc.h>
#include <errno.h>
#include <stdarg.h>
#include <array>
#include "FTools/Iconcpp.h"
#include "FTools/Font.h"
#include "FTools/Icon.h"
#include "../XPremium/Skeleton.h"

#ifndef IM_PI
#define IM_PI 3.14159265358979323846f
#endif

#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )

extern ImFont* F50;

void (*oWeaponFireComponent_Instant_CreateBulletLine)(uintptr_t thiz, Vector3 startPos, Vector3 dir, bool isDualFire) = nullptr;
void (*oWeaponFireComponent_Instant_CreateBulletProjectile)(void* thiz, Vector3 startPos, Vector3 dir, void* weaponImpact, int itemID, int flySmokeAssetID, bool enableVirtualStartPos, Vector3 virtualStartPos) = nullptr;

void RotateTriangle(std::array<Vector3, 3> & points, float rotation) {
    const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
    const auto theta = DEG2RAD(rotation);
    const auto c = cosf(theta);
    const auto s = sinf(theta);
    for (auto & point : points) {
        point = point - points_center;
        const auto temp_x = point.x;
        const auto temp_y = point.y;
        point.x = temp_x * c - temp_y * s;
        point.y = temp_x * s + temp_y * c;
        point = point + points_center;
    }
}

void VectorAnglesRadar(Vector3 & forward, Vector3 & angles) {
    if (forward.x == 0.f && forward.y == 0.f) {
        angles.x = forward.z > 0.f ? -90.f : 90.f;
        angles.y = 0.f;
    } else {
        angles.x = RAD2DEG(atan2(-forward.z, forward.Magnitude(forward)));
        angles.y = RAD2DEG(atan2(forward.y, forward.x));
    }
    angles.z = 0.f;
}

char extra[30];
int atas, kanan;

int32_t ToColor(float *col) {
    return ImGui::ColorConvertFloat4ToU32(*(ImVec4 *) (col));
}
int totalBots, totalEnemies;
bool isEspReady;

uintptr_t GetClosestTarget() {
    uintptr_t result = 0;
    float MaxDist = std::numeric_limits<float>::infinity();

    auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay_get_MatchGame);
    auto get_MatchGame = Gameplay_get_MatchGame();
    if (Tools::IsPtrValid((void *) get_MatchGame)) {
        auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay_get_LocalPawn);
        auto LocalPawn = Gameplay_get_LocalPawn();
        if (LocalPawn) {
            Vector3 MyPos{0, 0, 0};
            auto local_m_Mesh = *(Transform **) (LocalPawn + Class_Pawn_m_Mesh);
            if (local_m_Mesh) {
                MyPos = local_m_Mesh->get_position();
            }

            auto EnemyPawns = *(List<uintptr_t> **) (get_MatchGame + Class_BaseGame_EnemyPawns);
            if (EnemyPawns) {
                auto Items = EnemyPawns->getItems();
                if (Items) {
                    int size = EnemyPawns->getSize();
                    for (int i = 0; i < size; i++) {
                        auto Pawn = Items[i];
                        if (Pawn) {
                            if (!*(bool *) (Pawn + Class_Pawn_m_IsAlive))
                                continue;

                            auto m_Mesh = *(Transform **) (Pawn + Class_Pawn_m_Mesh);
                            if (!m_Mesh)
                                continue;

                            auto RootPos = m_Mesh->get_position();
                            float Distance = Vector3::Distance(MyPos, RootPos);

                            if (Distance < MaxDist) {
                                result = Pawn;
                                MaxDist = Distance;
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

bool isInsideFOV(int x, int y) {
    if (!Config.Aim.size)
        return true;

    int circle_x = get_width() / 2;
    int circle_y = get_height() / 2;
    int rad = Config.Aim.size;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

uintptr_t GetInsideFOVTarget() {
    uintptr_t result = 0;
    float MaxDist = std::numeric_limits<float>::infinity();

    auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay_get_MatchGame);
    auto get_MatchGame = Gameplay_get_MatchGame();
    if (Tools::IsPtrValid((void *) get_MatchGame)) {
        auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay_get_LocalPawn);
        auto LocalPawn = Gameplay_get_LocalPawn();
        if (LocalPawn) {
            auto mainCamera = Camera::get_main();
            if (!mainCamera) return 0;

            auto EnemyPawns = *(List<uintptr_t> **) (get_MatchGame + Class_BaseGame_EnemyPawns);
            if (EnemyPawns) {
                auto Items = EnemyPawns->getItems();
                if (Items) {
                    int size = EnemyPawns->getSize();
                    int midX = get_width() / 2;
                    int midY = get_height() / 2;
                    Vector2 v2Middle = Vector2((float)midX, (float)midY);

                    for (int i = 0; i < size; i++) {
                        auto Pawn = Items[i];
                        if (Pawn) {
                            auto isAlive = *(bool*) ((uintptr_t)Pawn + Class_Pawn_m_IsAlive);
                            if (!isAlive)
                                continue;

                            auto m_HeadBone = *(Transform **) (Pawn + Class_Pawn_m_HeadBone);
                            if (!m_HeadBone)
                                continue;

                            auto HeadSc = mainCamera->WorldToScreenPoint(m_HeadBone->get_position());
                            if (HeadSc.z <= 0) continue;

                            if (isInsideFOV((int) HeadSc.x, (int) HeadSc.y)) {
                                Vector2 v2Loc = Vector2(HeadSc.x, HeadSc.y);
                                float Distance = Vector2::Distance(v2Middle, v2Loc);

                                if (Distance < MaxDist) {
                                    result = Pawn;
                                    MaxDist = Distance;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return result;
}

void DrawAimLine(ImDrawList* draw, int sWidth, int sHeight) {
    uintptr_t Target = 0;
    if (Config.Aim.By == EAim::Distance) {
        Target = GetClosestTarget();
    } else if (Config.Aim.By == EAim::Crosshair) {
        Target = GetInsideFOVTarget();
    }

    if (Target) {
        auto m_HeadBone = *(Transform**)(Target + Class_Pawn_m_HeadBone);
        if (!m_HeadBone) return;

        Vector3 targetPos = m_HeadBone->get_position();
        if (Config.Aim.Target == EAimTarget::Chests) {
            targetPos.y -= 0.2f;
        } else if (Config.Aim.Target == EAimTarget::Body) {
            targetPos.y -= 0.4f;
        }

        auto mainCamera = Camera::get_main();
        if (mainCamera) {
            Vector3 HeadSc = mainCamera->WorldToScreenPoint(targetPos);
            if (HeadSc.z > 0) {
                ImVec2 center(sWidth / 2, sHeight / 2);
                draw->AddLine(center, ImVec2(HeadSc.x, sHeight - HeadSc.y), ToColor(Config.sColorsESPPLAYER.LinePLAYER), Config.sESPMenuLineScale.lineSize);
            }
        }
    }
}

ImVec2 pushToScreenBorder(ImVec2 Pos, ImVec2 screen, int borders, int offset) {
    float x = Pos.x;
    float y = Pos.y;
    if ((borders & 1) == 1) y = 0 - offset;
    if ((borders & 2) == 2) x = screen.x + offset;
    if ((borders & 4) == 4) y = screen.y + offset;
    if ((borders & 8) == 8) x = 0 - offset;
    return ImVec2(x, y);
}

int isOutsideSafezone(ImVec2 pos, ImVec2 screen) {
    ImVec2 mSafezoneTopLeft(screen.x * 0.04f, screen.y * 0.04f);
    ImVec2 mSafezoneBottomRight(screen.x * 0.96f, screen.y * 0.96f);
    int result = 0;
    if (pos.y < mSafezoneTopLeft.y) result |= 1;
    if (pos.x > mSafezoneBottomRight.x) result |= 2;
    if (pos.y > mSafezoneBottomRight.y) result |= 4;
    if (pos.x < mSafezoneTopLeft.x) result |= 8;
    return result;
}

class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;
public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {}
    void update() {
        m_fpscount++;
        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;
            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }
    unsigned int get() const { return m_fps; }
};
FPSCounter fps;

void DrawBoxEnemy(ImDrawList *draw, ImVec2 X, ImVec2 Y, float thicc, int color) {
    draw->AddLine({X.x, X.y}, {Y.x, Y.y}, color, thicc);
}

void TeleportToEnemy() {
    if (!Config.TeleportEnemy) return;
    
    BaseGame *get_MatchGame = GamePlay::get_MatchGame();
    if (!Tools::IsPtrValid(get_MatchGame)) return;
    
    Pawn *get_LocalPawn = GamePlay::get_LocalPawn();
    if (!Tools::IsPtrValid(get_LocalPawn)) return;
    
    Vector3 localPos = get_LocalPawn->get_LastPawnPos();
    
    List<Pawn *> *EnemyPawns = get_MatchGame->EnemyPawns();
    if (!Tools::IsPtrValid(EnemyPawns) || !EnemyPawns->getSize()) return;
    
    Pawn *closestEnemy = nullptr;
    float minDistance = 100.0f;
    
    Pawn **pawns = (Pawn **)EnemyPawns->getItems();
    int size = EnemyPawns->getSize();
    for (int i = 0; i < size; i++) {
        Pawn *pawn = pawns[i];
        if (!Tools::IsPtrValid(pawn)) continue;
        
        bool isAlive = *(bool *)((uintptr_t)pawn + Class_Pawn_m_IsAlive);
        if (!isAlive) continue;
        
        Vector3 enemyPos = pawn->get_LastPawnPos();
        float distance = Vector3::Distance(localPos, enemyPos) / 70.0f;
        
        if (distance < minDistance) {
            minDistance = distance;
            closestEnemy = pawn;
        }
    }
    
    if (closestEnemy) {
        Vector3 targetPos = closestEnemy->get_LastPawnPos();
        Vector3 direction = localPos - targetPos;
        direction.y = 0;
        direction = direction.Normalize();
        
        Vector3 teleportPos = targetPos + (direction * 1.5f);
        
        Transform *localTransform = *(Transform **)((uintptr_t)get_LocalPawn + Class_Pawn_m_Mesh);
        if (Tools::IsPtrValid(localTransform)) {
            auto _Transform_set_position = (void (*)(Transform *, Vector3))(Class_Transform_set_position);
            if (_Transform_set_position) {
                _Transform_set_position(localTransform, teleportPos);
            }
        }
    }
}

void DrawESP(ImDrawList *draw, int sWidth, int sHeight, float density) {
    BaseGame *get_MatchGame = GamePlay::get_MatchGame();
    if (!Tools::IsPtrValid(get_MatchGame)) return;

    Vector3 pLocalPawn_rootPos = Vector3::zero();
    Pawn *get_LocalPawn = GamePlay::get_LocalPawn();
    if (Tools::IsPtrValid(get_LocalPawn)) {
        pLocalPawn_rootPos = get_LocalPawn->get_LastPawnPos();
    }
    

    int renderedCount = 0;
    int MAX_RENDER = 10; 
    totalBots = 0;
    totalEnemies = 0;

    List<Pawn *> *EnemyPawns = get_MatchGame->EnemyPawns();
    if (!Tools::IsPtrValid(EnemyPawns) || !EnemyPawns->getSize()) return;

    auto mainCamera = Camera::get_main();
    if (!mainCamera) return;

    Pawn **pawns = (Pawn **)EnemyPawns->getItems();
    int pawnCount = EnemyPawns->getSize();

    std::vector<bool> alreadyRendered(pawnCount, false);

    auto DoRender = [&](Pawn* pawn, float distanceToMe, int index) {
        if (!Tools::IsPtrValid(pawn)) return;
        bool isBot = *(bool *)((uintptr_t)pawn + Class_Pawn_m_IsBot);
        Vector3 HeadSc = mainCamera->WorldToScreenPoint(pawn->get_HeadPosition());
        Vector3 RootSc = mainCamera->WorldToScreenPoint(pawn->get_LastPawnPos());

        if (HeadSc.z > 0) {
            renderedCount++;
            alreadyRendered[index] = true;

            auto m_AttackableInfo = *(uintptr_t *)(pawn + Class_AttackableTarget_m_AttackableInfo);
            if (!Tools::IsPtrValid((void*)m_AttackableInfo)) return;
            int CurHP = (int)*(float *)(m_AttackableInfo + Class_AttackableTarget_m_Health);
            auto m_HeadBone = *(Transform **)(pawn + Class_Pawn_m_HeadBone);

            ImU32 color = isBot ? IM_COL32(0, 255, 0, 255) : IM_COL32(255, 0, 0, 255);
            float lThick = isBot ? Config.Bline : Config.Pline;
            float bThick = isBot ? Config.Bbox : Config.Pbox;
            float sThick = isBot ? Config.BskelLine : Config.PskelLine;

            if (Config.ESPMenu.Alert) {
                Vector3 angle = Vector3();
                Vector3 forward = Vector3((float)(sWidth / 2) - HeadSc.x, (float)(sHeight / 2) - (sHeight - HeadSc.y), 0.0f);
                VectorAnglesRadar(forward, angle);
                const auto angle_rad = (angle.y + 180.f) * 3.1415926535f / 180.f;
                const auto nX = (sWidth / 2) + 220 * cosf(angle_rad);
                const auto nY = (sHeight / 2) + 220 * sinf(angle_rad);
                std::array<Vector3, 3> pts{ Vector3(nX-13, nY-8, 0), Vector3(nX+6, nY, 0), Vector3(nX-13, nY+8, 0) };
                RotateTriangle(pts, angle.y + 180.f);
                draw->AddTriangleFilled(ImVec2(pts[0].x, pts[0].y), ImVec2(pts[1].x, pts[1].y), ImVec2(pts[2].x, pts[2].y), color);
            }

            if (Config.ESPMenu.isPlayerLine) {
                ImVec2 start;
                if (Config.ESPMenu.Target == LineTarget::Top) start = ImVec2(sWidth/2, 80);
                else if (Config.ESPMenu.Target == LineTarget::Center) start = ImVec2(sWidth/2, sHeight/2);
                else start = ImVec2(sWidth/2, sHeight);
                draw->AddLine(start, ImVec2(HeadSc.x, sHeight - HeadSc.y), color, lThick);
            }

            if (Config.ESPMenu.Skeleton && distanceToMe < 60.0f) {
                auto m_Neck = *(Transform**)((uintptr_t)pawn + Class_Pawn_m_NeckBone);
                auto m_Spine = *(Transform**)((uintptr_t)pawn + Class_Pawn_m_SpineBone);
                auto m_Hips = *(Transform**)((uintptr_t)pawn + Class_Pawn_m_HipsBone);
                auto m_LAnkle = *(Transform**)((uintptr_t)pawn + Class_Pawn_m_LeftAnkleBone);
                auto m_RAnkle = *(Transform**)((uintptr_t)pawn + Class_Pawn_m_RightAnkleBone);
                auto m_LHand = *(Transform**)((uintptr_t)pawn + 0x7A8); 
                auto m_RHand = *(Transform**)((uintptr_t)pawn + 0x7A0); 

                if (m_HeadBone && m_Neck && m_Spine && m_Hips) {
                    Vector3 hP = m_HeadBone->get_position();
                    Vector3 nP = m_Neck->get_position();
                    Vector3 sP = m_Spine->get_position();
                    Vector3 hiP = m_Hips->get_position();

                    auto DrawBone = [&](Vector3 from, Vector3 to) {
                        Vector3 fS = mainCamera->WorldToScreenPoint(from);
                        Vector3 tS = mainCamera->WorldToScreenPoint(to);
                        if (fS.z > 0 && tS.z > 0) {
                            draw->AddLine(ImVec2(fS.x, sHeight - fS.y), ImVec2(tS.x, sHeight - tS.y), color, sThick);
                        }
                    };

                    Vector3 hS = mainCamera->WorldToScreenPoint(hP);
                    if (hS.z > 0) draw->AddCircle(ImVec2(hS.x, sHeight - hS.y), 5.0f, color, 12, sThick);
                    DrawBone(hP, nP); DrawBone(nP, sP); DrawBone(sP, hiP);
                    if (m_LHand) DrawBone(nP, m_LHand->get_position());
                    if (m_RHand) DrawBone(nP, m_RHand->get_position());

                    if (m_LAnkle && m_RAnkle) {
                        Vector3 lAnkP = m_LAnkle->get_position();
                        Vector3 rAnkP = m_RAnkle->get_position();
                        Vector3 lKnee = Vector3((lAnkP.x + hiP.x) * 0.5f, lAnkP.y + ((hiP.y - lAnkP.y) * 0.5f), (lAnkP.z + hiP.z) * 0.5f);
                        Vector3 rKnee = Vector3((rAnkP.x + hiP.x) * 0.5f, rAnkP.y + ((hiP.y - rAnkP.y) * 0.5f), (rAnkP.z + hiP.z) * 0.5f);
                        DrawBone(hiP, lKnee); DrawBone(lKnee, lAnkP); DrawBone(hiP, rKnee); DrawBone(rKnee, rAnkP);
                    }
                }
            }

            float bH = abs(HeadSc.y - RootSc.y);
            float bW = bH * 0.65f;
            float x = RootSc.x - (bW / 2);
            float y = sHeight - HeadSc.y; 

            if (Config.ESPMenu.Box) {
                float lW = bW * 0.25f; float lH = bH * 0.2f;
                ImVec2 corners[8][2] = {
                    {{x, y}, {x + lW, y}}, {{x, y}, {x, y + lH}},
                    {{x + bW, y}, {x + bW - lW, y}}, {{x + bW, y}, {x + bW, y + lH}},
                    {{x, y + bH}, {x + lW, y + bH}}, {{x, y + bH}, {x, y + bH - lH}},
                    {{x + bW, y + bH}, {x + bW - lW, y + bH}}, {{x + bW, y + bH}, {x + bW, y + bH - lH}}
                };
                for (auto& edge : corners) {
                    DrawBoxEnemy(draw, edge[0], edge[1], bThick + 1.5f, IM_COL32(0, 0, 0, 255));
                    DrawBoxEnemy(draw, edge[0], edge[1], bThick, color);
                }
            }

            if (Config.ESPMenu.Name || Config.ESPMenu.Distance || Config.ESPMenu.Health) {
                char dTxt[32]; 
                snprintf(dTxt, sizeof(dTxt), "%dm", (int)distanceToMe);
                
                const char* nameTxt = "Player";
                if (isBot) {
                    nameTxt = "Bot";
                } else if (pawn->get_PlayerName() && Tools::IsPtrValid(pawn->get_PlayerName())) {
                    nameTxt = pawn->get_PlayerName()->CString();
                }
                
                float padding = 8.0f;
                float iconSpace = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? 28.0f : 0.0f;
                ImVec2 nameSize = Config.ESPMenu.Name ? ImGui::CalcTextSize(nameTxt) : ImVec2(0,0);
                ImVec2 distSize = Config.ESPMenu.Distance ? ImGui::CalcTextSize(dTxt) : ImVec2(0,0);
                
                float boxW = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? (iconSpace + nameSize.x + distSize.x + (padding * 4)) : 65.0f;
                float boxH = (Config.ESPMenu.Name || Config.ESPMenu.Distance) ? 42.0f : 15.0f;
                float boxX = HeadSc.x - (boxW / 2.0f); float boxY = y - boxH - 10.0f; 

                draw->AddRectFilled(ImVec2(boxX, boxY), ImVec2(boxX + boxW, boxY + boxH), IM_COL32(15, 15, 15, 220), 6.0f);
                draw->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + boxW, boxY + boxH), IM_COL32(120, 120, 120, 255), 6.0f, 0, 1.5f);

                float currentX = boxX + padding;
                if (Config.ESPMenu.Name || Config.ESPMenu.Distance) {
                    float iX = currentX + 10.0f; float iY = boxY + 16.0f;
                    if (isBot) {
                        draw->AddLine(ImVec2(iX - 4, iY - 7), ImVec2(iX - 2, iY - 4), color, 1.2f);
                        draw->AddLine(ImVec2(iX + 4, iY - 7), ImVec2(iX + 2, iY - 4), color, 1.2f);
                        draw->AddRectFilled(ImVec2(iX - 6, iY - 4), ImVec2(iX + 6, iY + 4), color, 1.5f);
                        draw->AddCircleFilled(ImVec2(iX - 2.5f, iY - 1), 1.2f, IM_COL32(15, 15, 15, 255));
                        draw->AddCircleFilled(ImVec2(iX + 2.5f, iY - 1), 1.2f, IM_COL32(15, 15, 15, 255));
                    } else {
                        draw->AddCircleFilled(ImVec2(iX, iY - 8), 1.5f, color);
                        draw->AddCircleFilled(ImVec2(iX, iY - 3), 4.5f, color);
                        draw->AddRectFilled(ImVec2(iX - 6, iY + 3), ImVec2(iX + 6, iY + 8), color, 10.0f, ImDrawFlags_RoundCornersTop);
                    }
                    currentX += iconSpace;
                }
                if (Config.ESPMenu.Name) { draw->AddText(nullptr, 17.0f, ImVec2(currentX, boxY + 6), color, nameTxt); currentX += nameSize.x + padding; }
                if (Config.ESPMenu.Distance) draw->AddText(nullptr, 15.0f, ImVec2(currentX, boxY + 8), IM_COL32(220, 220, 220, 255), dTxt);
                if (Config.ESPMenu.Health) {
                    float barY = boxY + boxH - 10.0f; float barW = boxW - (padding * 2); float hpW = (barW * CurHP) / 100.0f;
                    long hCol = IM_COL32(std::min(510*(100-CurHP)/100, 255), std::min(510*CurHP/100, 255), 0, 255);
                    draw->AddRectFilled(ImVec2(boxX + padding, barY), ImVec2(boxX + padding + barW, barY + 5), IM_COL32(40, 40, 40, 255), 2.0f);
                    draw->AddRectFilled(ImVec2(boxX + padding, barY), ImVec2(boxX + padding + hpW, barY + 5), hCol, 2.0f);
                }
            }
        }
    };

    for (int i = 0; i < pawnCount; i++) {
        Pawn* pawn = pawns[i];
        if (!Tools::IsPtrValid(pawn) || !pawn->m_IsAlive()) continue;
        bool isBot = *(bool *)((uintptr_t)pawn + Class_Pawn_m_IsBot);
        if (isBot) totalBots++; else totalEnemies++;
        float dist = Vector3::Distance(pLocalPawn_rootPos, pawn->get_LastPawnPos());
        if (dist <= 100.0f && renderedCount < MAX_RENDER) {
            DoRender(pawn, dist, i);
        }
    }

    for (int i = 0; i < pawnCount; i++) {
        if (renderedCount >= MAX_RENDER) break;
        if (alreadyRendered[i]) continue;
        Pawn* pawn = pawns[i];
        if (!Tools::IsPtrValid(pawn) || !pawn->m_IsAlive()) continue;
        float dist = Vector3::Distance(pLocalPawn_rootPos, pawn->get_LastPawnPos());
        if (dist > 100.0f && dist <= 200.0f) {
            DoRender(pawn, dist, i);
        }
    }

    if (Config.ESPMenu.Count) {
        float lY = 50.0f; float pH = 34.0f; float spacing = 10.0f;
        char pT[16], bT[16]; 
        snprintf(pT, sizeof(pT), "%d", totalEnemies); 
        snprintf(bT, sizeof(bT), "%d", totalBots);
        float pTextW = ImGui::CalcTextSize(pT).x; float bTextW = ImGui::CalcTextSize(bT).x;
        float tabW = 75.0f; float totalW = (tabW * 2) + spacing; float startX = (sWidth - totalW) / 2.0f;

        auto DrawTab = [&](float x, ImU32 iconBgColor, bool isBot, const char* count, float cW) {
            draw->AddRectFilled(ImVec2(x, lY), ImVec2(x + tabW, lY + pH), IM_COL32(20, 20, 20, 240), 6.0f);
            draw->AddRect(ImVec2(x, lY), ImVec2(x + tabW, lY + pH), IM_COL32(80, 80, 80, 180), 6.0f, 15, 1.2f);
            draw->AddRectFilled(ImVec2(x + 3, lY + 3), ImVec2(x + 28, lY + pH - 3), iconBgColor, 4.0f);
            float iX = x + 15.5f; float iY = lY + 17.0f;
            if (isBot) {
                draw->AddLine(ImVec2(iX - 4, iY - 6), ImVec2(iX - 2, iY - 4), IM_COL32(255, 255, 255, 255), 1.0f);
                draw->AddLine(ImVec2(iX + 4, iY - 6), ImVec2(iX + 2, iY - 4), IM_COL32(255, 255, 255, 255), 1.0f);
                draw->AddRectFilled(ImVec2(iX - 5, iY - 4), ImVec2(iX + 5, iY + 4), IM_COL32(255, 255, 255, 255), 1.5f);
                draw->AddCircleFilled(ImVec2(iX - 2.5f, iY - 1), 1.2f, IM_COL32(40, 150, 130, 255));
                draw->AddCircleFilled(ImVec2(iX + 2.5f, iY - 1), 1.2f, IM_COL32(40, 150, 130, 255));
            } else {
                draw->AddCircleFilled(ImVec2(iX, iY - 2), 4.0f, IM_COL32(255, 255, 255, 255));
                draw->AddRectFilled(ImVec2(iX - 5, iY + 3), ImVec2(iX + 5, iY + 7), IM_COL32(255, 255, 255, 255), 10.0f, ImDrawFlags_RoundCornersTop);
            }
            float countX = x + 30.0f + ((tabW - 30.0f - cW) / 2.0f);
            draw->AddText(NULL, 22.0f, ImVec2(countX, lY + 5), IM_COL32(255, 255, 255, 255), count);
        };
        DrawTab(startX, IM_COL32(180, 40, 40, 255), false, pT, pTextW); 
        DrawTab(startX + tabW + spacing, IM_COL32(40, 150, 130, 255), true, bT, bTextW);
    }
}

template<typename ThisType, typename... Args>
void WeaponHandlerByKirito(ThisType thiz, Vector3 startPos, Vector3& dir, Args... args) {
    if (!Config.Aim.Aimbot360 && !Config.Aim.BulletTrack) return;

    auto get_MatchGame = ((uintptr_t(*)())(Class_Gameplay_get_MatchGame))();
    if (!Tools::IsPtrValid((void*)get_MatchGame)) return;

    auto LocalPawn = ((uintptr_t(*)())(Class_Gameplay_get_LocalPawn))();
    if (!LocalPawn) return;

    bool triggerReady = Config.Aim.Trigger == EAimTrigger::None;
    if (Config.Aim.Trigger == EAimTrigger::Shooting) {
        triggerReady = ((bool(*)(uintptr_t))(Class_Pawn_get_IsFiring))(LocalPawn);
    } else if (Config.Aim.Trigger == EAimTrigger::Scoping) {
        triggerReady = ((bool(*)(uintptr_t))(Class_Pawn_IsAiming))(LocalPawn);
    }

    if (!triggerReady) return;

    uintptr_t target = (Config.Aim.By == EAim::Distance) ? GetClosestTarget() : GetInsideFOVTarget();
    if (!target) return;

    auto m_HeadBone = *(Transform**)(target + Class_Pawn_m_HeadBone);
    if (!m_HeadBone) return;

    Vector3 targetPos = m_HeadBone->get_position();
    if (Config.Aim.Target == EAimTarget::Chests) {
        targetPos.y -= 0.2f;
    } else if (Config.Aim.Target == EAimTarget::Body) {
        targetPos.y -= 0.4f;
    }

    auto mainCamera = Camera::get_main();
    if (mainCamera) {
        auto mainView = ((Component *) mainCamera)->get_transform();
        if (mainView) {
            if (Config.Aim.BulletTrack) {
                dir = targetPos - mainView->get_position();
            }
            if (Config.Aim.Aimbot360) {
                auto Pawn_set_AimRotation = (void ( *)(uintptr_t, Quaternion))(Class_Pawn_set_AimRotation);
                Pawn_set_AimRotation(LocalPawn, Quaternion::LookRotation(targetPos - mainView->get_position(), Vector3::Up()));
            }
        }
    }
}

void WeaponFireComponent_Instant_CreateBulletLine(uintptr_t thiz, Vector3 startPos, Vector3 dir, bool isDualFire) {
    WeaponHandlerByKirito(thiz, startPos, dir, isDualFire);
    return oWeaponFireComponent_Instant_CreateBulletLine(thiz, startPos, dir, isDualFire);
}

void WeaponFireComponent_Instant_CreateBulletProjectile(void* thiz, Vector3 startPos, Vector3 dir, void* weaponImpact, int itemID, int flySmokeAssetID, bool enableVirtualStartPos, Vector3 virtualStartPos) {
    WeaponHandlerByKirito(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
    return oWeaponFireComponent_Instant_CreateBulletProjectile(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
}